<template>
  <div class="home">
    <div class="top">
      <img src="../assets/img/top.png">
    </div>
    <div class="echartsContainer">
      <div class="echartsContent">
        <EchartsLine :echartsData='echartsData'/>
      </div>
    </div>
    <div class="tableContainer">
      <div class="title">数据展示</div>
    </div>
    <div class="tableContent">
      <TableList :tableData='tableData'/>
    </div>
    <div class="bottom">
      <img src="../assets/img/bottom.png">
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import EchartsLine from '@/components/EchartsLine.vue'
import TableList from '@/components/TableList.vue'
import Socket from '@/assets/socket.js'

export default {
  name: 'home',
  data () {
    return {
      echartsData: {
        time: [1, 2, 3, 4, 5],
        lineRed: [12, 13, 15, 17, 19],
        lineYellow: [9, 8, 15, 17, 13]
      },
      tableData: [{
        name: '2016-05-022016-05-022016-05-022016-05-022016-05-02',
        state: 0,
        id: 'asda454458'
      }, {
        name: '2016-05-04',
        state: 1,
        id: 'asda4544asd'
      }, {
        name: '2016-05-01',
        state: '1',
        id: 'asda45jio55458'
      }, {
        name: '2016-05-03',
        state: '王小虎',
        id: 'asda454458nkkj'
      }, {
        name: '2016-05-03',
        state: '王小虎',
        id: 'asda454458nkkj'
      }, {
        name: '2016-05-03',
        state: '王小虎',
        id: 'asda454458nkkj'
      }, {
        name: '2016-05-03',
        state: '王小虎',
        id: 'asda454458nkkj'
      }, {
        name: '2016-05-03',
        state: '王小虎',
        id: 'asda454458nkkj'
      }, {
        name: '2016-05-03',
        state: '王小虎',
        id: 'asda454458nkkj'
      }, {
        name: '2016-05-03',
        state: '王小虎',
        id: 'asda454458nkkj'
      }, {
        name: '2016-05-03',
        state: '王小虎',
        id: 'asda454458nkkj'
      }, {
        name: '2016-05-03',
        state: '王小虎',
        id: 'asda454458nkkj'
      }, {
        name: '2016-05-03',
        state: '王小虎',
        id: 'asda454458nkkj'
      }],
      socket: null
    }
  },
  components: {
    EchartsLine,
    TableList
  },
  created () {
    let d = Number(new Date())
    let r = Math.floor(Math.random() * 1000000)
    r = r.toString()
    d = d + r
    this.socket = new Socket({
      url: 'ws://10.125.23.77/api/1.0/iot/websocketserver/' + d,
      onMessage: this.socketMessage
    })
    this.socket.init()
  },
  methods: {
    getNowFormatDate () {
      const date = new Date()
      let seperator1 = '-'
      let seperator2 = ':'
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      if (month >= 1 && month <= 9) {
        month = '0' + month
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = '0' + strDate
      }
      let h = date.getHours() < 10 ? '0' + date.getHours() : date.getHours()
      let m = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()
      let s = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds()
      let currentdate = month + seperator1 + strDate +
      ' ' + h + seperator2 + m +
      seperator2 + s
      return currentdate
    },
    /**
     * @Description: websocket收到消息的回调函数
     * @Author: DuXin
     * @param {event} websocket返回内容
     * @return: 温度，湿度
     * @Date: 2019-04-10 12:22:17
     */
    socketMessage (event) {
      if (event.data === '*') return
      let data = JSON.parse(event.data)
      // eslint-disable-next-line eqeqeq
      if (data.code == 200) {
        let { humidity, temperature } = data.data
        this.add(humidity, temperature)
      }
    },
    /**
     * @Description: 向数据图中增加数据
     * @Author: DuXin
     * @param {humidity} 湿度
     * @param {temperature} 温度
     * @return: 温度，湿度
     * @Date: 2019-04-10 12:22:17
     */
    add (humidity, temperature) {
      if (this.echartsData.time.length < 15) {
        this.echartsData.time.push(this.getNowFormatDate())
        this.echartsData.lineRed.push(temperature)
        this.echartsData.lineYellow.push(humidity)
      } else {
        this.echartsData.time.shift()
        this.echartsData.time.push(this.getNowFormatDate())

        this.echartsData.lineRed.shift()
        this.echartsData.lineRed.push(temperature)

        this.echartsData.lineYellow.shift()
        this.echartsData.lineYellow.push(humidity)
      }
    },
    test () {
      console.log(1)
    }
  }
}
</script>

<style lang="stylus" scoped>
.home
  width 100%
  height 100%
  margin 0 auto
.top
.bottom
  position absolute
  width 1854px
  height 184px
  z-index 999
.top
  left 0
  top 0
  width 100%
.bottom
  right 0
  bottom 0
  width 100%
  overflow hidden
.top img
.bottom img
  width 100%
  height 100%
.echartsContent
  width 100%
  height calc(100% - 184px)
  margin-top 184px
.echartsContainer
  position absolute
  left 230px
  top 0
  bottom 153px
  right 758px
  box-shadow 0px 8px 64px 0px rgba(162,162,162,0.5)
.tableContainer
  position absolute
  left 1225px
  top 198px
  right 230px
  bottom 0
  box-shadow 0px 8px 64px 0px rgba(162,162,162,0.5)
.title
  position absolute
  width 185px
  height 63px
  font-size 45px
  font-family PingFangSC-Medium
  font-weight 500
  color rgba(99,99,99,1)
  line-height 63px
  top -113px
  right 6px
.tableContent
  position absolute
  left 1225px
  top 198px
  right 230px
  bottom 110px
  z-index 1000
  box-sizing border-box
  padding 0 20px
</style>
