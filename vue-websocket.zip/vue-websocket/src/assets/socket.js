/**
 * @Description: websocket对象
 * @Author: DuXin
 * @param {url} 连接地址
 * @param {onOpen} 连接成功回调
 * @param {onClose} 连接关闭回调
 * @param {onMessage} 收到消息回调
 * @param {onError} 报错回调
 * @return: websocket实例
 * @Date: 2019-04-04 15:43:19
 */
const _webSocket = Symbol('webSocket')
const _getWebIP = Symbol('getWebIP')
const _throwErr = Symbol('throwErr')
const _params = Symbol('params')
const _getNowFormatDate = Symbol('getNowFormatDate')
const _tryTime = Symbol('tryTime')
const _heartBeat = Symbol('_heartBeat')

const _heart = Symbol('_heart')
const _openHandler = Symbol('_openHandler')
const _closeHandler = Symbol('_closeHandler')
const _messageHandler = Symbol('_messageHandler')
class Socket {
  constructor (config) {
    this[_webSocket] = null
    this[_tryTime] = 0
    this[_heartBeat] = false
    this._lostRetryTimeout = null
    this._heartBeatTimeout = null

    this[_params] = config
  }
  [_getWebIP] () {
    return window.location.hostname
  }
  [_throwErr] = (msg) => {
    this[_heartBeat] = false
    this[_params].onError ? this[_params].onError(msg) : console.log(msg)
  }
  [_getNowFormatDate] () {
    const date = new Date()
    let seperator1 = '-'
    let seperator2 = ':'
    let month = date.getMonth() + 1
    let strDate = date.getDate()
    if (month >= 1 && month <= 9) {
      month = '0' + month
    }
    if (strDate >= 0 && strDate <= 9) {
      strDate = '0' + strDate
    }
    let currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate +
    ' ' + date.getHours() + seperator2 + date.getMinutes() +
    seperator2 + date.getSeconds()
    return currentdate
  }
  [_heart] = () => {
    if (this[_heartBeat]) {
      this[_webSocket].send('*')
      console.log(this[_getNowFormatDate]() + '  心跳')
      this._heartBeatTimeout = setTimeout(() => {
        this[_heart]()
      }, 10 * 60 * 1000)
    } else {
      clearTimeout(this._heartBeatTimeout)
      this._heartBeatTimeout = null
    }
  }
  [_openHandler] = (event) => {
    this[_heartBeat] = true
    this[_tryTime] = 0
    clearTimeout(this._lostRetryTimeout)
    this._lostRetryTimeout = null
    this[_heart]()
    this[_params].onOpen ? this[_params].onOpen(event) : console.log('websocket连接成功')
  }
  [_closeHandler] = (event) => {
    this[_heartBeat] = false
    if (this[_tryTime] < 10) {
      this._lostRetryTimeout = setTimeout(() => {
        this[_webSocket] = null
        this[_tryTime]++
        this.init()
        console.log(this[_getNowFormatDate]() + '  第' + this[_tryTime] + '次重连')
      }, 3 * 1000)
    } else {
      this[_params].onClose ? this[_params].onClose() : console.log('websocket已断开')
      this.close()
    }
  }
  [_messageHandler] = (event) => {
    console.log(event)
  }
  _on (eventName, handler) {
    this[_webSocket].addEventListener(eventName, handler)
    return this
  }
  _off (eventName, handler) {
    this[_webSocket].removeEventListener(eventName, handler)
    return this
  }
  init () {
    if (!window.WebSocket) {
      return this[_throwErr]('您的浏览器不支持websocket')
    }
    // let protocol = location.protocol === 'https' ? 'wss://' : 'ws://'
    // let address = protocol + this[_getWebIP]() + ':8080/' + this[_params].url
    this[_webSocket] = new WebSocket(this[_params].url)
    this._on('open', this[_openHandler])
      ._on('message', this[_params].onMessage || this[_messageHandler])
      ._on('close', this[_closeHandler])
      ._on('error', this[_throwErr])
  }
  send (data) {
    if (!this[_webSocket] && this[_webSocket].readyState === 1) {
      this[_throwErr]('websocket暂未连接')
      return
    }
    this[_webSocket].send(data)
  }
  close = () => {
    if (this[_webSocket]) {
      this[_webSocket].close()
      this._off('open')
        ._off('message')
        ._off('close')
        ._off('error')
    }
  }
}
export default Socket
