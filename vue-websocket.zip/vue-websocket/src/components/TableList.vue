<template>
 <div class="tableList">
   <div class="tableHeader">
     <table>
       <thead>
         <tr>
           <th>用户</th>
           <th>当前状态</th>
           <th>操作</th>
         </tr>
       </thead>
     </table>
   </div>
   <div class="tableBody">
      <p class="blank" v-if="!tableData.length">当前暂无设备</p>
      <vuescroll :ops='ops'>
        <table v-if="tableData.length">
          <tr v-for="(item, index) in tableData" :key="index" @click="selDevice(item)">
            <td :title="item.name">
              <span class="selected" :class="{selDevice: item.id == selectedDevice}"></span>
              {{item.name}}
            </td>
            <td>{{item.state | stateFilter}}</td>
            <td>
              <el-button type="danger" size="mini">下线</el-button>
            </td>
          </tr>
        </table>
      </vuescroll>
   </div>
 </div>
</template>

<script>
import vuescroll from 'vuescroll'
export default {
  props: ['tableData'],
  data () {
    return {
      ops: {
        vuescroll: {},
        scrollPanel: {
          scrollingX: false
        },
        rail: {},
        bar: {
          onlyShowBarOnScroll: false,
          background: '#EDEDED'
        }
      },
      selectedDevice: ''
    }
  },
  components: {
    vuescroll
  },
  filters: {
    stateFilter (val) {
      val = val * 1
      let text = ''
      switch (val) {
        case 0: text = '离线'; break
        case 1: text = '在线'; break
        default: text = '---'; break
      }
      return text
    }
  },
  methods: {
    /**
     * @Description: 点击获取表格内的设备id
     * @Author: DuXin
     * @return: 设备id
     * @Date: 2019-04-16 10:48:53
     */
    selDevice (scope) {
      this.selectedDevice = scope.id
      console.log(this.selectedDevice)
    }
  }
}

</script>
<style lang='stylus' scoped>
.tableList
  width 100%
  height 100%
table
  width 100%
  border-collapse collapse
th
  font-size 22px
  font-family PingFangSC-Medium
  font-weight 500
  color rgba(102,102,102,1)
  width 33.3333%
thead tr
  height 90px
tr
  border-bottom 1px solid #ececec
.tableBody
  width 100%
  height calc(100% - 91px)
.tableBody table
  table-layout fixed
.tableBody tr
  height 75px
  cursor pointer
.tableBody td
  width 33.3333%
  font-size 18px
  font-family PingFangSC-Medium
  font-weight 500
  color rgba(153,153,153,1)
  white-space nowrap
  overflow hidden
  text-overflow ellipsis
.tableBody tr td:nth-child(1)
  position relative
  padding-left 10px
.selected
  position absolute
  width 6px
  height 74px
  background linear-gradient(180deg,rgba(138,108,244,1) 0%,rgba(107,38,249,1) 100%)
  border-radius 5px
  left 0
  top 0
  opacity 0
  transition all 0.5s ease
.tableBody tr:hover .selected
  opacity 1
.selDevice
  opacity 1 !important
.blank
  text-align center
  font-size 18px
  font-family PingFangSC-Medium
  font-weight 500
  color rgba(153,153,153,1)
</style>
