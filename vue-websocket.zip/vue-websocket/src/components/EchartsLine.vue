<template>
  <div id="EchatLine" ref="mychart"></div>
</template>
<script>
const echarts = require('echarts/lib/echarts')
require('echarts/lib/component/tooltip')
require('echarts/lib/component/title')
require('echarts/lib/chart/line')
require('echarts/lib/component/markLine')
require('echarts/lib/component/legend')
export default {
  props: ['echartsData'],
  data () {
    return {
      echart: '',
      timer: true
    }
  },
  mounted () {
    this.initCharts()
    this.$Event.$on('resize', () => {
      this.echart.resize()
    })
  },
  methods: {
    initCharts () {
      let dom = this.$refs.mychart
      this.echart = echarts.init(dom)
      this.echart.setOption(this.opt)
    }
  },
  computed: {
    opt () {
      let option = {
        title: {
          text: '折线图堆叠',
          show: false
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          right: 0,
          show: true,
          textStyle: {
            color: '#999'
          }
        },
        grid: {
          left: '10px',
          right: '15px',
          bottom: '2%',
          top: '2%',
          containLabel: true
        },
        toolbox: {
          show: false
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          splitLine: {
            show: false,
            lineStyle: {
              color: '#979797'
              // color: '#0e568e'
            }
          },
          axisLine: {
            lineStyle: {
              type: 'solid',
              width: '1',
              color: '#979797'
              // color: {
              //   colorStops: [{
              //     offset: 0, color: '#0ae2c7'
              //   }, {
              //     offset: 1, color: '#082a31'
              //   }]
              // }
            }
          },
          axisLabel: {
            textStyle: {
              color: '#333'
            }
          },
          data: this.echartsData.time
        },
        yAxis: {
          type: 'value',
          axisLine: {
            lineStyle: {
              type: 'solid',
              width: '1',
              color: '#979797'
              // color: {
              //   type: 'linear',
              //   x: 0,
              //   y: 1,
              //   x2: 0,
              //   y2: 0,
              //   colorStops: [{
              //     offset: 0, color: '#0ae2c7'
              //   }, {
              //     offset: 1, color: '#082a31'
              //   }]
              // }
            }
          },
          axisLabel: {
            show: true,
            textStyle: {
              color: '#333'
            }
          },
          splitLine: {
            show: false
          }
        },
        series: [{
          name: '温度',
          type: 'line',
          stack: '温度',
          color: '#FBA0AE',
          symbol: 'none',
          smooth: true,
          itemStyle: {
            normal: {
              color: '#FB9DAD',
              lineStyle: {
                width: 3,
                shadowColor: '#FFE5EC',
                shadowBlur: 4,
                shadowOffsetY: 10,
                type: 'solid',
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                  offset: 0,
                  color: '#F5CEBF'
                }, {
                  offset: 1,
                  color: '#FF7CA0'
                }])
              }
            }
          },
          data: this.echartsData.lineRed
        },
        {
          name: '湿度',
          type: 'line',
          stack: '湿度',
          color: '#2EE7C0',
          symbol: 'none',
          smooth: true,
          itemStyle: {
            normal: {
              color: '#3CDCCB',
              lineStyle: {
                width: 3,
                shadowColor: '#9FFDFF',
                shadowBlur: 4,
                shadowOffsetY: 10,
                type: 'solid',
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                  offset: 0,
                  color: '#2EE7C0'
                }, {
                  offset: 1,
                  color: '#5CC4E3'
                }])
              }
            }
          },
          data: this.echartsData.lineYellow
        }]
      }
      return option
    }
  },
  watch: {
    opt: {
      handler (options) {
        this.echart.setOption(options)
      },
      deep: true
    }
  }
}
</script>
<style scoped lang="stylus">
#EchatLine
  width 100%
  height 100%
  font-size 14px
header
  text-align center
  color #fff
  font-size 22px
  padding 10px 0
</style>
