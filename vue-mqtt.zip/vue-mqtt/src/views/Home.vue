<template>
  <div class="home">
    <h3 class="header">
      <div class="title">MQTT设备模拟器</div>
      <div class="switch">
        <mt-switch
        @change="connectSwitch"
        v-model="online"/>
      </div>
    </h3>
    <div class="container">
      <DeviceProp
      @reportData="reportData"
      @reportDataTimer="reportDataTimer"
      :online="online"
      :data="sendValue" />
      <div class="blank"></div>
      <DeviceLog :log="log"/>
    </div>
  </div>
</template>

<script>
import DeviceProp from '../components/DeviceProp'
import DeviceLog from '../components/DeviceLog'
export default {
  name: 'home',
  data () {
    return {
      client: null,
      userName: 'admin1',
      clientId: '',
      password: 'Public@Chint2019',
      online: false,
      lost: true,
      log: [],
      sendValue: {
        humidity: '60',
        temperature: '23'
      },
      reportTimer: null
    }
  },
  components: {
    DeviceProp,
    DeviceLog
  },
  created () {
    this.mqttInit()
  },
  methods: {
    /**
     * @Description: 获取当前时间并格式化
     * @Author: DuXin
     * @return: MM-DD hh:mm:ss
     * @Date: 2019-04-19 13:30:34
     */
    getNowFormatDate () {
      const date = new Date()
      let seperator1 = '-'
      let seperator2 = ':'
      let month = date.getMonth() + 1
      let strDate = date.getDate()
      if (month >= 1 && month <= 9) {
        month = '0' + month
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = '0' + strDate
      }
      let h = date.getHours() < 10 ? '0' + date.getHours() : date.getHours()
      let m = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()
      let s = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds()
      let currentdate = month + seperator1 + strDate +
      ' ' + h + seperator2 + m +
      seperator2 + s
      return currentdate
    },
    mqttInit () {
      this.addLog('连接中')
      let clientId = window.localStorage.getItem('mqtt-clientID')
      if (!clientId) {
        let d = Number(new Date())
        let r = Math.floor(Math.random() * 1000000)
        r = r.toString()
        clientId = d + r
        clientId = clientId.split('').reverse().join('') // 倒序生成的clinentId 以便区分
        window.localStorage.setItem('mqtt-clientID', clientId)
        this.clientId = clientId
      } else {
        this.clientId = clientId
      }
      let url = 'iot-emq.chint.com'
      let port = 8083
      // 以时间戳+四位的随机数生成clientId

      // eslint-disable-next-line no-undef
      this.client = new Paho.MQTT.Client(url, Number(port), this.clientId)

      this.client.onConnectionLost = this.onConnectionLost
      this.client.onMessageArrived = this.onMessageArrived
      this.client.onMessageDelivered = this.onMessageDelivered

      this.client.connect({
        userName: this.userName,
        password: this.password,
        onSuccess: this.onConnect
      })
    },
    /**
     * @Description: mqtt上线/离线
     * @Author: DuXin
     * @Date: 2019-04-24 10:24:07
     */
    connectSwitch () {
      this.online ? this.onlineAction() : this.offlineAction()
    },
    /**
     * @Description: mqtt上线
     * @Author: DuXin
     * @Date: 2019-04-24 10:29:16
     */
    onlineAction () {
      if (this.lost) {
        this.mqttInit()
        return false
      }
      let messageData = {
        method: 'chint.iot.method.online',
        version: '1.0'
      }
      this.online = true
      this.mqttSendMsg(messageData)
      this.addLog('连接成功')
    },
    /**
     * @Description: mqtt下线
     * @Author: DuXin
     * @Date: 2019-04-24 10:29:27
     */
    offlineAction () {
      let messageData = {
        method: 'chint.iot.method.offline',
        version: '1.0'
      }
      this.online = false
      this.mqttSendMsg(messageData)
      this.addLog('连接已关闭')
    },
    /**
     * @Description: mqtt连接成功回调
     * @Author: DuXin
     * @Date: 2019-04-24 10:24:34
     */
    onConnect () {
      this.addLog('连接成功')
      this.client.subscribe('/iot/airControl/' + this.clientId + '/response') // 订阅主题
      let messageData = {
        method: 'chint.iot.method.online',
        version: '1.0'
      }
      this.mqttSendMsg(messageData)
      this.online = true
      this.lost = false
    },
    /**
     * @Description: 连接断开回调
     * @Author: DuXin
     * @Date: 2019-04-24 10:25:16
     */
    onConnectionLost (event) {
      console.log(event)
      this.addLog('连接已关闭')
      this.online = false
      this.lost = true
    },
    /**
     * @Description: 收到mqtt消息回调
     * @Author: DuXin
     * @param {object} event 收到的数据
     * @Date: 2019-04-24 10:27:01
     */
    onMessageArrived (event) {
      if (!event.payloadString) {
        return false
      }
      this.addLog('收到数据')
      this.addLog(event.payloadString)
      let data = JSON.parse(event.payloadString)
      if (data.method === 'chint.iot.method.offline') {
        let messageData = {
          method: 'chint.iot.method.offline',
          version: '1.0'
        }
        this.mqttSendMsg(messageData)
        this.online = false
      }
    },
    /**
     * @Description: 消息送达回调
     * @Author: DuXin
     * @param {object} event 发送的数据
     * @Date: 2019-04-24 10:27:29
     */
    onMessageDelivered (event) {
      this.addLog('数据已发送')
      this.addLog(event.payloadString)
    },
    /**
     * @Description: 发送mqtt消息
     * @Author: DuXin
     * @param {object} params 发送的json数据
     * @Date: 2019-04-24 10:28:18
     */
    mqttSendMsg (params) {
      params.requestId = Number(new Date())
      params = JSON.stringify(params)
      // eslint-disable-next-line no-undef
      let message = new Paho.MQTT.Message(params)
      message.destinationName = '/iot/airControl/' + this.clientId + '/request'
      this.client.send(message)
    },
    /**
     * @Description: 发送数据
     * @Author: DuXin
     * @Date: 2019-04-24 13:07:34
     */
    reportData () {
      if (!this.online) {
        return false
      }
      let params = JSON.parse(JSON.stringify(this.sendValue))
      let messageData = {
        method: 'chint.iot.method.publish.data',
        version: '1.0',
        params
      }
      this.mqttSendMsg(messageData)
    },
    /**
     * @Description: 持续上报
     * @Author: DuXin
     * @Date: 2019-04-24 13:07:17
     */
    reportDataTimer (type) {
      if (type) {
        this.reportTimer = setInterval(() => {
          this.sendValue.humidity = Math.floor(Math.random() * 100)
          this.sendValue.temperature = Math.floor(Math.random() * 100)
          this.reportData()
        }, 2000)
      } else {
        clearInterval(this.reportTimer)
        this.reportTimer = null
      }
    },
    addLog (log) {
      let date = this.getNowFormatDate()
      this.log.unshift(date + ':' + log)
    }
  }
}
</script>
<style lang="stylus" scoped>
.home
  width 100%
  height 100%
  background-color  #F8F8FA
  background-image  url('../assets/img/bk.png')
  background-repeat no-repeat
  background-size 100%
.header
  margin 0
  padding 0
  font-size 24px
  font-family PingFangSC-Semibold
  font-weight 600
  color rgba(255,255,255,1)
  line-height 33px
  padding-left 36px
  padding-top 40px
  padding-bottom 34px
  display flex
.header >>> .mint-switch-input:checked + .mint-switch-core
  background #53D76B
  border #53d788
.title
  width 190+65px
.switch
  flex 1
  display flex
  justify-content center
.container
  width 100%
  box-sizing border-box
  padding 0 20px
.blank
  clear both
  width 100%
  height 30px
</style>
