<template>
  <div class="device-prop">
    <div class="content-data">
      <div class="circle-content">
        <CircleData
        :value="data.temperature"
        @Change='ChangeTemperature'
        background='linear-gradient(180deg,rgba(254,238,131,1) 0%,rgba(254,170,60,1) 100%)'
        unit="°C"
        title="温度">
        </CircleData>
      </div>
      <div class="circle-content">
        <CircleData
        :value="data.humidity"
        background='linear-gradient(180deg,#B49FFF 0%,#6D51FF 100%)'
        unit="%"
        @Change='changeHumidity'
        title="湿度">
        </CircleData>
      </div>
    </div>
    <div class="btn-group">
      <div class="btn">
        <ActionBtn
        :img="icon1"
        @click="emit('reportData')"
        title="数据上报"/>
      </div>
      <div class="btn">
        <ActionBtn
        v-if="!this.isReportDataTimer"
        :img="icon2"
        @click="reportDataTimer(true)"
        title="持续上报"/>
        <ActionBtn
        v-if="this.isReportDataTimer"
        @click="reportDataTimer(false)"
        :img="icon3"
        title="停止上报"/>
      </div>
    </div>
  </div>
</template>

<script>
import CircleData from './CircleData'
import ActionBtn from './ActionBtn'
import icon1 from '../assets/img/up.png'
import icon2 from '../assets/img/autoUp.png'
import icon3 from '../assets/img/stopUp.png'
export default {
  props: ['data', 'online'],
  data () {
    return {
      icon1,
      icon2,
      icon3,
      isReportDataTimer: false
    }
  },
  components: {
    CircleData,
    ActionBtn
  },
  methods: {
    ChangeTemperature (val) {
      this.data.temperature = val
      this.$emit('change', this.data)
    },
    changeHumidity (val) {
      this.data.humidity = val
      this.$emit('change', this.data)
    },
    reportDataTimer (type) {
      if (type && !this.online) {
        return false
      }
      this.isReportDataTimer = type
      this.emit('reportDataTimer', type)
    },
    emit (type, params = '') {
      this.$emit(type, params)
    }
  },
  watch: {
    online () {
      if (!this.online && this.isReportDataTimer) {
        this.isReportDataTimer = false
        this.emit('reportDataTimer', false)
      }
    }
  }
}

</script>
<style lang='stylus' scoped>
.device-prop
  width 100%
  height 256px
  background rgba(255,255,255,1)
  border-radius 10px
  box-sizing border-box
  padding 0 17px
.content-data
  width 100%
  height 167px
  border-bottom 1px solid #eee
  display flex
.circle-content
  flex 1
  height 100%
  display flex
  justify-content center
  align-items center
.btn-group
  display flex
  width 100%
  height calc(100% - 167px)
.btn
  flex 1
  height 100%
</style>
