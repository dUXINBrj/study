<template>
  <div class="circle">
    <div class="circle-data" :style="{background: this.background ? this.background : '#05f3a6'}">
      <input type="text" v-model="value_" />
      <label>{{unit}}</label>
      <h5 class="title">{{title}}</h5>
    </div>
  </div>
</template>

<script>
export default {
  props: ['value', 'unit', 'title', 'background'],
  data () {
    return {
      value_: ''
    }
  },
  watch: {
    value: {
      handler () {
        this.value_ = this.value
      },
      immediate: true
    },
    value_ (val) {
      this.$emit('Change', val)
    }
  }
}

</script>
<style lang='stylus' scoped>
.circle
  height 118px
  width 88px
.circle-data
  height 88px
  width 88px
  text-align center
  line-height 88px
  border-radius 50%
  background linear-gradient(180deg,rgba(254,238,131,1) 0%,rgba(254,170,60,1) 100%)
  position relative
  font-size 20px
  font-family PingFangSC-Medium
  font-weight 500
  color rgba(255,255,255,1)
.title
  width 100%
  text-align center
  height 17px
  font-size 12px
  font-family PingFangSC-Medium
  font-weight 500
  color rgba(102,102,102,1)
  line-height 17px
  position absolute
  bottom -30px
  margin 0
input
  background-color transparent
  max-width 30px
  font-size 20px
  font-family PingFangSC-Medium
  font-weight 500
  color rgba(255,255,255,1)
  text-align center
  border none
  padding 0
  margin 0
</style>
