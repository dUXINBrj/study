<template>
  <div class="device-log">
    <DeviceTitle>设备日志</DeviceTitle>
    <div class="log-content" ref="wrapper">
      <div class="content" ref="scrollContent">
        <p v-if="!log.length" class="blank">暂无日志</p>
        <p class="log" v-for="(item, index) in log" :key="index">{{item}}</p>
      </div>
    </div>
  </div>
</template>

<script>
import DeviceTitle from './DeviceTitle'
import BScroll from 'better-scroll'
export default {
  props: ['log'],
  data () {
    return {
      scroll: null
    }
  },
  mounted () {
    this.$nextTick(() => {
      this.scroll = new BScroll(this.$refs.wrapper, {
        scrollbar: {
          fade: true,
          interactive: false
        }
      })
    })
  },
  components: {
    DeviceTitle
  }
}

</script>
<style lang='stylus' scoped>
.device-log
  width 100%
  height 193px
  background rgba(255,255,255,1)
  box-shadow 0px 3px 21px 0px rgba(188,188,188,1)
  border-radius 10px
.log-content
  padding 10px 14px
  box-sizing border-box
  width 100%
  height calc(100% - 40px)
  font-size 12px
  font-family PingFangSC-Regular
  font-weight 400
  color rgba(153,153,153,1)
  overflow hidden
  position relative
.blank
  font-size 12px
  font-family PingFangSC-Regular
  font-weight 400
  color rgba(153,153,153,1)
  text-align center
.log
  line-height 30px
  margin 0
  font-size 12px
  font-family PingFangSC-Regular
  font-weight 400
  color rgba(153,153,153,1)
  border-bottom 1px solid #eee
  word-wrap break-word
  word-break break-all
</style>
