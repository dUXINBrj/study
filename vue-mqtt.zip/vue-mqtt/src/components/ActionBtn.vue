<template>
 <div class="btn-container">
   <div class="btn-content" @click="click">
     <div class="icon" :style="{background: '../assets/img/up.png'}">
      <img :src="this.img">
     </div>
     <h5 class="title">{{title}}</h5>
   </div>
 </div>
</template>

<script>
export default {
  props: ['title', 'img'],
  methods: {
    click () {
      this.$emit('click')
    }
  }
}

</script>
<style lang='stylus' scoped>
.btn-container
  width 100%
  height 100%
  display flex
  justify-content center
  align-items center
.btn-content
  width 58px
  height 55px
.title
  margin 0
  margin-top 5px
  text-align center
  height 17px
  font-size 12px
  font-family PingFangSC-Regular
  font-weight 400
  color rgba(102,102,102,1)
  line-height 17px
.icon
  width 28px
  height 28px
  margin 0 auto
img
  width 100%
  height 100%
  border none
</style>
