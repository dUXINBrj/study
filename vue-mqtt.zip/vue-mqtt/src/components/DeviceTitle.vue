<template>
  <div class="device-title">
    <slot></slot>
  </div>
</template>

<script>
export default {
  data () {
    return {
    }
  }
}

</script>
<style lang='stylus' scoped>
.device-title
  width 100%
  height 40px
  background linear-gradient(270deg,rgba(159,121,249,1) 0%,rgba(83,85,229,1) 100%)
  border-radius 9px 9px 0px 0px
  font-size 18px
  font-family PingFangSC-Regular
  font-weight 400
  color rgba(255,255,255,1)
  line-height 40px
  box-sizing border-box
  padding 0 15px
</style>
