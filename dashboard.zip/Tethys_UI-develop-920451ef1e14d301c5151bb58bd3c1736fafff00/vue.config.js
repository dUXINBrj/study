module.exports = {
  publicPath: "./",
  devServer: {
    open: true,
    port: 18080
  }
};
