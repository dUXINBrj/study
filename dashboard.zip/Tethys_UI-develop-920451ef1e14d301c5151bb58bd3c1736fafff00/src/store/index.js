import Vue from "vue";
import Vuex from "vuex";
import commonConfig from "@/config/config.json";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    loadData: false,
    runtime: false, //是否是运行状态
    screenFull: false, //是否全屏状态
    config: commonConfig,
    deviceList: [], //测点集合
    pointGroup: {}, //点位组，定时相关信息
    authorityList: [
      {
        id: "5a359b2f88d644c2ab034d51514fa218",
        label: "超级管理员",
        password: "65535",
        grade: "65535",
        counter: 0
      }
    ],
    userInfo: {} || localStorage.getItem("userInfo") //用户信息
  },
  mutations: {
    setConfig(state, data) {
      state.config = data;
    },
    setDeviceList(state, data) {
      state.deviceList = data;
    },
    setPointGroup(state, data) {
      state.pointGroup = data;
    },
    SET_ACCOUNT(state, platform) {
      state.userInfo = platform;
      localStorage.setItem("userInfo", platform);
    },
    setLoadData(state, data) {
      state.loadData = data;
    }
  },
  actions: {
    setLoadData({ commit }, data) {
      commit("setLoadData", data);
    },
    setConfig({ commit }, data) {
      commit("setConfig", data);
    },
    setDeviceList({ commit }, data) {
      commit("setDeviceList", data);
    },
    setPointGroup({ commit }, data) {
      commit("setPointGroup", data);
    },
    setAccount({ commit }, platForm) {
      commit("SET_ACCOUNT", platForm);
    }
  },
  modules: {},
  getters: {
    theme: state => state.config.stylesConfig.theme["主题切换"].value,
    getInfo: state => state.userInfo
  }
});
