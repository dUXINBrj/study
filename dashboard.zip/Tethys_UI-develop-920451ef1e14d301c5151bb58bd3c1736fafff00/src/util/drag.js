import DomOperate from "./domOperate";
import RotateResize from "./rotateResize";
class Drag extends DomOperate {
  init(vm) {
    this.draging = false;
    this.startFn = this.starts.bind(this);
    this.endFn = this.ends.bind(this);
    this.keyUpFn = this.keyUp.bind(this);
    document.addEventListener("mousedown", this.startFn);
    document.addEventListener("mouseup", this.endFn);
    document.addEventListener("keyup", this.keyUpFn);
    this.initRotateResize();
    super.init(vm);
  }
  initRotateResize() {
    this.rotateResize = new RotateResize(".symbolDiv");
  }
  keyUp(event) {
    if (46 == event.keyCode) {
      this.$vm.$refs.contextmenu.deleteVm();
    }
    //ctrol
    if (event.ctrlKey) {
      switch (event.keyCode) {
        case 67:
          //复制ctrol+c
          if (this.vms) {
            this.$vm.$refs.contextmenu.startCopy();
          } else {
            this.$vm.$message({
              type: "warning",
              message: "请选择拷贝对象"
            });
          }
          break;
        case 86:
          //粘贴ctrol+v
          if (this.copyConfig.length) {
            this.$vm.$refs.contextmenu.endCopy();
          } else {
            this.$vm.$message({
              type: "warning",
              message: "请先拷贝元素"
            });
          }
          break;
        case 90:
          //回退ctrol+z

          break;
        default:
          break;
      }
    }
  }
  starts(e) {
    this.$left.clearDialog();
    this.hideContextmenu();
    if (e.ctrlKey) return;

    this.x = e.clientX;
    this.y = e.clientY;
    /**
     * status代表目前的动作，在move中科院做特别的处理
     * 0代表创建元素，拖动元素
     * 1代码改变元素宽高
     * 2多选状态
     */
    let status = null;
    let direction = null;
    let index = null;
    let className = e.target.className;
    let parentElementClassName = e.target.parentElement.className;
    if (className.indexOf("imgDiv") !== -1) {
      //添加新元素
      this.clearVms();
      this.cloneNode(e.target);
      status = 0;
    } else if (parentElementClassName.indexOf("imgDiv") != -1) {
      //添加新元素
      this.clearVms();
      this.cloneNode(e.target.parentElement);
      status = 0;
    } else if (className.indexOf("taglen") != -1) {
      //改变元素宽高属性
      status = 1;
      index = +e.target.getAttribute("index");
      console.log(index);
      direction = this.getDirection(className);
      this.rotateResize.init(this.vms.$data, ".symbolDiv");
      this.rotateResize.resize(event, this.vms.$data, index);
      return;
    } else if (className.indexOf("dragDiv") != -1) {
      this.clearVms();
      status = 3;
      this.showMark();
      this.showMenu({ classes: 66 });
    } else if (className.indexOf("rotate") > -1) {
      status = 4;
      let { width, height, left, top } = this.vms.$el.getBoundingClientRect();
      let { transform } = this.vms;
      this.rotateCenter = {
        x: left + width / 2,
        y: top + height / 2
      };
      this.startPos = {
        x: this.x - this.rotateCenter.x,
        y: this.y - this.rotateCenter.y
      };
      this.o_rotateDeg = transform;
    } else if (
      className.indexOf("symbolComp") != -1 ||
      className == "markView symbolMark" ||
      this.selected
    ) {
      //改变元素位置属性
      status = 2;
    }
    if (status === null) return;
    console.log("开始");
    document.onmousemove = event => {
      this.moves(event, status, direction, index);
      this.draging = true;
    };
  }
  cloneNode(el) {
    this.vms = el.cloneNode(true);
    this.vms.classList.add("moving");
    let width = el.offsetWidth;
    let height = el.offsetHeight;
    this.vms.isClone = true;
    this.vms.style.position = "absolute";
    this.vms.style.width = width + "px";
    this.vms.style.height = height + "px";
    this.vms.style.left = this.x - width / 2 + "px";
    this.vms.style.top = this.y - height / 2 + "px";
    this.vms.style.zIndex = 2000;
    document.body.appendChild(this.vms);
  }
  moves(event, status, direction) {
    if (!this.vms) return;
    if (!(this.vms instanceof Array)) {
      if (this.vms.locked || this.vms.isCompose) return;
    } else if (
      this.vms.length &&
      (this.vms[0].locked || this.vms[0].isCompose)
    ) {
      return;
    }
    let x = event.clientX - this.x;
    let y = event.clientY - this.y;
    switch (status) {
      case 0:
        var width = this.vms.offsetWidth;
        var height = this.vms.offsetHeight;
        this.vms.style.top = event.clientY - width / 2 + "px";
        this.vms.style.left = event.clientX - height / 2 + "px";
        break;
      case 1:
        if (direction.indexOf("top") != -1) {
          this.backFn(vm => {
            let height = vm.height - y;
            if (height <= 0) {
              return;
            }
            vm.top = vm.top + y;
            vm.height = vm.height - y;
          });
        }
        if (direction.indexOf("left") != -1) {
          this.backFn(vm => {
            let width = vm.width - x;
            if (width <= 0) {
              return;
            }
            vm.left = vm.left + x;
            vm.width = vm.width - x;
          });
        }
        if (direction.indexOf("right") != -1) {
          this.backFn(vm => {
            vm.width = vm.width + x;
          });
        }
        if (direction.indexOf("bottom") != -1) {
          this.backFn(vm => {
            vm.height = vm.height + y;
          });
        }
        break;
      case 2:
        this.backFn(vm => {
          var parentWidth = vm.$parentEl.clientWidth;
          var parentHeight = vm.$parentEl.clientHeight;
          if (vm.left + x < -vm.width / 2) {
            vm.left = -vm.width / 2;
          } else if (vm.left + x > parentWidth - vm.width / 2) {
            vm.left = parentWidth - vm.width / 2;
          } else {
            vm.left = vm.left + x;
          }
          if (vm.top + y < -vm.height / 2) {
            vm.top = -vm.height / 2;
          } else if (vm.top + y > parentHeight - vm.height / 2) {
            vm.top = parentHeight - vm.height / 2;
          } else {
            vm.top = vm.top + y;
          }
        });
        break;
      case 3:
        this.vms.width = this.vms.width + x;
        this.vms.height = this.vms.height + y;
        this.vms.resetStyle();
        break;

      case 4:
        var { pageX, pageY } = event;
        var current = {
          x: pageX - this.rotateCenter.x,
          y: pageY - this.rotateCenter.y
        };
        var DEG_SCALE = 3;
        var o_rotateDeg = this.o_rotateDeg;
        var back_roateDeg = this.vms.transform;
        var rotateDeg = this.calcDeg(
          current,
          this.startPos,
          o_rotateDeg,
          back_roateDeg,
          DEG_SCALE
        );
        this.vms.transform = rotateDeg;
        this.startPos = current;
        break;
      default:
        break;
    }

    this.x = event.clientX;
    this.y = event.clientY;
  }

  calcDeg(current, origin, o_rotateDeg, o_backupDeg, deg_scale) {
    let o = Math.sqrt(origin.x * origin.x + origin.y * origin.y);
    let c = Math.sqrt(current.x * current.x + current.y * current.y);
    let z = Math.sqrt(
      Math.pow(current.x - origin.x, 2) + Math.pow(current.y - origin.y, 2)
    );
    let cosZ = (Math.pow(o, 2) + Math.pow(c, 2) - Math.pow(z, 2)) / (2 * o * c);
    let zPI = Math.acos(cosZ);
    let zDeg = 180 / (Math.PI / zPI);
    //叉乘判断鼠标顺序 为负值 标识逆时针 为正值 表示顺时针
    let crossMultiply = origin.x * current.y - origin.y * current.x;
    let newDeg = Number(o_rotateDeg + zDeg);
    if (crossMultiply < 0) {
      newDeg = Number(o_rotateDeg - zDeg);
    }
    if (newDeg >= 360) {
      newDeg = 0;
    } else if (newDeg < 0) {
      newDeg = 360 + newDeg;
    }
    this.o_rotateDeg = o_rotateDeg = newDeg;
    if (o_backupDeg % 90 === 0) {
      if (
        o_rotateDeg >
          (o_backupDeg === 0 ? (crossMultiply < 0 ? 360 : 0) : o_backupDeg) -
            deg_scale &&
        o_rotateDeg <
          (o_backupDeg === 0 ? (crossMultiply < 0 ? 360 : 0) : o_backupDeg) +
            deg_scale
      ) {
        return o_backupDeg;
      }
    } else {
      if (newDeg % 90 >= 90 - deg_scale && newDeg % 90 < 90) {
        newDeg = 90 * (Math.floor(newDeg / 90) + 1);
      } else if (newDeg % 90 <= deg_scale && newDeg % 90 > 0) {
        newDeg = 90 * Math.floor(newDeg / 90);
      }
    }
    newDeg = Math.round(newDeg >= 360 ? 0 : newDeg);

    return newDeg;
  }

  backFn(fn) {
    let obj = this.vms;
    if (obj instanceof Array) {
      obj.forEach(vm => {
        fn(vm);
        vm.resetStyle();
      });
      return;
    } else {
      fn(obj);
      obj.resetStyle();
    }
  }
  ends(event) {
    console.log("结束");
    this.x = null;
    this.y = null;
    document.onmousemove = null;
    this.copyEvent = event;
    if (this.vms) {
      if (this.vms.type === "mark") {
        this.$mark.$el.style.display = "none";
        this.getMultiSymbols(this.vms.config);
        this.$mark.width = 0;
        this.$mark.height = 0;
      } else {
        if (this.vms.isClone) {
          this.vms.isClone = false;
          let config = JSON.parse(this.vms.getAttribute("data-config"));
          document.body.removeChild(this.vms);
          let checkCreate = this.checkCreateSymbol(event, config);
          if (checkCreate) return;
          let _vm = this.createSymbol(config, {
            x: event.clientX,
            y: event.clientY
          });
          this.$vm.$nextTick(() => {
            _vm.resetStyle();
            this.showMenu(_vm);
          });
        } else if (
          this.vms &&
          !(this.vms instanceof Array) &&
          !(this.vms instanceof HTMLElement)
        ) {
          this.vms.resetStyle();
          // this.showMenu(this.vms);
        }
      }
    }
    this.draging = false;
    this.selected = false;
  }
  destory() {
    document.removeEventListener("mousedown", this.startFn);
    document.removeEventListener("mouseup", this.endFn);
    document.removeEventListener("keyup", this.keyUpFn);
  }
}
export default Drag;
