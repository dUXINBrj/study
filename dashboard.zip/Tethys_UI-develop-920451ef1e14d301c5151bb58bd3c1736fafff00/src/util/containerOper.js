import DateOper from "./dateOper";
//容器管理器
class ContainerOper extends DateOper {
  init() {
    this.containerVms = {};
    super.init();
  }
  deleteContainerVms(vm) {
    let id = vm.$parentEl.getAttribute("id").slice(5);
    let target = this.containerVms[id].indexOf(vm);
    this.containerVms[id].splice(target, 1);
  }
  isNeedContainer(vm) {
    let id = vm.id;
    let comps = this.centerConfigs[this.currentPageId].comps;
    return comps.find(comp => {
      let config = comp.$refs.comp;
      config = config ? config.highConfig : null;
      if (config && JSON.stringify(config).indexOf(id) !== -1) {
        return true;
      }
    });
  }
  //校验元素是否拖放到容器中
  containerCheck(event, config, bool) {
    let target = null;
    let newConfig = null;
    let id = this.currentPageId;
    (this.containerVms[id] || []).forEach(vm => {
      if (!vm) return;
      let nowConfig = this.checkInner(event, vm, config, bool);
      if (nowConfig) {
        if (!target || target.zIndex < vm.zIndex) {
          target = vm;
          newConfig = nowConfig;
        }
      }
    });
    if (target) {
      let contain = target.$refs.comp;
      let containConfig = contain.baisicConfig["容器"];
      if (containConfig.blockContent) {
        //改容器被锁定
        return false;
      }
      let dom = contain.$el.querySelector(".body");
      let zIndex;
      if (config.zIndex) {
        zIndex = config.zIndex;
      } else {
        zIndex = contain.zIndex;
        contain.zIndex++;
      }
      this.vms = this.$vm.$symbols(target, dom, config, {
        left: newConfig.x < 0 ? 0 : newConfig.x,
        top: newConfig.y < 0 ? 0 : newConfig.y,
        zIndex: zIndex
      });
      let _vm = this.vms;
      this.$vm.$message("组件被放入容器内!");
      contain.comps[containConfig.currentTabIndex].push(_vm);
      if (!bool) {
        this.$vm.$nextTick(() => {
          _vm.resetStyle();
          this.showMenu(_vm);
        });
        this.setOperation(this.vms);
        this.selected = false;
      }
      return _vm;
    }
    return false;
  }
  //判断当前event是否在元素中
  checkInner(event, vm, config, bool) {
    if (vm.$el.style.display === "none") return;
    let scrollLeft = document.querySelector(".home").scrollLeft;
    let scrollTop = document.querySelector(".home").scrollTop;
    let { top, left } = this.getLocation();
    let addLeft = bool ? 0 : config.width / 2;
    let addTop = bool ? 0 : config.height / 2;
    let otherTop = this.currentPageType === "single" ? 0 : 50;
    let x = event.clientX - left + scrollLeft;
    let y = event.clientY - top - otherTop + scrollTop;
    if (
      x < vm.left ||
      x > vm.left + vm.width ||
      y < vm.top ||
      y > vm.top + vm.height
    ) {
      return false;
    }
    return {
      x: x - addLeft - vm.left,
      y: y - addTop - vm.top
    };
  }
  //收集容器
  collectContainer(vm) {
    let id = vm.$parentEl.getAttribute("id").slice(5);
    let config = this.containerVms[id];
    if (!config) {
      this.containerVms[id] = [];
    }
    this.containerVms[id].push(vm);
    //初始化容器，需要初始化容器内部配置
    let contain = vm.$refs.comp;
    let compconfigs = contain.compconfigs;
    let dom = contain.$el.querySelector(".body");

    let containConfig = contain.baisicConfig["容器"];
    compconfigs.forEach((compConfig, index) => {
      compConfig.forEach(compCon => {
        if (compCon.type === "compose") {
          //组合
          let comps = contain.comps[index];
          let vms = compCon.linkCompIndexs.map(index => {
            return comps[index];
          });
          this.startCompose(vms, compCon, true, index);
          // vm = this.$vm.$composeSymbols(this.$vm, dom, config);
        } else {
          let createVm = this.$vm.$symbols(vm, dom, compCon);
          if (index !== containConfig.currentTabIndex) {
            createVm.$el.style.display = "none";
          }
          contain.comps[index].push(createVm);
        }
      });
    });
  }
}
export default ContainerOper;
