import Others from "@/component/base/other.vue";
import Texts from "@/component/base/text.vue";
import Numbers from "@/component/base/number.vue";
import Rects from "@/component/base/rect.vue";
import Animations from "@/component/base/animation.vue";
import Sharps from "@/component/base/sharp.vue";
import Webviews from "@/component/base/webview.vue";
import Containers from "@/component/base/container.vue";
import Circles from "@/component/base/circle.vue";
import SwitchBtns from "@/component/sub/switchBtn.vue";
import Maps from "@/component/map/map.vue";
import Title from "@/component/sub/title.vue";
import Slider from "@/component/sub/slider.vue";
import Progress from "@/component/sub/progress.vue";
import Time from "@/component/sub/time.vue";
import DatePicker from "@/component/sub/datePicker.vue";
import PieSolid from "@/component/sub/pieSolid.vue";
import PieDoughnut from "@/component/sub/pieDoughnut.vue";
import PieNested from "@/component/sub/pieNested.vue";
import SubTitle from "@/component/sub/title.vue";
import DateSelect from "@/component/sub/dateSelect.vue";
import Tree from "@/component/high/tree.vue";
import Monitor from "@/component/spec/monitor.vue";
//生成唯一id
export function guid() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c) {
    var r = (Math.random() * 16) | 0,
      v = c == "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}
//组装样式
export function packFont(val) {
  return {
    fontSize: val[0],
    fontFamily: val[1],
    fontWeight: val[2],
    color: val[3]
  };
}

//获取页面列表
export function getPages(that) {
  let addRoute = [
    {
      value: "用户管理",
      label: "用户管理"
    },
    {
      value: "操作日志",
      label: "操作日志"
    }
  ];
  return that.$drag.$left.$refs.pages.pages
    .map(item => {
      return {
        label: item.name,
        value: item.id
      };
    })
    .concat(addRoute);
}

//获取组件
export function getComp(type) {
  let comp = null;
  switch (type) {
    case "text":
      comp = Texts;
      break;
    case "number":
      comp = Numbers;
      break;
    case "circle":
      comp = Circles;
      break;
    case "animation":
      comp = Animations;
      break;
    case "rect":
      comp = Rects;
      break;
    case "container":
      comp = Containers;
      break;
    case "webview":
      comp = Webviews;
      break;
    case "sharp":
      comp = Sharps;
      break;
    case "开关按钮":
      comp = SwitchBtns;
      break;
    case "标题栏":
      comp = Title;
      break;
    case "拖动条":
      comp = Slider;
      break;
    case "进度条":
      comp = Progress;
      break;
    case "日期选择":
      comp = DatePicker;
      break;
    case "时间":
      comp = Time;
      break;
    case "饼图":
      comp = PieSolid;
      break;
    case "环图":
      comp = PieDoughnut;
      break;
    case "环图2":
      comp = PieNested;
      comp = SubTitle;
      break;
    case "日期选择器":
      comp = DateSelect;
      break;
    case "树形关联图":
      comp = Tree;
      break;
    case "测试":
      comp = Others;
      break;
    case "monitor":
      comp = Monitor;
      break;
    default:
      comp = Maps;
      break;
  }
  return comp;
}
