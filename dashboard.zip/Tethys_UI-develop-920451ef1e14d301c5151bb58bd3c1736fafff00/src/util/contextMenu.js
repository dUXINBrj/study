import ContainerOper from "./containerOper.js";
class ContextMenu extends ContainerOper {
  init() {
    this.$contextmenu = this.$vm.$refs.contextmenu;
    //图标类操作
    this.targetVm = null;
    //上下移动准备
    this.linkVms = [];
    //操作的树组件原始
    this.operTreeItem = null;
    this.operTreeItemParent = null;
    //复制准备
    this.copyConfig = null;
    this.copyVms = [];
    this.copyContainer = null;
    this.copyEvent = null;
    this.curentVmIndex = null;

    super.init();
  }
  //取消组合
  unCompose(bool, vm) {
    let vms = vm || this.vms;
    let comps, dom;
    if (vms.$parent.type === "container") {
      let compData = vms.$parent.$refs.comp;
      let container = compData.baisicConfig["容器"];
      comps = compData.comps[container.currentTabIndex];
      dom = compData.$el.querySelector(".body");
    } else {
      comps = this.centerConfigs[this.currentPageId].comps;
      dom = this.$vm.$el.querySelector("#page-" + this.currentPageId);
    }
    let targetIndex = -1;
    let linkComps = vms.linkComps;
    comps.forEach((comp, index) => {
      if (comp === vms) {
        targetIndex = index;
      }
    });
    linkComps.forEach(comp => {
      comp.left = comp.left + vms.left;
      comp.top = comp.top + vms.top;
      dom.appendChild(comp.$el);
      comp.$parentEl = dom;
      comp.resetStyle();
      if (bool) {
        comp.isCompose = false;
      }
    });
    comps[targetIndex].$destroy();
    comps.splice(targetIndex, 1);
    return linkComps;
  }
  //开始组合
  /**
   *
   * @param {*} composeVm
   * @param {*} config
   * @param {*} status
   * @param {*} index 给容器使用
   */
  startCompose(composeVm, config, status, index) {
    let composeVms = composeVm || this.vms;
    if (!this.currentPageId) return;
    let bool = true;
    composeVms.some(vm => {
      if (vm.type === "container" || vm.type === "树形关联图") {
        bool = false;
      }
    });
    if (!bool) {
      this.$vm.$message("树形图和容器不能参与组合~");
      return;
    }
    let { left, width, top, height } = this.getMulOption(composeVms);
    let vms = [];
    composeVms.forEach(vm => {
      if (vm.compose === "compose") {
        vms.push(...vm.linkComps);
        this.unCompose(false, vm);
      } else {
        vm.isCompose = true;
        vms.push(vm);
      }
    });
    return this.createCompose(
      vms,
      left,
      width,
      top,
      height,
      config,
      status,
      index
    );
  }
  //创建组合元素
  createCompose(vms, left, width, top, height, config, status, index) {
    let bool = vms[0].$parent.type === "container";
    let dom = this.$vm.$el.querySelector("#page-" + this.currentPageId);
    let domVm = this.$vm;
    if (bool) {
      dom = vms[0].$parent.$refs.comp.$el.querySelector(".body");
      domVm = vms[0].$parent;
    }
    vms.sort((a, b) => {
      return a.zIndex - b.zIndex;
    });
    let zIndex = vms[vms.length - 1].zIndex;
    this.clearVms();
    let newConfig = config
      ? { ...config, linkComps: vms }
      : {
          linkComps: vms,
          currentPageId: this.currentPageId,
          width: width,
          height: height,
          left: left,
          top: top,
          zIndex: zIndex
        };

    this.vms = this.$vm.$composeSymbols(domVm, dom, newConfig);
    this.vms.$el.querySelector(".markView.symbolMark").style.zIndex = zIndex;
    let vmDom = this.vms.$el.querySelector(".content");
    vms.forEach(vm => {
      vm.left = vm.left - left;
      vm.top = vm.top - top;
      vmDom.appendChild(vm.$el);
      vm.$parentEl = vmDom;
    });
    if (bool) {
      let compData = vms[0].$parent.$refs.comp;
      let container = compData.baisicConfig["容器"];
      if (index === undefined) {
        index = container.currentTabIndex;
      }
      if (index !== container.currentTabIndex) {
        this.vms.$el.style.display = "none";
      }
      compData.comps[index].push(this.vms);
      compData.zIndex++;
    } else {
      this.centerConfigs[this.currentPageId].zIndex = zIndex + 1;
      this.centerConfigs[this.currentPageId].comps.push(this.vms);
    }
    if (!status) {
      this.setOperation(this.vms);
    }
    return this.vms;
  }
  showTreeContextMenu(item, parentItem) {
    this.showContextmenu(this.vms, item, parentItem);
  }
  //显示菜单
  showContextmenu(vm, item, parentItem) {
    let showMenu = this.getMenu(vm, item, parentItem);
    if (!showMenu) return;
    let scrollLeft = document.querySelector(".home").scrollLeft;
    let scrollTop = document.querySelector(".home").scrollTop;
    let { top, left } = this.getLocation();
    let padding = parseInt(this.$vm.otherStyle.padding.slice(0, -2));

    this.$contextmenu.left = event.clientX - left + scrollLeft + padding;
    this.$contextmenu.top = event.clientY - top + scrollTop + padding;
    this.$contextmenu.showMenu = showMenu;
  }
  //隐藏菜单
  hideContextmenu() {
    this.$contextmenu.showMenu = "";
  }
  //获取多个元素在当前页面中的顺序下标
  getTargetIndexs(_vms) {
    let vms = _vms || this.vms;
    let targetIndex = [];
    vms.forEach(vm => {
      let index = this.getTargetIndex(vm);
      targetIndex.push(index);
    });
    return targetIndex;
  }
  //获取耽搁元素在当前页面中的顺序下标
  getTargetIndex(vms, comps) {
    comps = comps || this.centerConfigs[this.currentPageId].comps;
    return comps.findIndex(comp => {
      if (comp === vms) {
        return true;
      }
    });
  }
  //获取多个元素范围
  getMulOption(copyVms) {
    let operVms = copyVms || this.vms;
    if (!operVms.length || operVms.length <= 1) return {};
    operVms.sort((a, b) => {
      return a.left - b.left;
    });
    let left = operVms[0].left;
    operVms.sort((a, b) => {
      return a.top - b.top;
    });
    let top = operVms[0].top;
    operVms.sort((a, b) => {
      return a.left + a.width - b.left - b.width;
    });
    let val = operVms[operVms.length - 1];
    let width = val.left + val.width - left;
    operVms.sort((a, b) => {
      return a.top + a.height - b.top - b.height;
    });
    val = operVms[operVms.length - 1];
    let height = val.top + val.height - top;
    return { left, top, width, height };
  }
  //显示右击菜单
  getMenu(vm, item, parentItem) {
    this.linkVms = [];
    let showMenu = "";
    if (item) {
      this.operTreeItem = item;
      this.operTreeItemParent = parentItem
        ? parentItem.children
        : this.vms.$refs.comp.treeData;
      showMenu += ",62,65,66,";
      if (item.type === "file") {
        showMenu += ",631,";
      } else if (item.type === "floder") {
        showMenu += ",61,632,";
        if (!item.children.length) {
          showMenu += ",6321,";
        }
      }
      showMenu += ",64,";
      if (this.operTreeItemParent.length > 1) {
        showMenu += ",641,";
      }
      return showMenu;
    }
    this.operTreeItem = null;
    this.operTreeItemParent = null;

    if (this.copyConfig) {
      this.copyEvent = event;
      showMenu += ",5,";
    }
    if (!vm) return showMenu;
    showMenu += ",1,";
    if (this.vms instanceof Array && this.vms.length >= 2) {
      showMenu += ",4,41,";
      this.vms.forEach(instance => {
        if (
          instance === vm &&
          Array.from(vm.$el.classList).indexOf("oper") === -1
        ) {
          this.targetVm = vm;
          vm.$el.classList.add("oper");
        } else {
          instance.$el.classList.remove("oper");
        }
      });
    } else {
      if (vm.type === "compose") {
        showMenu += "42";
      }
      if (vm.type === "树形关联图") {
        showMenu += "61";
      }
      let { width, height, left, top } = vm;
      let instances;
      if (vm.$parent.type == "container") {
        let compData = vm.$parent.$refs.comp;
        let container = compData.baisicConfig["容器"];
        instances = compData.comps[container.currentTabIndex];
      } else {
        instances = this.centerConfigs[this.currentPageId].comps;
      }

      this.linkVms = instances.filter(instance => {
        if (
          instance.left >= left + width ||
          instance.top >= top + height ||
          instance.left + instance.width <= left ||
          instance.height + instance.top <= top ||
          instance.locked ||
          instance.isCompose
        ) {
          return false;
        }
        return true;
      });
      this.linkVms.sort((a, b) => {
        return a.zIndex - b.zIndex;
      });
      this.curentVmIndex = this.linkVms.findIndex(item => {
        return item === vm;
      });
      if (this.linkVms.length >= 2) {
        if (this.curentVmIndex === 0) {
          showMenu += ",3,31,33,";
        } else if (this.curentVmIndex === this.linkVms.length - 1) {
          showMenu += ",3,32,34,";
        } else {
          showMenu += ",3,31,32,33,34,";
        }
      }
    }
    if (vm.locked) {
      showMenu += ",22,";
    } else {
      showMenu += ",21,";
    }
    return showMenu;
  }
}
export default ContextMenu;
