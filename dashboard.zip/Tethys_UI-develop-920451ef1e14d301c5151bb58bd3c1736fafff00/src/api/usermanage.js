import { commonRequest } from "./request";
export function getProjectList(params) {
  let datas = {
    url: window.config.dataCenterUrl + "/cloudconfigure/Project/GetPages",
    methods: "post",
    info: "编辑态：获取项目列表",
    params: params
  };
  return commonRequest(datas);
}
export function getUserList(params) {
  let datas = {
    url: window.config.dataCenterUrl + "/users/page",
    methods: "post",
    info: "运行态：获取用户项目列表",
    params: params
  };

  return commonRequest(datas);
}
export function getProjectListRun(params) {
  let datas = {
    url: window.config.dataCenterUrl + "/users/run/project/info",
    methods: "post",
    info: "获取用户列表",
    params: params
  };

  return commonRequest(datas);
}
export function addUser(params) {
  let datas = {
    url: window.config.dataCenterUrl + "/users/add",
    methods: "post",
    info: "新增用户",
    params: params
  };

  return commonRequest(datas);
}
export function editUser(params) {
  let datas = {
    url: window.config.dataCenterUrl + "/users/edit",
    methods: "post",
    info: "编辑用户信息",
    params: params
  };

  return commonRequest(datas);
}
export function deleteUser(params) {
  let datas = {
    url: window.config.dataCenterUrl + "/users/delete",
    methods: "post",
    info: "删除用户",
    params: params
  };

  return commonRequest(datas);
}
export function resetUser(params) {
  let datas = {
    url: window.config.dataCenterUrl + "/users/reset",
    methods: "post",
    info: "重置用户信息",
    params: params
  };
  return commonRequest(datas);
}
