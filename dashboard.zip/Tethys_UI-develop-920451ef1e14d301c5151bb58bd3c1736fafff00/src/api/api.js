import { commonRequest } from "./request";
export function logins(params) {
  let datas = {
    url: window.config.requestUrl + "/admin/Admin/LogIn",
    methods: "post",
    info: "登录",
    params: params
  };

  return commonRequest(datas);
}
export function getUserInfo(params) {
  let datas = {
    url: window.config.requestUrl + "/admin/Admin/GetUserInfo",
    methods: "post",
    info: "获取用户信息",
    params: params
  };
  return commonRequest(datas);
}

export function getPages(params) {
  let datas = {
    url: window.config.requestUrl + "/cloudconfigure/Project/GetPages",
    methods: "post",
    info: "获取项目列表",
    params: params
  };

  return commonRequest(datas);
}

//http://configcenterapi.cloud.techsel.net/api/cloudconfigure/DevicePoint/GetTree
