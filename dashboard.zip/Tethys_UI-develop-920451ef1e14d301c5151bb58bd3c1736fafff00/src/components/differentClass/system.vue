<template>
  <div class="comp">
    <el-collapse v-model="activeName" accordion>
      <el-collapse-item title="主题" name="1">
        <div v-if="showAdd" style="text-align:center;">
          <el-button type="primary" size="small" @click="addPoint(1)"
            >新增点位组</el-button
          >
        </div>
        <template v-else>
          <div
            class="pointDiv"
            v-for="(item, index) in pointGroup"
            :key="item.id"
          >
            <div class="title">名称</div>
            <div class="pointBlock">
              <input type="text" v-model="item.name" />
              <span
                @click="readyPoints(item)"
                class="iconfont iconxitong"
              ></span>
            </div>
            <div class="divFlex">
              <div
                @click="addPoint(2)"
                v-show="index + 1 === pointGroup.length"
                class="add"
              >
                +
              </div>
              <div
                @click="deletes(item, index)"
                v-show="pointGroup.length !== 1"
                class="delete"
              >
                -
              </div>
            </div>
          </div>
        </template>
      </el-collapse-item>
      <el-collapse-item title="顶部编辑" name="2">
        <div>权限列表</div>
      </el-collapse-item>
    </el-collapse>
    <div class="bottomDiv">- 我是有底线的 -</div>
    <el-dialog title="点位组合页面" :visible.sync="pointDialog">
      <div class="title">
        <span>列表</span>
      </div>
      <el-table
        ref="tableRef"
        :data="
          pointPiTs.piTs.filter((currentValue, index) => {
            return currentPage * 10 > index && index >= currentPage * 10 - 10;
          })
        "
        border
        row-key="id"
        style="width: 100%"
        height="296"
        :highlight-current-row="false"
        :row-style="{ height: '0px' }"
        :cell-style="{ padding: '0px' }"
        @selection-change="handleSelectChange"
      >
        <el-table-column
          type="selection"
          align="center"
          width="50"
        ></el-table-column>
        <el-table-column
          type="index"
          :index="indexMethodPit"
          label="序号"
          width="50"
          align="center"
        ></el-table-column>
        <el-table-column prop="name" label="点位名称" align="center">
          <template slot-scope="scope">
            <el-input
              v-model.trim="scope.row.name"
              placeholder="请输入点位名称"
            ></el-input>
          </template>
        </el-table-column>
        <el-table-column prop="pit" label="点位设备" align="center">
          <template slot-scope="scope">
            <!-- 级联选择器 -->
            <el-cascader
              v-model="scope.row.pit"
              size="small"
              :props="props"
              @change="upPoint($event, scope.$index)"
              clearable
            ></el-cascader>
          </template>
        </el-table-column>
        <el-table-column prop="address" label="操作" align="center">
          <template slot-scope="scope">
            <i
              class="el-icon-close list-body-icon"
              @click="removePoint(scope)"
              size="mini"
              title="删除"
            ></i>
            <i
              class="el-icon-top list-body-icon"
              size="mini"
              title="向上"
              @click="handleSort(0, scope.row)"
            ></i>
            <i
              class="el-icon-bottom list-body-icon"
              size="mini"
              title="向下"
              @click="handleSort(1, scope.row)"
            ></i>
          </template>
        </el-table-column>
      </el-table>
      <div class="footer">
        <el-pagination
          background
          layout="prev, pager, next,total"
          :total="pointPiTs.piTs.length"
          :current-page.sync="currentPage"
          @current-change="changCurrentPage"
        ></el-pagination>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button
          size="mini"
          class="btn-determine"
          @click="okPointDialog"
          style="width:115px"
          >确 定</el-button
        >
        <el-button
          size="mini"
          class="btn-cancel"
          @click="closePointDialog"
          style="width:115px"
          >取 消</el-button
        >
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { guid } from "@/util/common.js";
export default {
  data() {
    return {
      gridData: [
        {
          date: "2016-05-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-04",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-01",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-03",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        }
      ],
      activeName: "1",
      showAdd: true,
      props: { multiple: true },
      pointGroup: [],
      pointPiTs: { piTs: [] },
      pointDialog: false,
      currentPage: 1
    };
  },
  methods: {
    //组装点位
    readyPoints(item) {
      this.pointDialog = true;
      this.pointPiTs = item;
      console.log(item);
    },
    //选取数据
    handleSelectChange(val) {
      console.log(val);
    },
    //关闭弹窗
    closePointDialog() {},
    //页签变化
    changCurrentPage() {},
    //页面序号
    indexMethodPit(index) {
      return index + (this.currentPage - 1) * 10 + 1;
    },
    //级联选择
    upPoint() {},
    removePoint(scope) {
      console.log(scope);
    },
    //移动位置
    handleSort(type, row) {
      console.log(type, row);
    },
    okPointDialog() {},
    deletes(item, index) {
      this.$confirm(`请确认删除点位组:${item.name}?`, "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.pointGroup.splice(index, 1);
          this.$message({
            type: "success",
            message: "删除成功!"
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    //新增点位
    addPoint(status) {
      this.showAdd = false;
      let point = {
        count: 0,
        id: guid(),
        name: "点位组-" + (this.pointGroup.length + 1),
        piTs: []
      };
      switch (status) {
        case 1:
          this.pointGroup = [point];
          break;
        case 2:
          this.pointGroup.push(point);
          break;
        default:
          break;
      }
    }
  }
};
</script>

<style lang="less" scoped>
.comp {
  height: calc(100%);
  width: calc(100%);
  background: #373e4a;
  overflow: overlay;
  .pointDiv {
    .pointBlock {
      margin-top: 15px;
      display: flex;
      flex-direction: row;
      input {
        font-size: 14px;
        text-align: left;
        padding-left: 10px;
        box-sizing: border-box;
        height: 30px;
        color: #282828;
        background-color: #fff;
        border: 1px solid #282828;
        border-top-left-radius: 4px;
        border-bottom-left-radius: 4px;
        line-height: 30px;
        width: 130px;
      }
      .iconfont {
        height: 30px;
        width: 60px;
        font-size: 18px;
        border: 1px solid #282828;
        background: #f5f7fa;
        box-sizing: border-box;
        text-align: center;
        color: #909399;
        border-top-right-radius: 4px;
        border-bottom-right-radius: 4px;
      }
    }
  }
  &::-webkit-scrollbar {
    width: 4px;
    height: 4px;
  }
  &::-webkit-scrollbar-thumb {
    background: #e3e3e3;
    border-radius: 4px;
  }
  &::-webkit-scrollbar-resizer {
    background: #ff0bee;
  }
  & /deep/ .el-collapse {
    border-top: 0px;
    border-bottom: 1px solid #24252a;
  }
  & /deep/ .el-collapse-item__header {
    background: #737881;
    border-bottom: 1px solid #24252a;
    color: white;
    padding-left: 20px;
  }
  & /deep/ .el-collapse-item__wrap {
    border-bottom: 0px;
  }
  & /deep/ .el-collapse-item__content {
    background: #373e4a;
    color: #e9e9e9;
    padding: 16px 25px 40px;
    box-sizing: border-box;
  }
  & /deep/ .el-collapse-item__header {
    height: 36px;
    line-height: 36px;
  }
  .bottomDiv {
    text-align: center;
    color: #c0c4cc;
    font-size: 12px;
    padding-bottom: 20px;
  }
}
.divFlex {
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  align-items: center;
}
.add,
.delete {
  width: 40px;
  font-size: 40px;
  text-align: center;
}
</style>
