<template>
  <div class="comp">
    <el-collapse v-model="activeName" accordion>
      <el-collapse-item title="主题" name="1">
        <packComp
          :config="themeConfig"
          :type="'theme'"
          :onChange="initStyle"
        ></packComp>
      </el-collapse-item>
      <el-collapse-item title="顶部编辑" name="2">
        <packComp
          :config="config.topConfig"
          :type="'top'"
          :onChange="initStyle"
        ></packComp>
      </el-collapse-item>
      <el-collapse-item title="中心区域编辑" name="3">
        <packComp
          :config="config.centerConfig"
          :type="'center'"
          :onChange="initStyle"
        ></packComp>
      </el-collapse-item>
      <el-collapse-item title="左侧导航编辑" name="4">
        <packComp
          :config="config.leftConfig"
          :type="'left'"
          :onChange="initStyle"
        ></packComp>
      </el-collapse-item>
      <el-collapse-item title="用户入口编辑" name="5"> </el-collapse-item>
    </el-collapse>
    <div class="bottomDiv">- 我是有底线的 -</div>
  </div>
</template>

<script>
import packComp from "./pack/pack.vue";
export default {
  components: {
    packComp
  },
  data() {
    return {
      activeName: "1",
      white: {
        topBackground: "#3573c1"
      },
      black: {
        topBackground: "#2d3035"
      },
      themeConfig: {
        主题切换: {
          type: "select",
          label: [
            {
              label: "主题一",
              value: "black"
            },
            {
              label: "主题二",
              value: "white"
            }
          ],
          value: "black"
        },
        线条: {
          type: "line"
        },
        页面选项: {
          type: "select",
          label: [
            {
              label: "固定尺寸",
              value: "1"
            },
            {
              label: "适应宽度",
              value: "2"
            },
            {
              label: "适应全部",
              value: "3"
            }
          ],
          value: "1"
        }
      },
      topConfig: {
        样式还原: {
          type: "resetStyle"
        },
        标题: {
          type: "inputFontStyle",
          value: ["新能源科技有限公司", "22px", "", "normal", "white"]
        },
        标题渐变色: {
          type: "slider-gradient",
          note: "启用",
          hidden: false,
          range: [0, 360],
          value: ["", 0]
        },
        标题阴影: {
          type: "shadowStyle",
          note: "启用",
          value: ["", "2px", "2px", "2px", false]
        },
        标题位置: {
          type: "select",
          label: [
            {
              label: "左",
              value: "flex-start"
            },
            {
              label: "居中",
              value: "center"
            },
            {
              label: "右",
              value: "flex-end"
            }
          ],
          value: "flex-start"
        },
        副标题: {
          type: "inputFontStyle",
          note: "启用",
          value: ["能效综合平台", "12px", "", "normal", "white", true]
        },
        Logo: {
          type: "logo",
          note: "启用",
          value: ["", false, true]
        },
        背景色: {
          type: "color-select",
          value: "#3573c1"
        },
        边框发光色: {
          type: "color-select",
          value: "rgba(255, 255, 255, 0.5)"
        },
        隐藏顶部导航: {
          type: "checkbox",
          note: "启用",
          value: false
        },
        运行时间: {
          type: "checkbox",
          note: "启用",
          value: false
        },
        天气: {
          type: "sky",
          note: "启用",
          value: ["14px", "上海", "normal", "rgba(255,255,255,1)", false]
        }
      },
      layoutVm: null,
      config: null,
      header: null,
      lefter: null,
      center: null,
      theme: null
    };
  },
  created() {
    this.layoutVm = this.$parent.$parent;
    this.config = this.layoutVm.config;
    console.log(JSON.stringify(this.config));
    Object.assign(this.themeConfig, this.layoutVm.themeConfig);
  },
  mounted() {
    this.header = this.layoutVm.$refs.headers;
    this.lefter = this.layoutVm.$refs.lefters;
    this.center = this.$drag.$vm;
  },
  methods: {
    initStyle(type, order) {
      switch (type) {
        case "theme":
          break;
        case "top":
          this.header.initStyle(order);
          break;
        case "center":
          this.center.initStyle(order);
          break;
        case "left":
          this.lefter.initStyle(order);
          break;
        default:
          break;
      }
      this.layoutVm.initStyle();
    }
  }
};
</script>

<style lang="less" scoped>
.comp {
  height: calc(100%);
  width: calc(100%);
  background: #373e4a;
  overflow: overlay;
  &::-webkit-scrollbar {
    width: 4px;
    height: 4px;
  }
  &::-webkit-scrollbar-thumb {
    background: #e3e3e3;
    border-radius: 4px;
  }
  &::-webkit-scrollbar-resizer {
    background: #ff0bee;
  }
  & /deep/ .el-collapse {
    border-top: 0px;
    border-bottom: 1px solid #24252a;
  }
  & /deep/ .el-collapse-item__header {
    background: #737881;
    border-bottom: 1px solid #24252a;
    color: white;
    padding-left: 20px;
  }
  & /deep/ .el-collapse-item__wrap {
    border-bottom: 0px;
  }
  & /deep/ .el-collapse-item__content {
    background: #373e4a;
    color: #e9e9e9;
    padding: 16px 10px 40px;
    box-sizing: border-box;
  }
  & /deep/ .el-collapse-item__header {
    height: 36px;
    line-height: 36px;
  }
  .bottomDiv {
    text-align: center;
    color: #c0c4cc;
    font-size: 12px;
    padding-bottom: 20px;
  }
}
</style>
