<template>
  <div class="comps">
    <div class="title">{{ title }}</div>
    <div class="body">
      <el-slider
        ref="slider"
        v-model="config.value[0]"
        @change="onChange"
        @input="deal"
      ></el-slider>
      <span class="demonstration">{{ config.value[0] + "%" }}</span>
    </div>
    <el-checkbox v-model="config.value[1]" @change="onChange">{{
      config.note
    }}</el-checkbox>
  </div>
</template>

<script>
export default {
  props: {
    title: String,
    config: Object,
    onChange: Function
  },
  methods: {
    deal() {
      this.onChange();
    }
  }
};
</script>
