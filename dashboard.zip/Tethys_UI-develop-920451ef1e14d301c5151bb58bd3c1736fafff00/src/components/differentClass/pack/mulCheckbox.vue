<template>
  <div class="comps">
    <el-checkbox-group v-model="config.value" size="small" @change="onChange">
      <el-checkbox-button
        v-for="item in config.label"
        :label="item"
        :key="item"
        >{{ item }}</el-checkbox-button
      >
    </el-checkbox-group>
  </div>
</template>

<script>
export default {
  props: {
    title: String,
    config: Object,
    onChange: Function
  }
};
</script>
