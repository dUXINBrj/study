<template>
  <div class="comps">
    <div class="title">
      <span>{{ title }}</span
      ><el-checkbox v-model="config.value[2]" @change="onChange">{{
        config.note
      }}</el-checkbox>
    </div>
    <div class="bodys" v-show="!config.value.hidden">
      <el-checkbox v-model="config.value[1]">启动自定义Logo</el-checkbox>
      <!-- <el-upload
        v-show="config.value[1]"
        action="#"
        :multiple="false"
        list-type="picture-card"
        :auto-upload="false"
        :on-change="handleChange"
      >
        <i slot="default" class="el-icon-plus"></i>
      </el-upload> -->
    </div>
  </div>
</template>

<script>
import logo from "@/assets/image/chnt-b.svg";
export default {
  props: {
    title: String,
    config: Object,
    onChange: Function
  },
  data() {
    return {
      dialogImageUrl: ""
    };
  },
  created() {
    this.dialogImageUrl = this.config.value.myLogo || logo;
  },
  methods: {
    handleChange() {
      //   this.config.value.myLogo = file
    },
    handleRemove() {
      console.log(this.config.value.myLogo);
    }
  }
};
</script>
<style lang="less" scoped>
.bodys {
  flex-direction: column;
}
</style>
