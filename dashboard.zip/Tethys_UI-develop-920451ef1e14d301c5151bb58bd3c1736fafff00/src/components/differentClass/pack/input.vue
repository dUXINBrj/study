<template>
  <div>
    <div class="title">{{ title }}</div>
    <el-input
      v-model="config.value"
      placeholder="请输入内容"
      @input="onChange"
      @change="onChange"
    ></el-input>
  </div>
</template>
<script>
export default {
  props: {
    title: String,
    config: Object,
    onChange: Function
  }
};
</script>
