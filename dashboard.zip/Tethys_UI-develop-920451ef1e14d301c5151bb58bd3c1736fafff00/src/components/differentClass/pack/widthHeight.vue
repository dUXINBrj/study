<template>
  <div class="comps">
    <div class="title">{{ title }}</div>
    <div class="body" style="padding-left:10px;">
      <span>
        {{ config.label[0] }}
        <input
          type="text"
          v-model.number="config.value[0]"
          @change="onChange"
          @input="onChange"
        /> </span
      >&nbsp;&nbsp;&nbsp;
      <span>
        {{ config.label[1] }}
        <input
          type="text"
          v-model.number="config.value[1]"
          @change="onChange"
          @input="onChange"
        />
      </span>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    title: String,
    config: Object,
    onChange: Function
  }
};
</script>
<style lang="less" scoped>
input {
  outline: none;
  width: 68px;
  color: #282828;
  border: 1px solid #cccccc;
  background-color: #fff;
  border-radius: 4px;
  border: 1px solid rgba(40, 40, 40, 1);
  font-family: microsoft yahei;
  font-size: 14px;
  text-align: center;
  box-sizing: border-box;
  height: 30px;
}
</style>
