<template>
  <div class="comps">
    <div class="title">
      <span>{{ title }}</span>
      <el-checkbox
        v-show="config.note"
        v-model="config.disabled"
        @change="onChange"
        >{{ config.note }}</el-checkbox
      >
    </div>
    <div
      class="bg-reset"
      v-show="config.disabled === undefined || config.disabled"
    >
      <color-picker v-model="color1" @change="setColor" />
    </div>
  </div>
</template>

<script>
import { predefineColors } from "./common";
export default {
  props: {
    title: String,
    config: Object,
    onChange: Function
  },
  data() {
    return {
      color1: this.config.value,
      predefineColors: predefineColors
    };
  },
  methods: {
    setColor() {
      this.config.value = this.color1;
      this.onChange();
    }
  }
};
</script>
