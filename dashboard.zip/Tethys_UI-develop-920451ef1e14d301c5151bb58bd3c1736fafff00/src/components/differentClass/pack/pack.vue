<template>
  <div class="comps">
    <template v-for="(item, title) in config">
      <template v-if="item.type === 'input'">
        <packInput
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packInput>
      </template>
      <template v-else-if="item.type === 'select'">
        <packSelect
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packSelect>
      </template>
      <template v-else-if="item.type === 'resetStyle'">
        <packResetStyle
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packResetStyle>
      </template>
      <template v-else-if="item.type === 'fontStyle'">
        <packFontStyle
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packFontStyle>
      </template>
      <template v-else-if="item.type === 'inputFontStyle'">
        <packInputFontStyle
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packInputFontStyle>
      </template>
      <template v-else-if="item.type === 'shadowStyle'">
        <packShadowStyle
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packShadowStyle>
      </template>
      <template v-else-if="item.type === 'logo'">
        <packLogo
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packLogo>
      </template>
      <template v-else-if="item.type === 'color-select'">
        <packColorSelect
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packColorSelect>
      </template>
      <template v-else-if="item.type === 'checkbox'">
        <packCheckbox
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packCheckbox>
      </template>
      <template v-else-if="item.type === 'sky'">
        <packSky
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packSky>
      </template>
      <template v-else-if="item.type === 'linear-gradient'">
        <packLinearGradient
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packLinearGradient>
      </template>
      <template v-else-if="item.type === 'widthHeight'">
        <packWidthHeight
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packWidthHeight>
      </template>
      <template v-else-if="item.type === 'slider'">
        <packSlider
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packSlider>
      </template>
      <template v-else-if="item.type === 'textarea'">
        <packTextarea
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packTextarea>
      </template>
      <template v-else-if="item.type === 'font'">
        <packFont
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packFont>
      </template>
      <template v-else-if="item.type === 'font-align'">
        <packFontAlign
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packFontAlign>
      </template>
      <template v-else-if="item.type === 'slider-gradient'">
        <packSliderGradient
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packSliderGradient>
      </template>
      <template v-else-if="item.type === 'explain'">
        <packExplain
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packExplain>
      </template>
      <template v-else-if="item.type === 'eventOpacity'">
        <packEventOpacity
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packEventOpacity>
      </template>
      <template v-else-if="item.type === 'eventVisible'">
        <packEventVisible
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packEventVisible>
      </template>
      <template v-else-if="item.type === 'eventColor'">
        <packEventColor
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packEventColor>
      </template>
      <template v-else-if="item.type === 'eventColorChange'">
        <packEventColorChange
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packEventColorChange>
      </template>
      <template v-else-if="item.type === 'event'">
        <packEvent
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packEvent>
      </template>
      <template v-else-if="item.type === 'line'">
        <packLine
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packLine>
      </template>
      <template v-else-if="item.type === 'deciaml'">
        <packDeciaml
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packDeciaml>
      </template>
      <template v-else-if="item.type === 'mul-checkbox'">
        <packMulCheckbox
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packMulCheckbox>
      </template>
      <template v-else-if="item.type === 'upload-image'">
        <packUploadImage
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packUploadImage>
      </template>
      <template v-else-if="item.type === 'degree'">
        <packDegree
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packDegree>
      </template>
      <template v-else-if="item.type === 'iconCheckbox'">
        <packIconCheckbox
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packIconCheckbox>
      </template>
      <template v-else-if="item.type === 'container'">
        <packContainer
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packContainer>
      </template>
      <template v-else-if="item.type === 'dateTypeCheckbox'">
        <packDateTypeCheckbox
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packDateTypeCheckbox>
      </template>
      <template v-else-if="item.type === 'eventMap'">
        <packEventMap
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packEventMap>
      </template>
      <template v-else-if="item.type === 'seriesData'">
        <packSeriesData
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packSeriesData>
      </template>
      <template v-else-if="item.type === 'fontThree'">
        <packFontThree
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packFontThree>
      </template>
      <template v-else-if="item.type === 'fontSelect'">
        <packFontSelect
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packFontSelect>
      </template>
      <template v-else-if="item.type === 'treeConfig'">
        <packTreeConfig
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packTreeConfig>
      </template>
      <template v-else-if="item.type === 'dependDateSelect'">
        <packDependDateSelect
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packDependDateSelect>
      </template>
      <template v-else-if="item.type === 'dependtree'">
        <packDependtree
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packDependtree>
      </template>
      <template v-else-if="item.type === 'dateType'">
        <packDateType
          :title="title"
          :config="item"
          :key="title"
          :onChange="changes"
        ></packDateType>
      </template>
    </template>
  </div>
</template>

<script>
import packInput from "./input.vue";
import packSelect from "./select.vue";
import packResetStyle from "./resetStyle.vue";
import packFontStyle from "./fontStyle.vue";
import packInputFontStyle from "./inputFontStyle.vue";
import packShadowStyle from "./shadowStyle.vue";
import packLogo from "./logo.vue";
import packColorSelect from "./colorSelect.vue";
import packCheckbox from "./checkbox.vue";
import packSky from "./sky.vue";
import packLinearGradient from "./linearGradient.vue";
import packWidthHeight from "./widthHeight.vue";
import packSlider from "./slider.vue";
import packTextarea from "./textarea.vue";
import packFontAlign from "./fontAlign.vue";
import packFont from "./font.vue";
import packSliderGradient from "./sliderGradient.vue";
import packExplain from "./explain.vue";
import packEventVisible from "./eventVisible.vue";
import packEventOpacity from "./eventOpacity.vue";
import packEventColor from "./eventColor.vue";
import packEventColorChange from "./eventColorChange.vue";
import packEvent from "./event.vue";
import packLine from "./line.vue";
import packDeciaml from "./deciaml.vue";
import packMulCheckbox from "./mulCheckbox.vue";
import packUploadImage from "./uploadImage.vue";
import packDegree from "./degree.vue";
import packIconCheckbox from "./iconCheckbox.vue";
import packDateTypeCheckbox from "./dateTypeCheckbox.vue";
import packSeriesData from "./seriesData.vue";
import packContainer from "./containers.vue";
import packEventMap from "./eventMap.vue";
import packFontThree from "./fontThree.vue";
import packFontSelect from "./fontSelect.vue";
import packTreeConfig from "./treeConfig.vue";
import packDependtree from "./dependtree.vue";
import packDependDateSelect from "./dependDateSelect.vue";
import packDateType from "./dateType.vue";
export default {
  components: {
    packDateType,
    packDependtree,
    packDependDateSelect,
    packTreeConfig,
    packFontSelect,
    packFontThree,
    packInput,
    packSelect,
    packResetStyle,
    packFontStyle,
    packInputFontStyle,
    packShadowStyle,
    packLogo,
    packColorSelect,
    packCheckbox,
    packSky,
    packLinearGradient,
    packWidthHeight,
    packSlider,
    packTextarea,
    packFontAlign,
    packFont,
    packSliderGradient,
    packExplain,
    packEventVisible,
    packEventOpacity,
    packEventColor,
    packEventColorChange,
    packEvent,
    packLine,
    packDeciaml,
    packMulCheckbox,
    packUploadImage,
    packDegree,
    packIconCheckbox,
    packDateTypeCheckbox,
    packSeriesData,
    packContainer,
    packEventMap
  },
  props: {
    type: String || Object,
    config: Object,
    onChange: Function
  },
  methods: {
    changes(order) {
      this.onChange(this.type, order);
    }
  }
};
</script>
<style lang="less" scoped>
.comps {
  overflow: hidden;
  > div {
    padding: 0 0 15px 0;
    overflow: hidden;
    /deep/ .title {
      position: relative;
      padding-bottom: 5px;
      .el-checkbox {
        position: absolute;
        right: 0px;
      }
    }
  }
  & /deep/ .el-input__inner {
    height: 28px;
    line-height: 28px;
    text-align: center;
    color: #282828;
  }
  & /deep/ .el-input__icon {
    line-height: 28px;
  }
  & /deep/ .el-checkbox {
    color: white;
  }
  & /deep/ .el-color-picker__trigger {
    border: none;
  }
  & /deep/ .el-input-number__decrease {
    display: none;
  }
  & /deep/ .el-input-number__increase {
    display: none;
  }
  & /deep/ .el-slider__input {
    width: 50px;
    .el-input__inner {
      padding: 0;
    }
  }
  & /deep/ .el-slider__runway.show-input {
    width: calc(100% - 70px);
  }
  & /deep/ .body {
    display: flex;
    flex-direction: row;
    align-items: center;
    .el-slider {
      width: calc(80%);
      padding: 0 15px;
    }
    .demonstration {
      text-align: center;
      width: calc(20%);
    }
  }
}
</style>
