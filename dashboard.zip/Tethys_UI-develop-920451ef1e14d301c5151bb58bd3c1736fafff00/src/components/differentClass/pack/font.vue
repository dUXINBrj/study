<template>
  <div class="comps">
    <div class="title">
      <span>{{ title }}</span>
    </div>
    <div class="body" style="margin-top:10px;">
      <div class="rows">
        <span>A</span>
        <div class="text-color">
          <color-picker v-model="color1" @change="setColor" />
        </div>
      </div>
      <div
        class="rows"
        @mousedown.stop="change(1)"
        :style="{ 'font-weight': config.value[1] }"
      >
        <span>B</span>
      </div>
      <div
        class="rows"
        @mousedown.stop="change(2)"
        :style="{ 'font-weight': config.value[2] }"
      >
        <span>T</span>
      </div>
      <div
        class="rows"
        @mousedown.stop="change(3)"
        :style="{ 'font-weight': config.value[3] }"
      >
        <span>U</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    title: String,
    config: Object,
    onChange: Function
  },
  data() {
    return {
      color1: this.config.value[0]
    };
  },
  methods: {
    setColor() {
      this.config.value[0] = this.color1;
      this.onChange();
      this.ids = Math.random();
    },
    change(type) {
      let val = null;
      switch (type) {
        case 1:
          // eslint-disable-next-line no-case-declarations
          val = this.config.value[1];
          this.config.value[1] = val === "normal" ? "bold" : "normal";
          this.onChange();
          break;
        case 2:
          // eslint-disable-next-line no-case-declarations
          val = this.config.value[2];
          this.config.value[2] = val === "" ? "oblique" : "";
          this.onChange();
          break;
        case 3:
          // eslint-disable-next-line no-case-declarations
          val = this.config.value[3];
          this.config.value[3] = val === "" ? "underline" : "";
          this.onChange();
          break;
        default:
          break;
      }
      this.ids = Math.random();
    }
  }
};
</script>

<style lang="less" scoped>
.body {
  height: 28px;
  line-height: 28px;
  background: white;
  color: #282828;
  border-radius: 4px;
  .rows {
    height: calc(100%);
    position: relative;
    width: 25%;
    text-align: center;
    cursor: pointer;
    box-sizing: border-box;
    position: relative;
    .text-color {
      position: absolute;
      left: 0;
      top: 0;
      right: 0;
      bottom: 0;
      opacity: 0;
    }
    select {
      border-radius: 4px;
      width: calc(100%);
      height: 28px;
      border: none;
      font-size: 12px;
    }
    span {
      font-size: 20px;
    }
  }
  .rows + .rows {
    &::before {
      content: "";
      position: absolute;
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      top: 2px;
      left: 0.5px;
      height: 24px;
      width: 1px;
      background: #cccccc;
    }
  }
}
</style>
