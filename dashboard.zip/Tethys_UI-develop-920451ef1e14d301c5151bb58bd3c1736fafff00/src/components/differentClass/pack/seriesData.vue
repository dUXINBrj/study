<template>
  <div class="comps">
    <div v-for="(item, index) in config.value" :key="index">
      <div class="wrapper">
        <div class="title">数据名称</div>
        <el-input
          v-model="item.name"
          placeholder="请输入内容"
          @input="onChange"
          @change="onChange"
        ></el-input>
      </div>
      <div class="wrapper">
        <div class="title">数据来源</div>
        <el-cascader
          popper-class="rightattr-cascader"
          v-model="item.pointId"
          :props="props"
          clearable
        ></el-cascader>
      </div>
      <div class="wrapper">
        <div class="title">颜色</div>
        <color-picker v-model="item.itemStyle.color" @change="onChange" />
      </div>
      <div class="btn-wrapper">
        <button
          class="btn"
          v-if="index === config.value.length - 1 && index < 14"
          @click="addDate(index)"
        >
          +
        </button>
        <button
          class="btn"
          v-if="config.value.length > 1"
          @click="delData(index, item)"
        >
          del
        </button>
      </div>
      <packLine></packLine>
    </div>
  </div>
</template>

<script>
import packLine from "./line.vue";
const COLOR_ARR = [
  "#3573C1",
  "#E53F3F",
  "#33A566",
  "#F1921C",
  "#34A8C2",
  "#3445C2",
  "#BB4FE1",
  "#B2DDFF",
  "#24252A",
  "#1C3A60",
  "#F6376A",
  "#82C949",
  "#F4B60B",
  "#106B7F",
  "#9C34C2",
  "#323232"
];
export default {
  props: {
    title: String,
    config: Object,
    onChange: Function
  },

  components: {
    packLine
  },

  data() {
    return {
      props: [],
      total: 1,
      curColArr: [...COLOR_ARR]
    };
  },

  created() {
    let self = this;
    self.props = {
      label: "name",
      lazy: true,
      lazyLoad(node, resolve) {
        let { data, root } = node;
        setTimeout(() => {
          let params = [];
          if (!root && data.childNodes) {
            params = data.childNodes;
          } else {
            params = self.$store.state.deviceList || [];
          }
          const nodes = Array.from(params).map(item => ({
            value: item.id,
            name: item.name,
            disabled: item.disabled,
            leaf: !item.children,
            childNodes: item.children
          }));
          resolve(nodes);
        }, 400);
      }
    };

    this.config.value[0].itemStyle.color = this.curColArr[0];
    this.curColArr.splice(0, 1);
  },

  methods: {
    addDate() {
      let obj = {
        name: "默认名称" + (this.total + 1),
        value: 100,
        pointId: [],
        rule: "",
        itemStyle: {
          color: this.curColArr[0]
        }
      };
      this.curColArr.splice(0, 1);
      this.total++;
      this.config.value.push(obj);
      this.onChange();
    },

    delData(index, item) {
      this.config.value.splice(index, 1);
      if (
        COLOR_ARR.includes(item.itemStyle.color) &&
        !this.curColArr.includes(item.itemStyle.color)
      ) {
        this.curColArr.unshift(item.itemStyle.color);
      }
      this.onChange();
    }
  }
};
</script>

<style lang="less" scoped>
.wrapper {
  padding-bottom: 15px;
}
.btn-wrapper {
  display: flex;
  justify-content: flex-end;
  .btn {
    margin-left: 20px;
  }
}
</style>
