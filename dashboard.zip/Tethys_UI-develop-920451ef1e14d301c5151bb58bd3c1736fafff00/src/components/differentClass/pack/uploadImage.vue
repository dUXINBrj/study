<template>
  <div class="comps">
    <div class="title">{{ title }}</div>
    <el-upload
      class="img-uploader"
      :action="uploadUrl"
      :show-file-list="false"
      :on-success="imgSuccess"
      :headers="headerMsg"
      :before-upload="beforeImgUpload"
    >
      <img v-if="backgroundImage" :src="backgroundImage" class="img-preview" />
      <i v-else class="el-icon-plus img-uploader-icon"></i>
      <div class="img-del-icon" v-if="backgroundImage">
        <i class="el-icon-delete" @mousedown="delBgImage($event)"></i>
      </div>
    </el-upload>
    <el-select
      v-model="config.value.fash"
      placeholder="请选择"
      @change="change"
    >
      <el-option label="铺满" value="铺满"></el-option>
      <el-option label="居中" value="居中"></el-option>
      <el-option label="适应图片" value="适应图片"></el-option>
    </el-select>
  </div>
</template>

<script>
export default {
  data() {
    return {
      backgroundImage: this.config.value.imgUrl,
      uploadUrl: window.config.uploadUrl,
      headerMsg: {
        accesstoken: "adcf40f89d4acd38bddb9",
        app: "cloudconfigure",
        ext: ".png"
      },
      img: null,
      width: null,
      height: null
    };
  },
  methods: {
    beforeImgUpload(file) {
      let spl = file.name.split(".");
      this.headerMsg.ext = `.${spl[spl.length - 1]}`;
    },
    change() {
      if (this.config.value.fash === "适应图片") {
        let widthHeight = this.$parent.config["尺寸"];
        if (widthHeight) {
          widthHeight.value = [this.width, this.height];
        }
      }

      this.onChange();
    },
    imgSuccess(res) {
      this.backgroundImage = res.Data;
      this.config.value.imgUrl = res.Data;
      this.img = new Image();
      this.img.src = res.Data;
      this.img.onload = () => {
        this.width = Math.round(this.img.width);
        this.height = Math.round(this.img.height);
        this.onChange();
      };
    },
    delBgImage() {
      this.backgroundImage = "";
      this.config.value.imgUrl = "";
      this.onChange();
    }
  },
  props: {
    title: String,
    config: Object,
    onChange: Function
  }
};
</script>
<style></style>
<style lang="less" scoped>
.img-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}

.img-uploader .el-upload:hover {
  border-color: #409eff;
}

.img-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 150px;
  height: 150px;
  line-height: 150px;
  text-align: center;
}

.comps {
  & /deep/ .el-upload.el-upload--text {
    border: 1px solid hsla(0, 0%, 100%, 0.6);
    background: hsla(0, 0%, 100%, 0.2);
    border-radius: 4px;
    cursor: pointer;
    overflow: hidden;
    text-align: center;
    position: relative;
    width: 150px;
    height: 150px;
    box-sizing: content-box;
    display: flex;
    justify-content: center;
    align-items: center;
    &:hover {
      border-color: #409eff;
    }
    .img-preview {
      box-sizing: content-box;
      max-width: 100%;
      max-height: 100%;
    }
    .img-del-icon {
      position: absolute;
      top: 0px;
      left: 0px;
      right: 0px;
      bottom: 0px;
      display: flex;
      justify-content: center;
      align-items: center;
      opacity: 0;
      background-color: rgba(0, 0, 0, 0.5);
      .el-icon-delete {
        padding: 2px;
        color: #fff;
        height: 24px;
        width: 24px;
      }
      &:hover {
        opacity: 1;
      }
    }
  }
}
</style>
