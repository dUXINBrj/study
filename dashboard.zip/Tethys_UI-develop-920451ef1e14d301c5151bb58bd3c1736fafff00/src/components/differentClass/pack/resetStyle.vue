<template>
  <div class="comps">
    <el-button type="primary" size="small" @click="onChanges">{{
      title
    }}</el-button>
  </div>
</template>

<script>
import { getComp } from "@/util/common.js";
export default {
  props: {
    title: String,
    config: Object,
    onChange: Function
  },
  methods: {
    onChanges() {
      if (this.$drag.vms) {
        let comp = getComp(this.$drag.vms.type).data();
        this.$drag.vms.$refs.comp.resetStyle(comp);
        this.$drag.showMenu(this.$drag.vms);
      }
      this.onChange();
    }
  }
};
</script>
