<template>
  <div>
    <div class="title">{{ title }}</div>
    <el-select v-model="config.value" placeholder="请选择" @change="onChange">
      <el-option
        v-for="item in config.label"
        :key="item.value"
        :label="item.label"
        :value="item.value"
      >
      </el-option>
    </el-select>
  </div>
</template>
<script>
export default {
  props: {
    title: String,
    config: Object,
    onChange: Function
  }
};
</script>
