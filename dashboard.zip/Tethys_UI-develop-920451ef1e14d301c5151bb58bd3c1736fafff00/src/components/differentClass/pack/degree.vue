<template>
  <div class="comps">
    <div class="title">背景图样式</div>
    <el-select v-model="config.imgType" placeholder="请选择" @change="change">
      <el-option label="铺满" value="铺满"></el-option>
      <el-option label="居中" value="居中"></el-option>
      <el-option label="适应图片" value="适应图片"></el-option>
    </el-select>
    <explain style="margin:15px 0" :title="'添加响应'"></explain>
    <el-checkbox v-model="config.sameStatus">统一位号</el-checkbox>
    <div class="bodys" :key="index" v-for="(item, index) in list">
      <el-cascader
        popper-class="rightattr-cascader"
        v-model="item.pointId"
        :props="props"
        clearable
      ></el-cascader>
      <el-select
        v-model="item.sourceValue"
        placeholder="请选择"
        @change="onChange"
      >
        <el-option
          v-for="item in sourceData"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        >
        </el-option>
      </el-select>
      <div class="row rowend">
        <select v-model="item.oper" @change="onChange">
          <option
            v-for="item in operList"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></option>
        </select>
        <input v-model="item.value" />
      </div>
      <p>选择背景图</p>
      <el-upload
        class="img-uploader"
        :action="uploadUrl"
        :show-file-list="false"
        :on-success="
          (response, file, fileList) =>
            imgSuccess(response, file, fileList, item)
        "
        :headers="headerMsg"
        :before-upload="beforeImgUpload"
      >
        <img v-if="item.imgUrl" :src="item.imgUrl" class="img-preview" />
        <i v-else class="el-icon-plus img-uploader-icon"></i>
        <div class="img-del-icon" v-if="item.imgUrl">
          <i class="el-icon-delete" @mousedown="delBgImage(item)"></i>
        </div>
      </el-upload>
      <div class="divFlex">
        <div
          @click="adds(index)"
          v-show="index + 1 === list.length"
          class="add"
        >
          +
        </div>
        <div @click="deletes(index)" v-show="list.length !== 1" class="delete">
          -
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import explain from "./explain.vue";
import { sourceOrigin, operateList } from "./common";
export default {
  components: {
    explain
  },
  props: {
    title: String,
    config: Object,
    onChange: Function
  },
  data() {
    return {
      props: [],
      operList: operateList,
      sourceData: sourceOrigin,
      list: this.config.value || [
        {
          pointId: [],
          sourceValue: "1",
          oper: "",
          value: "",
          imgUrl: ""
        }
      ],
      uploadUrl: window.config.uploadUrl,
      headerMsg: {
        accesstoken: "adcf40f89d4acd38bddb9",
        app: "cloudconfigure",
        ext: ".png"
      },
      img: null,
      width: null,
      height: null
    };
  },
  methods: {
    adds(index) {
      this.list.splice(index + 1, 0, {
        pointId: [],
        sourceValue: "1",
        oper: "",
        value: "",
        imgUrl: ""
      });
      this.config.value = this.list;
    },
    deletes(index) {
      this.list.splice(index, 1);
      this.config.value = this.list;
    },
    beforeImgUpload(file) {
      let spl = file.name.split(".");
      this.headerMsg.ext = `.${spl[spl.length - 1]}`;
    },
    change() {
      if (this.config.imgType === "适应图片") {
        let widthHeight = this.$parent.$parent.baisicConfig["尺寸"];
        if (widthHeight) {
          widthHeight.value = [this.width, this.height];
        }
      }

      this.onChange();
    },
    imgSuccess(res, file, fileList, item) {
      item.imgUrl = res.Data;
      this.config.currentImage = res.Data;
      this.img = new Image();
      this.img.src = res.Data;
      this.img.onload = () => {
        this.width = Math.round(this.img.width);
        this.height = Math.round(this.img.height);
        this.onChange();
      };
    },
    delBgImage(item) {
      this.config.currentImage = "";
      item.imgUrl = "";
      this.onChange();
    }
  },
  created() {
    let self = this;
    self.props = {
      label: "name",
      lazy: true,
      lazyLoad(node, resolve) {
        let { data, root } = node;
        setTimeout(() => {
          let params = [];
          if (!root && data.childNodes) {
            params = data.childNodes;
          } else {
            params = self.$store.state.deviceList || [];
          }
          const nodes = Array.from(params).map(item => ({
            value: item.id,
            name: item.name,
            disabled: item.disabled,
            leaf: !item.children,
            childNodes: item.children
          }));
          resolve(nodes);
        }, 400);
      }
    };
  }
};
</script>
<style lang="less" scoped>
.row {
  padding-top: 5px;
}
.divFlex {
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  align-items: center;
}
.add,
.delete {
  width: 40px;
  font-size: 40px;
  text-align: center;
}
input,
select {
  border-radius: 4px;
  width: calc(100%);
  height: 30px;
  border: none;
  font-size: 12px;
  box-sizing: border-box;
  width: 40px;
}
select + input {
  margin-left: 10px;
}
input {
  margin-right: 5px;
}
.img-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}

.img-uploader .el-upload:hover {
  border-color: #409eff;
}

.img-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 150px;
  height: 150px;
  line-height: 150px;
  text-align: center;
}

.comps {
  & /deep/ .el-upload.el-upload--text {
    border: 1px solid hsla(0, 0%, 100%, 0.6);
    background: hsla(0, 0%, 100%, 0.2);
    border-radius: 4px;
    cursor: pointer;
    overflow: hidden;
    text-align: center;
    position: relative;
    width: 150px;
    height: 150px;
    box-sizing: content-box;
    display: flex;
    justify-content: center;
    align-items: center;
    &:hover {
      border-color: #409eff;
    }
    .img-preview {
      box-sizing: content-box;
      max-width: 100%;
      max-height: 100%;
    }
    .img-del-icon {
      position: absolute;
      top: 0px;
      left: 0px;
      right: 0px;
      bottom: 0px;
      display: flex;
      justify-content: center;
      align-items: center;
      opacity: 0;
      background-color: rgba(0, 0, 0, 0.5);
      .el-icon-delete {
        padding: 2px;
        color: #fff;
        height: 24px;
        width: 24px;
      }
      &:hover {
        opacity: 1;
      }
    }
  }
}
</style>
