<template>
  <div class="comps">
    <div class="title">{{ title }}</div>
    <div class="body">
      <el-slider
        ref="slider"
        v-model="config.value"
        :min="config.range[0]"
        :max="config.range[1]"
        @change="onChange"
        @input="onChange"
        :show-input="config.status === 1"
      ></el-slider>
      <template v-if="config.status !== 1">
        <span class="demonstration">{{ config.value + "px" }}</span>
      </template>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    title: String,
    config: Object,
    onChange: Function
  },
  data() {
    return {
      num: this.config.value
    };
  },
  methods: {
    onChanges() {
      this.config.value = parseInt(this.num || 0);
      this.onChange();
    }
  }
};
</script>
<style lang="less" scoped>
.body {
  paddint-left: 12px;
}
</style>
