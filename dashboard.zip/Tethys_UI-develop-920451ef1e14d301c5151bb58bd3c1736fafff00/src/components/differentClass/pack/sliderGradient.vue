<template>
  <div class="comps">
    <div class="title">
      <span>{{ title }}</span>
      <el-checkbox
        v-show="config.note"
        v-model="config.hidden"
        @change="onChange"
        >{{ config.note }}</el-checkbox
      >
    </div>
    <div v-show="config.hidden">
      <div>
        <color-picker v-model="color1" @change="setColor" />
      </div>
      <div class="titles">
        <span>{{ title }}</span>
      </div>
      <div class="body">
        <el-slider
          ref="slider"
          v-model="config.value[1]"
          :min="config.range[0]"
          :max="config.range[1]"
          @change="onChange"
          @input="onChange"
        ></el-slider>
        <span class="demonstration">{{ config.value[1] }}</span>
      </div>
    </div>
  </div>
</template>

<script>
import { predefineColors } from "./common";
export default {
  props: {
    title: String,
    config: Object,
    onChange: Function
  },
  data() {
    return {
      color1: "",
      predefineColors: predefineColors
    };
  },
  methods: {
    setColor() {
      this.config.value[0] = this.color1;
      this.onChange();
    }
  }
};
</script>
<style lang="less" scoped>
.titles {
  margin-top: 10px;
}
</style>
