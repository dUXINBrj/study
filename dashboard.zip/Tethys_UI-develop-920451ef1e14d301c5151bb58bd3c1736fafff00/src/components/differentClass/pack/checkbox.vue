<template>
  <div class="comps">
    <div class="title">
      <span>{{ title }}</span
      ><el-checkbox v-model="config.value" @change="onChange">{{
        config.note
      }}</el-checkbox>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    title: String,
    config: Object,
    onChange: Function
  }
};
</script>
