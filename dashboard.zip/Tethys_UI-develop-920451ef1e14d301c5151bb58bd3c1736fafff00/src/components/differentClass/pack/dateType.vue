<template>
  <div class="comps">
    <el-button type="primary" size="small">dateType</el-button>
  </div>
</template>

<script>
export default {
  props: {
    title: String,
    config: Object,
    onChange: Function
  }
};
</script>
