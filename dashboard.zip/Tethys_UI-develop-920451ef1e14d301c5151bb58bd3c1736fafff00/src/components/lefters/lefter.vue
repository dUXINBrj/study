<template>
  <div class="lefter" :style="wholeStyle">
    <leftRoutes class="routes" ref="routes"></leftRoutes>
    <div class="spaceLine" :style="lineStyle"></div>
    <leftPages class="pages" ref="pages"></leftPages>
  </div>
</template>

<script>
import leftRoutes from "./routes";
import leftPages from "./pages";
export default {
  props: {
    config: Object
  },
  components: {
    leftRoutes,
    leftPages
  },
  data() {
    return {
      wholeStyle: {},
      lineStyle: {}
    };
  },
  methods: {
    selectPage(item) {
      this.$refs.pages.selectPage(item);
    },
    //初始化样式
    initStyle() {
      this.lineStyle = {
        background: this.config["其他样式"][1]
      };
      this.wholeStyle = {
        background: this.config["背景色"].value,
        boxShadow: this.config["边框发光色"].value + " 0px 0px 10px 0px inset"
      };
      this.$refs.routes.initStyle();
      this.$refs.pages.initStyle();
    },
    clearDialog() {
      this.$refs.routes.clearDialog();
      this.$refs.pages.clearDialog();
    }
  }
};
</script>

<style lang="less" scoped>
.lefter {
  background: rgb(36, 37, 42);
  display: flex;
  flex-direction: column;
  padding: 8px 4px;
  box-sizing: border-box;
  position: relative;
  .routes {
    position: relative;
    height: calc(50% - 3px);
    width: calc(100% - 4px);
  }
  .pages {
    width: calc(100%);
    height: calc(50%);
  }
  .spaceLine {
    width: calc(100%);
    height: 3px;
  }
}
</style>
