<template>
  <div
    :class="locked ? 'locked rightTab' : 'rightTab'"
    :style="{ width: `${showPropertyMenu ? 300 : 0}px` }"
  >
    <span
      @mousedown.stop="toggleMenu"
      :class="[
        'iconfont',
        `${showPropertyMenu ? 'iconzhankai' : 'iconshouqi'}`,
        'toggleicon'
      ]"
    ></span>
    <div class="body">
      <div class="component" v-show="showPropertyMenu">
        <compCommon ref="type66" v-show="currentClass === 66"></compCommon>
        <compBase ref="type0" v-show="currentClass === 0"></compBase>
        <compMap ref="type1" v-show="currentClass === 1"></compMap>
        <compSub ref="type2" v-show="currentClass === 2"></compSub>
        <compHigh ref="type3" v-show="currentClass === 3"></compHigh>
        <compSpec ref="type4" v-show="currentClass === 4"></compSpec>
        <compSystem ref="type6" v-show="currentClass === 5"></compSystem>
      </div>
    </div>
    <div class="menu">
      <div
        @mousedown.stop="
          currentClass = index;
          showPropertyMenu = true;
        "
        :class="currentClass === index ? 'active menuItem' : 'menuItem'"
        v-for="(item, index) in list"
        :key="item.name + index"
      >
        <div>
          <span :class="'iconfont ' + item.icon"></span>
        </div>
        <div class="title">{{ item.name }}</div>
      </div>
      <div style="margin-top:250px;"></div>
      <div
        @mousedown.stop="deal(item)"
        class="menuItem"
        v-for="(item, index) in otherList"
        :key="item.name + index"
      >
        <div>
          <span :class="'iconfont ' + item.icon"></span>
        </div>
        <div class="title">{{ item.name }}</div>
      </div>
    </div>
  </div>
</template>

<script>
import { setConfig } from "@/api/server.js";
import compCommon from "./differentClass/common";
import compBase from "./differentClass/base";
import compHigh from "./differentClass/high";
import compMap from "./differentClass/map";
import compSpec from "./differentClass/spec";
import compSub from "./differentClass/sub";
import compSystem from "./differentClass/system";
export default {
  components: {
    compBase,
    compHigh,
    compSub,
    compSpec,
    compMap,
    compCommon,
    compSystem
  },
  data() {
    return {
      treeConfig: new Map(),
      locked: false,
      currentClass: 66,
      currentVm: null,
      list: [
        {
          name: "基本",
          icon: "iconjiben"
        },
        {
          name: "图库",
          icon: "icontuku"
        },
        {
          name: "组件",
          icon: "iconzujian"
        },
        {
          name: "高级",
          icon: "icongaoji"
        },
        {
          name: "专业",
          icon: "iconzhuanye"
        },
        {
          name: "系统",
          icon: "iconxitong"
        }
      ],
      otherList: [
        {
          name: "同步",
          icon: "icontongbu"
        },
        {
          name: "保存",
          icon: "iconbaocun"
        },
        {
          name: "运行",
          icon: "iconyunxing"
        }
      ],
      showPropertyMenu: true
    };
  },
  methods: {
    showMenu(vm) {
      this.currentClass = vm.classes;
      // this.showPropertyMenu = true;
      let target = this.$refs["type" + this.currentClass];

      if (this.currentVm && this.currentVm.type === "树形关联图") {
        let comp = this.currentVm.$refs.comp;
        if (comp) {
          comp.currentItem = null;
          comp.highConfig["树形图"] = {
            type: "treeConfig",
            currentItem: "",
            pointIds: [],
            statisticsType: ""
          };
        }
      }
      if (target.$refs.compConfig) {
        if (this.currentVm !== vm) {
          target.$refs.compConfig.currentType = "basic";
        }

        target.$refs.compConfig.baisicConfig = null;
        target.$refs.compConfig.highConfig = null;
      }
      this.currentVm = vm;
      if (vm.$refs && vm.$refs.comp) {
        this.$nextTick(() => {
          target.$refs.compConfig.baisicConfig = vm.$refs.comp.baisicConfig;
          target.$refs.compConfig.highConfig = vm.$refs.comp.highConfig;
          target.$refs.compConfig.currentComp = vm.$refs.comp;
        });
      }
    },
    //获取树的配置
    getTreeConfigList() {
      let configs = [];
      // eslint-disable-next-line no-unused-vars
      for (let [key, value] of this.treeConfig) {
        let config = value;
        if (!config) {
          config = this.$drag.treeConfigs.find(item => {
            return item.id === config.id;
          });
        }
        configs.push(config);
      }
      console.log(configs);
      return JSON.stringify(configs);
    },
    getCompConfig(comp) {
      if (comp.type === "compose") {
        return {
          ...comp.getConfig(),
          _linkComp: null
        };
      } else if (comp.type === "container") {
        return comp.getConfig();
      } else if (comp.type === "树形关联图") {
        let treeConfig = {
          ...comp.$data,
          currentComp: null,
          compConfig: {
            ...comp.$refs.comp.$data,
            currentItem: null,
            highConfig: {
              树形图: {
                type: "treeConfig",
                currentItem: "",
                pointIds: [],
                statisticsType: ""
              }
            }
          }
        };
        if (!this.treeConfig.get(treeConfig.id)) {
          this.treeConfig.set(treeConfig.id, treeConfig);
        }
        return {
          id: treeConfig.id,
          type: treeConfig.type
        };
      }
      return {
        ...comp.$data,
        currentComp: null,
        compConfig: comp.$refs.comp ? comp.$refs.comp.$data : comp.$data
      };
    },
    deal(item) {
      let left, centerConfigs, newConfigs, config;
      switch (item.name) {
        case "运行":
          window.open(`http://${this.$drag.$vm.query.domain}/#/project/list`);
          // window.open(`http://10.125.23.158:18088/#/project/list`);
          break;
        case "保存":
          left = this.$drag.$left;
          centerConfigs = this.$drag.centerConfigs;
          newConfigs = {};
          for (let key in centerConfigs) {
            let val = centerConfigs[key];
            let comps = val.comps;
            let _compConfigs = val.compConfigs;
            if (val.loaded) {
              _compConfigs = comps.map(item => {
                return this.getCompConfig(item);
              });
            } else {
              _compConfigs = _compConfigs.map(item => {
                if (item.type === "树形关联图") {
                  if (!this.treeConfig.get(item.id)) {
                    this.treeConfig.set(item.id, null);
                  }
                }
                return item;
              });
            }
            newConfigs[key] = JSON.stringify({
              zIndex: val.zIndex,
              compConfigs: _compConfigs,
              comps: []
            });
          }
          config = {
            pid: this.$drag.$vm.query.subProjectId,
            version: 1,
            stylesConfig: this.$store.state.config.stylesConfig,
            routeConfig: {
              currentSelectRoute: left.$refs.routes.currentSelectRoute,
              currentSelectChildrenRoute:
                left.$refs.routes.currentSelectChildrenRoute,
              routes: left.$refs.routes.routes,
              pages: left.$refs.pages.pages
            },
            centerConfigs: newConfigs,
            treeConfigList: this.getTreeConfigList()
          };
          setConfig(config).then(() => {
            this.$message({
              type: "success",
              message: "保存成功"
            });
          });
          break;

        default:
          break;
      }
    },
    toggleMenu() {
      this.showPropertyMenu = !this.showPropertyMenu;
    }
  }
};
</script>

<style lang="less" scoped>
.rightTab {
  display: flex;
  flex-direction: row;
  transition: right 0.3s;
  position: relative;
  .toggleicon {
    position: absolute;
    left: -29px;
    bottom: 30px;
    background: #373e4a;
    padding: 5px;
    color: rgb(183, 192, 205);
  }
  &.locked {
    right: -300px !important;
  }

  .icons {
    height: 30px;
    width: 30px;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #777e8a;
    margin-top: 700px;
    .iconfont {
      font-size: 20px;
    }
    background: #373e4a;
  }
  .body {
    width: 240px;
    height: calc(100%);
    color: #e9e9e9;
    box-shadow: 0px 3px 8px 0px rgba(0, 0, 0, 0.7);
    background-color: #373e4a;
    position: relative;

    .component {
      height: calc(100%);
      // margin: 0 10px 0 0 ;
    }
    .shows {
      position: absolute;
      top: 0px;
      right: -240px;
      transition: right 0.2s ease;
      &.active {
        right: 0px;
      }
    }
  }
  .menu {
    z-index: 1;
    width: 60px;
    background: #23272e;
    .menuItem {
      cursor: pointer;
      box-sizing: border-box;
      height: 60px;
      height: 60px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      color: #777e8a;
      font-size: 12px;
      .title {
        margin-top: 6px;
      }
      &:hover {
        background: rgb(17, 19, 20);
      }
      &.active {
        background: rgb(0, 100, 255);
        color: rgb(255, 255, 255);
      }
    }
  }
}
</style>
