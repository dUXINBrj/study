<template>
  <div class="header" :style="bodyStyle">
    <div class="left" v-show="logoVisible || subVisible">
      <img v-show="logoVisible" :src="logoUrl" />
      <span v-show="subVisible" :style="subStyle">{{ subtitle }}</span>
    </div>
    <div class="center" :style="titleLocation">
      <div :data-content="title" :style="titleStyle">{{ title }}</div>
    </div>
    <div class="right">
      <div v-show="config['天气'].value[4]" :style="skyStyle" class="weather">
        <i
          :style="{ marginRight: '10px', fontSize: weatherImgSize + 'px' }"
          class="iconfont iconqingtian"
        ></i>
        <span>晴 24°C~35°C 东风 2级 1970-01-01 星期三 {{ city }}</span>
      </div>
      <div v-show="config['运行时间'].value" class="runtime">
        安全运行99天9时9分9秒
      </div>
      <Screenfull class="hover-effect" />
      <div class="icon messege">
        <el-badge is-dot class="item"
          ><span class="iconfont iconxiaoxi"></span
        ></el-badge>
      </div>
      <el-dropdown
        @command="handleCommand"
        trigger="click"
        placement="bottom-end"
      >
        <div class="icon el-dropdown-link cirle-box">
          <span class="iconfont iconmorentouxiang"></span>
        </div>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item style="width:82px;" command="1"
            ><span class="iconfont iconwode1" style="margin-right: 4px;"></span
            >{{ loginName }}</el-dropdown-item
          >
          <el-dropdown-item style="width:82px" command="2"
            ><span class="iconfont iconjiben" style="margin-right: 4px;"></span
            >项目列表</el-dropdown-item
          >
          <el-dropdown-item style="width:80px" command="3" divided
            ><span class="iconfont iconRight" style="margin-right: 4px;"></span
            >退出</el-dropdown-item
          >
        </el-dropdown-menu>
      </el-dropdown>
    </div>
  </div>
</template>

<script>
import logo from "@/assets/image/chnt-b.svg";
import { packFont } from "@/util/common.js";
import Screenfull from "../component/screenfull/index";
import { getUser, clear } from "../util/localStorage";
export default {
  components: {
    Screenfull
  },
  props: {
    config: Object
  },
  data() {
    return {
      bodyStyle: {},
      logoUrl: "",
      logoVisible: true,
      subVisible: true,
      title: "",
      titleStyle: {},
      titleLocation: {},
      subtitle: "",
      subStyle: {},
      skyStyle: {},
      weatherImgSize: 21,
      city: "上海",
      loginName: ""
    };
  },
  created() {
    this.initStyle();
    this.loginName = getUser().admin.loginName;
  },
  methods: {
    initStyle(order) {
      console.log(order);
      this.skyStyle = this.config["天气"].value[4]
        ? packFont(this.config["天气"].value)
        : {};
      if (this.skyStyle && this.skyStyle.fontSize) {
        this.weatherImgSize =
          Number(this.skyStyle.fontSize.substring(0, 2)) + 7;
      }
      this.title = this.config["标题"].value[0];
      if (typeof this.config["天气"].value[1] !== "string") {
        let city = this.config["天气"].value[1];
        this.city = city[city.length - 1];
      } else {
        this.city = this.config["天气"].value[1];
      }
      let textShadows = !this.config["标题阴影"].value[4]
        ? {
            "--left": "0px",
            "--top": "0px"
          }
        : {
            "--left": this.config["标题阴影"].value.slice(1)[1],
            "--top": this.config["标题阴影"].value.slice(1)[0]
          };
      let sliderGradient =
        !this.config["标题渐变色"].hidden || !this.config["标题渐变色"].value[0]
          ? {}
          : {
              color: "transparent",
              backgroundImage: `linear-gradient(${this.config["标题渐变色"].value[1]}deg,${this.config["标题"].value[4]}, ${this.config["标题渐变色"].value[0]})`
            };

      this.titleLocation = {
        justifyContent: this.config["标题位置"].value
      };
      this.titleStyle = Object.assign(
        packFont(this.config["标题"].value.slice(1)),
        sliderGradient,
        textShadows
      );
      this.logoUrl = this.config["Logo"].value[0] || logo;
      this.logoVisible = this.config["Logo"].value[2];
      this.subVisible = this.config["副标题"].value[5];
      this.subtitle = this.config["副标题"].value[0];
      this.subStyle = packFont(this.config["副标题"].value.slice(1));
      this.bodyStyle = {
        background: this.config["背景色"].value,
        boxShadow: this.config["边框发光色"].value + " 0px 0px 10px 0px inset"
      };
    },
    handleCommand(command) {
      if (command == "2") {
        this.onProjectList();
      } else if (command == "3") {
        this.onLogout();
      }
    },
    onProjectList() {
      this.$confirm("是否确定返回项目列表页?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          // 跳转到项目列表页面
          this.$router.replace("/ProjectList");
        })
        .catch(() => {});
    },
    onLogout() {
      this.$confirm("是否确定退出系统?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$message({
            type: "success",
            message: "退出成功!"
          });
          clear();
          // 跳转到登录页面
          this.$router.replace("/Login");
        })
        .catch(() => {});
    }
  }
};
</script>
<style lang="less" scoped>
.header {
  color: white;
  display: flex;
  width: calc(100%);
  flex-direction: row;
  .left {
    width: 200px;
    height: calc(100%);
    display: flex;
    flex-direction: column;
    text-align: center;
    justify-content: center;
    img {
      height: 22px;
      padding-bottom: 5px;
    }
  }
  .right {
    min-width: 200px;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-end;
    font-size: 14px;
    margin-right: 20px;
    .weather {
      margin-right: 30px;
      display: flex;
      align-items: center;
    }
    .runtime {
      margin-right: 30px;
    }
    .icon {
      /deep/.el-badge__content {
        background-color: #e6a23c;
      }
      .iconxiaoxi {
        font-size: 20px;
        &:hover {
          color: #3573c1;
        }
      }
    }
    .cirle-box {
      background-color: #18191d;
      width: 34px;
      height: 34px;
      line-height: 34px;
      border-radius: 50%;
      color: #fff;
      font-size: 16px;
      text-align: center;
      cursor: pointer;
      .iconmorentouxiang {
        &:hover {
          color: #3573c1;
        }
      }
    }
    .messege {
      margin-right: 30px;
    }
  }
  .center {
    flex: 1;
    height: calc(100%);
    position: relative;
    display: flex;
    align-items: center;
    padding-left: 25px;
    div {
      -webkit-background-clip: text;
      height: auto;
      position: relative;
      width: fit-content;
      &::after {
        height: inherit;
        width: inherit;
        content: " " attr(data-content) "";
        left: var(--left);
        top: var(--top);
        background-image: inherit;
        background-clip: inherit;
        position: absolute;
        opacity: 0.5;
        color: transparent;
      }
    }
  }
}
</style>
