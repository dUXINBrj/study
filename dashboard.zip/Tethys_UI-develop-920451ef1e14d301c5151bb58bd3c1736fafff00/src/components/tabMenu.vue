<template>
  <div class="tabMenu" :style="wholeStyle">
    <div class="lefts" :style="leftStyle">
      <span
        @mousedown.stop="hideLeft"
        :class="['iconfont ', isHideLeft ? 'iconzhankai' : 'iconshouqi']"
      ></span>
    </div>
    <div class="rights">
      <div class="left" v-if="level1">{{ level2 ? level2 : level1 }}</div>
      <div class="right" v-if="level1">
        <span :class="['iconfont', routeIcon]"></span>
        <span class="line">/</span>
        <span class="title wrapper">{{ level1 }}</span>
        <template v-if="level2">
          <span class="line">/</span>
          <span class="title wrapper">{{ level2 }}</span>
        </template>
      </div>
    </div>
  </div>
</template>
<script>
import { packFont } from "@/util/common.js";
export default {
  props: {
    config: Object
  },
  data() {
    return {
      fontStyle: {},
      wholeStyle: {},
      leftStyle: {},
      level1: "",
      level2: "",
      isHideLeft: false,
      routeIcon: ""
    };
  },
  methods: {
    updateTitle(level1, level2, icon) {
      this.level1 = level1;
      this.level2 = level2;
      this.routeIcon = icon;
    },
    initStyle() {
      this.fontStyle = packFont(this.config["字体样式"].value);
      this.wholeStyle = {
        background: this.config["背景色"].value,
        color: this.fontStyle.color,
        borderBottom: `1px solid ${this.config["其他样式"][0]}`
      };
      this.leftStyle = {
        borderRight: `1px solid ${this.config["其他样式"][0]}`
      };
    },
    hideLeft() {
      this.$parent.toggLeft();
      this.isHideLeft = !this.isHideLeft;
    }
  }
};
</script>
<style lang="less" scoped>
.tabMenu {
  background-color: rgb(36, 37, 42);
  color: rgb(183, 192, 205);
  display: flex;
  flex-direction: row;
  .lefts {
    width: 200px;
    height: calc(100%);
    box-sizing: border-box;
    display: flex;
    align-items: center;
    span {
      margin-left: 20px;
    }
  }
  .rights {
    flex: 1;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    .left {
      height: calc(100%);
      line-height: 43px;
      font-size: 15px;
      padding: 0 22px;
      border-bottom: 2px solid #3573c1;
    }
    .right {
      padding-right: 20px;
      display: flex;
      align-items: center;
      .title {
        max-width: 150px;
        display: inline-block;
      }
      .line {
        display: inline-block;
        margin: 0 9px;
        font-weight: 700;
      }
    }
  }
}
</style>
