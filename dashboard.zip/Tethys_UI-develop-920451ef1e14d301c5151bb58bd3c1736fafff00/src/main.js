import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import "@/util/axios";
import "@/util/comp.js";
import Grag from "@/util/drag.js";
import "@/assets/css/common.less";
import "./util/permission";
import ColorPicker from "@/components/ColorPicker/index.vue";
Vue.component("ColorPicker", ColorPicker);

document.documentElement.addEventListener("contextmenu", ev => {
  ev.preventDefault();
});

import ElementUI from "element-ui";
import "element-ui/lib/theme-chalk/index.css";
Vue.use(ElementUI);
Vue.prototype.$drag = new Grag();

window.config = {};

if (window.location.host.indexOf(":18080") !== -1) {
  window.config = {
    requestUrl: "https://dev-gateway.chintcloud.net/common/api/v2.0/visual/api",
    dataCenterUrl:
      "https://dev-gateway.chintcloud.net/common/api/v2.0/visual/api",
    uploadUrl: "http://ufs.cloud.techsel.net/uploadfile"
  };
  // window.config = {
  //   requestUrl: "http://cloudconfigserver.cloud.techsel.net/api",
  //   dataCenterUrl: "http://configcenterapi.cloud.techsel.net/api",
  //   uploadUrl: "http://ufs.cloud.techsel.net/uploadfile"
  // };
} else if (window.location.host.startsWith("dev-tethys")) {
  window.config = {
    requestUrl: "https://dev-gateway.chintcloud.net/common/api/v2.0/visual/api",
    dataCenterUrl:
      "https://dev-gateway.chintcloud.net/common/api/v2.0/visual/api",
    uploadUrl: "http://ufs.cloud.techsel.net/uploadfile"
  };
} else if (window.location.host.startsWith("test-tethys")) {
  window.config = {
    requestUrl:
      "https://test-gateway.chintcloud.net/common/api/v2.0/visual/api",
    dataCenterUrl:
      "https://test-gateway.chintcloud.net/common/api/v2.0/visual/api",
    uploadUrl: "http://ufs.cloud.techsel.net/uploadfile"
    // runtimeUrl: "http://test-gateway-runtime.chintcloud.net/#/home"
  };
} else if (window.location.host.startsWith("tethys")) {
  window.config = {
    requestUrl: "http://gateway.chint.com/common/api/v2.0/visual/api",
    dataCenterUrl: "http://gateway.chint.com/common/api/v2.0/visual/api",
    uploadUrl: "http://ufs.cloud.techsel.net/uploadfile"
    // runtimeUrl: "http://gateway-runtime.chint.com/#/home"
  };
}

Vue.config.productionTip = false;

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount("#app");
