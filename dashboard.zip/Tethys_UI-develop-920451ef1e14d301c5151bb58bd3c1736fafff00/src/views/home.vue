<template>
  <div
    class="home"
    :style="wholeStyle"
    @contextmenu.prevent.stop="showContextMenu"
  >
    <template v-for="page in pageList">
      <template v-if="page.type === 'multi' && page.origin === 'local'">
        <div
          class="multi"
          :key="page.linkPage"
          :id="'page-' + page.linkPage"
          :style="{
            display: page.linkPage === linkPageId ? '' : 'none'
          }"
        >
          <div class="tabs">
            <div
              :key="item.id"
              :class="
                mulLinkPageId === item.id
                  ? 'tab wrapper backColor active'
                  : 'tab backColor wrapper'
              "
              v-for="(item, index) in page.pages"
            >
              <input
                @mousedown.stop="selectMul(page.pages, item)"
                class="noBorder backColor colorWhiteBlack"
                type="text"
                v-model="item.name"
              />
              <i
                v-show="index"
                @mousedown.stop="deleteMulPage(page.pages, item, index)"
                class="el-icon-circle-close colorWhiteBlack"
              ></i>
            </div>
            <div class="add colorWhiteBlack">
              <i @mousedown.stop="addMul(page.pages)" class="el-icon-plus"></i>
            </div>
          </div>
          <div class="content" :style="otherStyle">
            <div
              v-for="item in page.pages"
              :key="item.id"
              :id="'page-' + item.id"
              class="dragDiv dragss"
              :style="{
                display: item.id === mulLinkPageId ? '' : 'none',
                ...styles,
                height: `${parseInt(styles.height.slice(0, -2)) - 50}px`
              }"
            ></div>
          </div>
        </div>
      </template>
      <template v-else>
        <div
          class="single"
          :key="page.linkPage"
          :style="{
            display: page.linkPage === linkPageId ? '' : 'none',
            ...otherStyle
          }"
        >
          <div
            :id="'page-' + page.linkPage"
            class="dragDiv dragss"
            :style="styles"
          >
            <UserManage v-if="linkPageId === '用户管理'"></UserManage>
            <LogManage v-if="linkPageId === '操作日志'"></LogManage>
          </div>
        </div>
      </template>
    </template>
    <div class="content" :style="otherStyle" v-if="!linkPageId">
      <div class="dragDiv dragss" :style="styles">
        <div class="views">请选择组态页面</div>
      </div>
    </div>
    <compContextmenu ref="contextmenu"></compContextmenu>
    <compMark ref="compMark"></compMark>
  </div>
</template>
<script>
import LogManage from "@/system/LogManage.vue";
import UserManage from "@/system/UserManage.vue";
import compContextmenu from "@/components/contextmenu.vue";
import compMark from "@/components/mark.vue";
import { getPointsData, getConfig } from "@/api/server.js";
import { getTree } from "@/api/server.js";
import { guid } from "@/util/common.js";
export default {
  components: {
    compContextmenu,
    compMark,
    LogManage,
    UserManage
  },
  inject: ["reload"],
  data() {
    return {
      query: this.$route.query,
      config: null,
      styles: {},
      wholeStyle: {},
      otherStyle: {},
      pageList: [],
      multPages: [],
      linkPageId: null,
      mulLinkPageId: null
    };
  },
  beforeDestroy() {
    this.$drag.destory();
  },
  created() {
    this.initStyle();
    if (!this.$store.state.loadData) {
      this.$store.dispatch("setLoadData", true);
      getConfig({ pid: this.query.subProjectId }).then(res => {
        if (res.data) {
          let centerConfigs = res.data.centerConfigs;
          for (let key in centerConfigs) {
            centerConfigs[key] = JSON.parse(centerConfigs[key]);
          }
          console.log(centerConfigs);
          this.$store.dispatch("setConfig", res.data);
          this.reload();
        }
      });
      getPointsData().then(res => {
        this.$store.dispatch("setPointGroup", res.body);
      });
      getTree({
        projectId: this.query.projectId
      }).then(res => {
        this.$store.dispatch("setDeviceList", res.data);
      });
    } else {
      this.$store.dispatch("setLoadData", false);
    }
  },
  mounted() {
    this.$drag.init(this);
  },
  methods: {
    //显示右击菜单
    showContextMenu() {
      this.$drag.showContextmenu();
    },
    //初始化多页面
    initMulPages(pages) {
      this.multPages = pages;
    },
    //添加多页面
    addMul(pages) {
      this.multPages = pages;
      this.multPages.push({
        id: guid(),
        name: "新增页面-" + this.multPages.length
      });
    },
    //删除多页面
    deleteMulPage(pages, item, index) {
      this.multPages = pages;
      this.multPages.splice(index, 1);
      if (this.mulLinkPageId === item.id) {
        this.selectMul(this.multPages, this.multPages[0]);
      }
      this.$drag.deletePage(item.id, item);
    },
    //选择多页面页签
    selectMul(pages, item) {
      this.multPages = pages;
      if (this.mulLinkPageId === item.id) return;
      this.mulLinkPageId = item.id;
      this.$drag.currentPageId = item.id;
      this.$drag.loadmulLocal(item.id);
    },
    //更新样式
    initStyle() {
      this.config = this.$parent.config.centerConfig;
      let top = this.$parent.mainTop + 4 + this.config["外边距"].value * 2;
      let left = 200;
      this.styles = {
        height: this.config["页面大小(非数字则无效)"].value[1] - top + "px",
        width:
          this.config["页面大小(非数字则无效)"].value[0] -
          left -
          this.config["外边距"].value * 2 +
          "px",
        backgroundImage: `radial-gradient(circle, ${this.config["栅格色"].value} 20%, transparent 10%)`
      };
      this.otherStyle = {
        padding: this.config["外边距"].value + "px"
      };
      this.wholeStyle = {
        background: this.config["背景色"].value
      };
    }
  }
};
</script>

<style lang="less" scoped>
.noBorder {
  height: 34px;
  line-height: 34px;
  cursor: pointer;
  width: inherit;
  border: 0px;
  font-size: 14px;
  box-sizing: border-box;
  padding: 0;
  text-align: center;
}
.home {
  height: calc(100%);
  width: calc(100%);
  background: rgb(43, 46, 55);
  box-sizing: border-box;
  overflow: overlay;
  position: relative;
  .multi,
  .single {
    height: 100%;
    width: 100%;
    .tabs {
      height: 50px;
      padding: 0 15px;
      display: flex;
      flex-direction: row;
      justify-content: flex-start;
      align-items: flex-end;
      .add {
        cursor: pointer;
        height: 34px;
        width: 50px;
        line-height: 34px;
        text-align: center;
        font-weight: 700;
        border-radius: 50%;
      }
      .tab {
        height: 34px;
        border-radius: 2px;
        text-align: center;
        width: 130px;
        box-sizing: border-box;
        position: relative;
        &.active {
          color: white;
          background: #3573c1;
          input {
            color: white;
            background: #3573c1;
          }
        }
        .el-icon-circle-close {
          cursor: pointer;
          position: absolute;
          right: 10px;
          top: calc(50% - 8px);
        }
      }
    }
  }
  &::-webkit-scrollbar {
    width: 4px;
    height: 4px;
  }
  &::-webkit-scrollbar-thumb {
    background: #e3e3e3;
    border-radius: 4px;
  }
  &::-webkit-scrollbar-resizer {
    background: #ff0bee;
  }
  .dragDiv {
    overflow: hidden;
    background-size: 10px 10px;
    box-sizing: border-box;
    border: 2px dashed rgba(230, 162, 60, 0.5);
    position: relative;
    .views {
      width: 100%;
      height: 100%;
      background-size: 10px 10px;
      position: relative;
      color: #e6a23c;
      font-size: 35px;
      text-align: center;
      position: relative;
      top: 20%;
    }
  }
}
</style>
