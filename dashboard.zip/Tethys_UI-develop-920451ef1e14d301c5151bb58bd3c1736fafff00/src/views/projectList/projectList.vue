<template>
  <div class="box">
    <div class="top">
      <span>{{ organizeName }}云组态中心</span>
      <div class="rightinfo">
        <Screenfull class="right-menu-item hover-effect" />
        <i class="el-icon-user"></i>
        <div class="loginName">{{ loginName }}</div>
        <el-button icon="el-icon-switch-button" @click="onLogout"></el-button>
      </div>
    </div>
    <div class="content">
      <div class="search">
        <el-input
          placeholder="搜索项目名称"
          style="width:413px;height:42px;"
          v-model="searchKey"
          clearable
          @clear="search"
        />
        <el-button
          class="searchBtn"
          type="primary"
          icon="el-icon-search"
          @click="search"
          >搜索</el-button
        >
      </div>
      <div class="ptable">
        <el-table :data="tableData" @row-click="clickProjectList" height="100%">
          <el-table-column
            prop="projectName"
            label="项目名称"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="subProjectName"
            label="应用名称"
            align="center"
          >
          </el-table-column>
        </el-table>
      </div>
      <el-pagination
        style="float:right;margin-right: 80px;margin-top: 30px;"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="pagination.currentPage"
        :page-sizes="[5, 10, 100, 200, 500]"
        :page-size="pagination.pageSize"
        background
        layout="total, sizes, prev, pager, next, jumper"
        :total="pagination.totalItems"
      ></el-pagination>
    </div>
  </div>
</template>
<script>
import Screenfull from "./screenFull";
import { clear } from "@/util/localStorage.js";
import { getProjectList } from "../../api/usermanage.js";
export default {
  name: "ProjectList",
  components: {
    Screenfull
  },
  data() {
    return {
      tableData: [],
      loginName: "",
      organizeName: "", //标题
      searchKey: "", //搜索框绑定的值
      pagination: {
        currentPage: 1,
        pageSize: 10,
        totalItems: 1,
        totalPages: 1
      }
    };
  },
  created() {
    this.getProjectList();
  },
  mounted() {},
  computed: {},
  methods: {
    async getProjectList() {
      //获取项目列表
      let params = {
        projectTypeId: "",
        key: this.searchKey,
        pageIndex: this.pagination.currentPage,
        pageSize: this.pagination.pageSize,
        time: "",
        order: "",
        where: ""
      };
      let res = await getProjectList(params);
      let { currentPage, pageSize, totalItems, totalPages, items } = res.data;
      this.tableData = items;
      this.pagination = {
        currentPage,
        pageSize,
        totalItems,
        totalPages
      };
    },
    handleEdit(index, row) {
      console.log(index, row);
    },
    search() {
      this.getProjectList();
    },
    //项目列表条目点击事件
    clickProjectList(row) {
      this.$router.replace({
        name: "home",
        query: {
          projectId: row.projectId,
          subProjectId: row.subProjectId,
          domain: row.domain
        }
      });
    },
    onLogout() {
      this.$confirm("是否确定退出系统?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$message({
            type: "success",
            message: "退出成功!"
          });
          clear();
          // 跳转到登录页面
          this.$router.replace("/login");
        })
        .catch(() => {});
    },
    formatter(row) {
      return row.address;
    },
    handleSizeChange(val) {
      this.pagination.pageSize = val;
      this.getProjectList();
    },
    handleCurrentChange(val) {
      this.pagination.currentPage = val;
      this.getProjectList();
    }
  }
};
</script>
<style>
/* 分页1，2，3数据li标签 */
/* .el-pagination.is-background .el-pager li {
  border-color: #4a5053;
  background-color: #202429;
} */
/* 分页前面箭头 */
/* .el-pagination.is-background .btn-prev {
  background-color: #202429;
} */
/* 分页后面箭头 */
/* .el-pagination.is-background .btn-next {
  background-color: #202429;
} */

/* //表格颜色 */
.ptable .el-table__header th {
  padding: 0;
  height: 42px;
  background-color: #409eff !important;
  color: #fff;
  box-shadow: -2px -2px 8px #63696e;
}
.ptable .el-table tr {
  background-color: #202429 !important;
  font-size: 18px;
  color: #f2f6fc;
}
.ptable .el-table tr:hover > td {
  background-color: #63696e !important;
}

/* //上箭头 */
.ptable .el-table .ascending .sort-caret.ascending {
  border-bottom-color: #63696e;
}
/* 下箭头 */
.ptable .el-table .descending .sort-caret.descending {
  border-top-color: #63696e;
}
/* 搜索框和前往页面输入框 */
.ptable .search .el-input__inner {
  background: #202429;
  border: 1px solid #32383f;
}
/* 表格颜色 */
.ptable .el-table td,
.ptable .el-table th.is-leaf {
  border: 1px solid #32383f;
}
/* 设置完表格颜色，但是表格底部线还是白色，其实是背景色导致的 */
.ptable .el-table::before {
  background-color: #32383f;
}
/* 设置完表格颜色，但是表格右部线还是白色，其实是背景色导致的 */
.ptable .el-table,
.ptable .el-table__expanded-cell {
  /* background-color: #32383f; */
  background-color: #05090f;
}

/* 右边滚动条 */
.ptable
  .el-table--scrollable-y
  .el-table__body-wrapper::-webkit-scrollbar-thumb {
  /*滚动条里面小方块*/
  background-color: #b2ddff;
  box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
}

.rightinfo .el-button {
  float: left;
  height: 60px;
  width: 40px;
  background-color: #3573c1;
  color: #fff;
  border-style: none;
  border-radius: 0px;
  padding: 0;
  margin-left: 35px;
}
.rightinfo .el-button:focus,
.rightinfo .el-button:hover {
  background-color: #3573c1;
  color: #fff;
  opacity: 0.9;
}
.searchBtn {
  margin-left: 5px;
}
</style>

<style lang="less" scoped>
.box {
  height: 100%;
  .top {
    height: 60px;
    background-color: #202429;
    position: relative;
    span {
      line-height: 60px;
      color: #00ccff;
      font-size: 26px;
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate3d(-50%, -50%, 0);
    }
    .rightinfo {
      justify-content: flex-end;
      display: flex;
      align-items: center;
      .right-menu-item {
        height: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 20px;
        color: #fff;
        margin-right: 50px;
        vertical-align: text-bottom;
        &.hover-effect {
          cursor: pointer;
          // transition: background 0.3s;
          &:hover {
            // background: rgba(0, 0, 0, 0.3);
          }
        }
      }
      i {
        font-size: 18px;
        color: #fff;
        margin-right: 10px;
      }
      .loginName {
        color: #fff;
        text-align: center;
      }
    }
  }
  .content {
    height: calc(100% - 177px);
    background-color: #05090f;
    padding: 77px 80px 40px;
    .search {
      margin-bottom: 22px;
    }
    .ptable {
      height: calc(100% - 126px);
    }
  }
}
</style>
