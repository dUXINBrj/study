<template>
  <div class="symbolComp" :style="styles">
    <video
      class="monitor"
      :src="videoSrc"
      controls
      playsinline
      webkit-playsinline
    ></video>
  </div>
</template>
<script>
import { initStyle } from "../common";
export default {
  props: {
    theme: String
  },
  data() {
    return {
      videoSrc:
        "https://edge.ivideo.sina.com.cn/34263728303.mp4?KID=sina,viask&Expires=1595520000&ssig=CPYZjez0yx&reqid=",
      styles: {},
      white: {
        backgroundColor: "",
        borderColor: "#000000",
        color: "#000000"
      },
      black: {
        backgroundColor: "",
        borderColor: "white",
        color: "white"
      },
      baisicConfig: {
        地址: {
          type: "textarea",
          value:
            "https://edge.ivideo.sina.com.cn/34263728303.mp4?KID=sina,viask&Expires=1595520000&ssig=CPYZjez0yx&reqid="
        },
        尺寸: {
          type: "widthHeight",
          label: ["宽度", "高度"],
          value: [0, 0]
        },
        位置: {
          type: "widthHeight",
          label: ["横轴", "纵轴"],
          value: [0, 0]
        },
        边框粗细: {
          type: "slider",
          status: 1,
          range: [0, 10],
          value: 0
        },
        边框颜色: {
          type: "color-select",
          value: "red"
        },
        显示度: {
          type: "slider",
          status: 1,
          range: [0, 100],
          value: 100
        },
        样式还原: {
          type: "resetStyle"
        },
        旋转角度: {
          type: "slider",
          status: 1,
          range: [0, 360],
          value: 0
        }
      }
    };
  },
  methods: {
    initStyle(bool) {
      initStyle(bool, this);
    }
  }
};
</script>

<style lang="less" scoped>
.monitor {
  width: 100%;
  height: 100%;
}

.symbolComp {
  width: calc(100%);
  height: calc(100%);
  display: flex;
  justify-content: center;
  align-items: center;
  box-sizing: border-box;
  white-space: pre;
  overflow: hidden;
}
</style>
