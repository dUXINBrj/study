<template>
  <div class="symbolComp" :style="styles">
    <img :src="imUrl" @mousedown.prevent="" alt="" />
  </div>
</template>
<script>
export default {
  props: {
    theme: String
  },
  watch: {
    "$store.getters.theme": function() {
      let theme = this[this.theme];
      this.baisicConfig["背景颜色"].value = theme.backgroundColor;
      this.initStyle(true);
    }
  },
  methods: {
    initStyle(bool) {
      this.imUrl = this.$parent.imUrl;
      this.styles = {
        opacity: this.baisicConfig["显示度"].value / 100,
        background: this.baisicConfig["背景颜色"].value
      };
      if (!bool) {
        this.$parent.initStyle(
          this.baisicConfig["尺寸"].value,
          this.baisicConfig["位置"].value,
          this.baisicConfig["旋转角度"].value
        );
      }
    }
  },
  data() {
    return {
      styles: {},
      imUrl: "",
      white: {
        color: ""
      },
      black: {
        color: "white"
      },
      highConfig: {
        添加响应: {
          type: "explain"
        },
        可见: {
          type: "eventVisible",
          value: {
            pointId: [],
            rule: ""
          }
        },
        线条1: {
          type: "line"
        },
        闪烁: {
          type: "eventOpacity",
          value: {
            pointId: [],
            rule: ""
          }
        },
        线条2: {
          type: "line"
        },
        显示度: {
          type: "eventMap",
          value: [],
          opacityRange: [20, 100],
          dataRange: [0, 100]
        }
      },
      baisicConfig: {
        尺寸: {
          type: "widthHeight",
          label: ["宽度", "高度"],
          value: [0, 0]
        },
        位置: {
          type: "widthHeight",
          label: ["横轴", "纵轴"],
          value: [0, 0]
        },
        背景颜色: {
          type: "color-select",
          value: ""
        },
        显示度: {
          type: "slider",
          status: 1,
          range: [0, 100],
          value: 100
        },
        旋转角度: {
          type: "slider",
          status: 1,
          range: [0, 360],
          value: 0
        }
      }
    };
  }
};
</script>
<style lang="less" scoped>
.symbolComp {
  width: calc(100%);
  height: calc(100%);
  display: flex;
  justify-content: center;
  align-items: center;
  box-sizing: border-box;
  white-space: pre;
  overflow: hidden;
  background-repeat: no-repeat;
  img {
    width: 100%;
    height: 100%;
  }
}
</style>
