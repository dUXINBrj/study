<template>
  <div class="symbolComp">日期选择器和树形图绑定</div>
</template>
<script>
export default {
  props: {
    theme: String
  },
  watch: {
    "$store.getters.theme": function() {
      this.initStyle(true);
    }
  },
  methods: {
    toSearch(val) {
      if (this.$store.state.runtime) {
        console.log(val);
      }
    },
    getData() {
      if (this.$store.state.runtime) {
        let treeId = this.highConfig["树形图"].value;
        if (treeId) {
          console.log(this.$drag.getTreeData(treeId));
        }
      }
    },
    initStyle(bool) {
      if (!bool) {
        this.$parent.initStyle(
          this.baisicConfig["尺寸"].value,
          this.baisicConfig["位置"].value,
          this.baisicConfig["旋转角度"].value
        );
      }
    }
  },
  data() {
    return {
      white: {
        backgroundColor: "",
        borderColor: "#000000",
        color: "#000000"
      },
      black: {
        backgroundColor: "",
        borderColor: "white",
        color: "white"
      },
      highConfig: {
        数据关联: {
          type: "explain"
        },
        日期组件: {
          type: "dependDateSelect",
          oldValue: "",
          value: ""
        },
        树形图: {
          type: "dependtree",
          value: ""
        }
      },
      baisicConfig: {
        尺寸: {
          type: "widthHeight",
          label: ["宽度", "高度"],
          value: [0, 0]
        },
        位置: {
          type: "widthHeight",
          label: ["横轴", "纵轴"],
          value: [0, 0]
        },

        旋转角度: {
          type: "slider",
          status: 1,
          range: [0, 360],
          value: 0
        }
      }
    };
  }
};
</script>

<style lang="less" scoped>
.symbolComp {
  width: calc(100%);
  height: calc(100%);
  display: flex;
  justify-content: center;
  align-items: center;
  box-sizing: border-box;
  white-space: pre;
  overflow: hidden;
}
</style>
