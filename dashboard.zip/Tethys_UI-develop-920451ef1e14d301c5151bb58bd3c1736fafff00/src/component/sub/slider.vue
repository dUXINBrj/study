<template>
  <div class="symbolComp" :style="styles">
    <span
      class="valueText"
      :class="highConfig['数据位置'].value"
      :style="fontStyle"
    >
      {{ value }}
    </span>
    <el-slider
      class="el-slider"
      v-model="value"
      :show-tooltip="false"
      :min="parseInt(highConfig['最小值'].value)"
      :max="parseInt(highConfig['最大值'].value)"
      :step="parseInt(highConfig['步长值'].value)"
      ref="elSlider"
    ></el-slider>
  </div>
</template>
<script>
export default {
  props: {
    theme: String
  },
  watch: {
    "$store.getters.theme": function() {
      let theme = this[this.theme];
      console.log(theme);
      this.initStyle(true);
    }
  },
  methods: {
    initStyle(bool) {
      let slider = this.$refs.elSlider.$el.getElementsByClassName(
        "el-slider__runway"
      )[0];
      let sliderBar = this.$refs.elSlider.$el.getElementsByClassName(
        "el-slider__bar"
      )[0];
      let sliderButton = this.$refs.elSlider.$el.getElementsByClassName(
        "el-slider__button"
      )[0];
      // slider.style = {
      //   ...slider.style,
      //   backgroundColor: this.baisicConfig["数据条背景颜色"].value,
      //   border: `${this.baisicConfig["数据条背景颜色"].value} slid ${this.baisicConfig["数据条背景颜色"].value}`
      // };
      // console.log(`${this.baisicConfig["边框粗细"].value}px solid ${this.baisicConfig["数据条边框颜色"].value}`);
      slider.style.backgroundColor = this.baisicConfig["数据条背景颜色"].value;
      slider.style.border = `${this.baisicConfig["边框粗细"].value}px solid ${this.baisicConfig["数据条边框颜色"].value}`;
      sliderBar.style.backgroundColor = this.baisicConfig[
        "数据条前景颜色"
      ].value;
      sliderButton.style.borderColor = this.baisicConfig["滑块边框颜色"].value;
      sliderButton.style.backgroundColor = this.baisicConfig[
        "滑块填充颜色"
      ].value;

      this.styles = {
        opacity: this.baisicConfig["显示度"].value / 100,
        fontSize: this.baisicConfig["数据条高度"].value * 5 + "px"
      };

      let font = this.highConfig["字体样式"].value;
      this.fontStyle = {
        fontSize: font[0],
        fontFamily: font[1],
        fontWeight: font[2],
        color: font[3]
      };

      if (!bool) {
        this.$parent.initStyle(
          this.baisicConfig["尺寸"].value,
          this.baisicConfig["位置"].value,
          this.baisicConfig["旋转角度"].value
        );
      }
    }
  },
  data() {
    return {
      value: 0,
      styles: {},
      fontStyle: {},
      highConfig: {
        添加响应: {
          type: "explain"
        },
        最小值: {
          type: "input",
          value: 0
        },
        最大值: {
          type: "input",
          value: 100
        },
        步长值: {
          type: "input",
          value: 1
        },
        数据位置: {
          type: "select",
          label: [
            {
              label: "无",
              value: "none"
            },
            {
              label: "右",
              value: "right"
            },
            {
              label: "左",
              value: "left"
            },
            {
              label: "上",
              value: "top"
            },
            {
              label: "下",
              value: "bottom"
            }
          ],
          value: "none"
        },
        字体样式: {
          type: "fontStyle",
          value: ["14px", "", "normal", ""]
        },
        线条1: {
          type: "line"
        },
        显示数据: {
          type: "eventVisible",
          value: {
            pointId: [],
            rule: ""
          }
        },
        线条2: {
          type: "line"
        },
        发送数据: {
          type: "eventVisible",
          value: {
            pointId: [],
            rule: ""
          }
        }
      },
      baisicConfig: {
        尺寸: {
          type: "widthHeight",
          label: ["宽度", "高度"],
          value: [0, 0]
        },
        位置: {
          type: "widthHeight",
          label: ["横轴", "纵轴"],
          value: [0, 0]
        },
        线条1: {
          type: "line"
        },
        数据条边框颜色: {
          type: "color-select",
          value: ""
        },
        数据条背景颜色: {
          type: "color-select",
          value: "#E4E7ED"
        },
        数据条前景颜色: {
          type: "color-select",
          value: "#409EFF"
        },
        滑块边框颜色: {
          type: "color-select",
          value: "#409EFF"
        },
        滑块填充颜色: {
          type: "color-select",
          value: "#FFF"
        },
        边框粗细: {
          type: "slider",
          status: 1,
          range: [0, 10],
          value: 0
        },
        数据条高度: {
          type: "slider",
          status: 1,
          range: [1, 8],
          value: 3
        },
        显示度: {
          type: "slider",
          status: 1,
          range: [0, 100],
          value: 100
        },
        样式还原: {
          type: "resetStyle"
        },
        线条2: {
          type: "line"
        },
        旋转角度: {
          type: "slider",
          status: 1,
          range: [0, 160],
          value: 0
        }
      }
    };
  }
};
</script>

<style lang="less" scoped>
.symbolComp {
  padding: 0 20px;
  width: calc(100%);
  height: calc(100%);
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  box-sizing: border-box;
  overflow: hidden;
  .el-slider {
    flex: 1;
    padding: 0 10px;
    font-size: 100%;
  }
  .el-slider /deep/ .el-slider__runway {
    height: 0.5em;
    font-size: 100%;
    .el-slider__bar {
      height: 0.5em;
    }
    .el-slider__button-wrapper {
      top: 50%;
      height: 3em;
      width: 3em;
      transform: translate(-50%, -50%);
      .el-slider__button {
        height: 1.3em;
        width: 1.3em;
      }
    }
  }
  .valueText {
    text-align: center;
    &.none {
      display: none;
    }
    &.left {
      padding-right: 20px;
    }
    &.right {
      order: 9;
      padding-left: 20px;
    }
    &.top {
      width: 100%;
    }
    &.bottom {
      order: 9;
      width: 100%;
    }
  }
}
</style>
