<template>
  <div class="symbolComp" :style="styles">
    查询条件
    <el-datePicker v-model="startDate"></el-datePicker>
    <el-datePicker v-model="endDate"></el-datePicker>
    <template v-for="(item, index) in radioArr">
      <el-radio
        :key="index"
        v-model="radioVal"
        :label="item.value"
        v-show="baisicConfig['日期类型'].value.includes(item.name)"
      >
        {{ item.name }}
      </el-radio>
    </template>
    <button class="searchBtn" :style="btnStyle">查询</button>
  </div>
</template>
<script>
export default {
  props: {
    theme: String
  },
  watch: {
    "$store.getters.theme": function() {
      let theme = this[this.theme];
      console.log(theme);
      this.initStyle(true);
    }
  },
  methods: {
    initStyle(bool) {
      let font = this.baisicConfig["字体"].value;
      this.styles = {
        opacity: this.baisicConfig["显示度"].value / 100,
        fontSize: font[0],
        fontFamily: font[1],
        color: font[3],
        fontWeight: font[2],
        background: this.baisicConfig["背景颜色"].value
      };

      this.btnStyle = {
        backgroundColor: this.baisicConfig["按钮颜色"].value
      };

      if (!bool) {
        this.$parent.initStyle(
          this.baisicConfig["尺寸"].value,
          this.baisicConfig["位置"].value,
          this.baisicConfig["旋转角度"].value
        );
      }
    }
  },
  data() {
    return {
      startDate: new Date().getTime() - 86400000,
      endDate: new Date(),
      radioVal: "hour",
      styles: {},
      btnStyle: {},
      white: {
        color: ""
      },
      radioArr: [
        {
          name: "小时",
          value: "hour"
        },
        {
          name: "日",
          value: "day"
        },
        {
          name: "周",
          value: "week"
        },
        {
          name: "月",
          value: "month"
        },
        {
          name: "季度",
          value: "quarter"
        },
        {
          name: "年",
          value: "year"
        }
      ],
      baisicConfig: {
        尺寸: {
          type: "widthHeight",
          label: ["宽度", "高度"],
          value: [0, 0]
        },
        位置: {
          type: "widthHeight",
          label: ["横轴", "纵轴"],
          value: [0, 0]
        },
        线条1: {
          type: "line"
        },
        名称: {
          type: "input",
          value: "日期"
        },
        字体: {
          type: "fontStyle",
          value: ["14px", "", "normal", "#b2ddff"]
        },
        背景颜色: {
          type: "color-select",
          value: ""
        },
        按钮颜色: {
          type: "color-select",
          value: "#3573c1"
        },
        显示度: {
          type: "slider",
          status: 1,
          range: [0, 100],
          value: 100
        },
        样式还原: {
          type: "resetStyle"
        },
        线条2: {
          type: "line"
        },
        旋转角度: {
          type: "slider",
          status: 1,
          range: [0, 160],
          value: 0
        },
        日期类型: {
          type: "dateTypeCheckbox",
          value: ["小时", "日", "月"]
        }
      }
    };
  }
};
</script>

<style lang="less" scoped>
.symbolComp {
  padding: 0 10px;
  width: calc(100%);
  height: calc(100%);
  display: flex;
  justify-content: flex-start;
  align-items: center;
  box-sizing: border-box;
  white-space: pre;
  overflow: hidden;
  /deep/ .el-input {
    margin: 0 0 0 10px;
    font-size: inherit;
    .el-input__inner {
      color: inherit;
      background-color: transparent;
      .el-input__prefix {
        color: #c0c4cc;
      }
    }
  }
  /deep/ .el-radio {
    margin: 0 0 0 10px;
    font-size: inherit;
    color: inherit;
    .el-radio__label {
      padding-left: 2px;
      font-size: inherit;
    }
  }
  .searchBtn {
    margin-left: 10px;
    padding: 10px 20px;
    border: none;
    border-radius: 10px;
    font-size: inherit;
    color: #b2ddff;
    outline: none;
  }
}
</style>
