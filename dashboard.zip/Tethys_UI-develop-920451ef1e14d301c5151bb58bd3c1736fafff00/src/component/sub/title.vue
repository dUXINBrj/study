<template>
  <div class="symbolComp" :style="styles">
    <svg
      :class="
        'icon-ali imgDiv ' + baisicConfig['是否启用小图标'].value.iconClass
      "
      :style="imgStyle"
      v-show="baisicConfig['是否启用小图标'].value.iconStatus"
      aria-hidden="true"
      version="1.1"
      preserveAspectRatio="xMinYMin meet"
    >
      <use
        :xlink:href="`#${baisicConfig['是否启用小图标'].value.iconClass}`"
      ></use>
    </svg>
    {{ title }}
  </div>
</template>
<script>
export default {
  props: {
    theme: String
  },
  watch: {
    "$store.getters.theme": function() {
      let theme = this[this.theme];
      console.log(theme);
      this.initStyle(true);
    }
  },
  methods: {
    initStyle(bool) {
      this.title = this.baisicConfig["标题内容"].value;
      let font = this.baisicConfig["字体样式"].value;
      this.styles = {
        border: `${this.baisicConfig["边框粗细"].value}px solid ${this.baisicConfig["边框颜色"].value}`,
        justifyContent: this.baisicConfig["标题位置"].value,
        opacity: this.baisicConfig["显示度"].value / 100,
        fontSize: font[0],
        fontFamily: font[1],
        color: font[3],
        fontWeight: font[2],
        background: this.baisicConfig["背景颜色"].value,
        boxShadow: `${this.baisicConfig["发光色"].value} 0px 0px 10px -3px inset`
      };
      this.imgStyle = {
        filter: `drop-shadow(${this.baisicConfig["是否启用小图标"].value.color} 56px 0)`
      };

      if (!bool) {
        this.$parent.initStyle(
          this.baisicConfig["尺寸"].value,
          this.baisicConfig["位置"].value,
          this.baisicConfig["旋转角度"].value
        );
      }
    }
  },
  data() {
    return {
      title: "",
      styles: {},
      imgStyle: {},
      white: {
        color: ""
      },
      baisicConfig: {
        尺寸: {
          type: "widthHeight",
          label: ["宽度", "高度"],
          value: [0, 0]
        },
        位置: {
          type: "widthHeight",
          label: ["横轴", "纵轴"],
          value: [0, 0]
        },
        线条1: {
          type: "line"
        },
        标题内容: {
          type: "input",
          value: "标题"
        },
        标题位置: {
          type: "select",
          label: [
            {
              label: "左",
              value: "flex-start"
            },
            {
              label: "中间",
              value: "center"
            },
            {
              label: "右",
              value: "flex-end"
            }
          ],
          value: "flex-start"
        },
        线条2: {
          type: "line"
        },
        字体样式: {
          type: "fontStyle",
          value: ["14px", "", "normal", ""]
        },
        背景颜色: {
          type: "color-select",
          value: ""
        },
        发光色: {
          type: "color-select",
          value: "rgb(53, 115, 193)"
        },
        边框颜色: {
          type: "color-select",
          value: "#404753"
        },
        是否启用小图标: {
          type: "iconCheckbox",
          note: "123",
          value: {
            iconStatus: false,
            iconClass: "iconshuzi",
            color: "#fff"
          }
        },
        边框粗细: {
          type: "slider",
          status: 1,
          range: [1, 10],
          value: 1
        },
        显示度: {
          type: "slider",
          status: 1,
          range: [0, 100],
          value: 100
        },
        样式还原: {
          type: "resetStyle"
        },
        线条3: {
          type: "line"
        },
        旋转角度: {
          type: "slider",
          status: 1,
          range: [0, 160],
          value: 0
        }
      }
    };
  }
};
</script>

<style lang="less" scoped>
.symbolComp {
  padding: 0 10px;
  width: calc(100%);
  height: calc(100%);
  display: flex;
  align-items: center;
  box-sizing: border-box;
  white-space: pre;
  overflow: hidden;
  .imgDiv {
    width: 46px;
    height: 46px;
    fill: currentColor;
    overflow: hidden;
    display: block;
    margin-top: 10px;
    transform: translateX(-56px);
  }
}
</style>
