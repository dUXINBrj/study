<template>
  <div class="symbolComp" :style="styles">
    <div class="switchs" :style="switchsStyle" @click="btnCut">
      <div class="circle" :style="circleStyle"></div>
      <div class="text" :style="textStyle">{{ text }}</div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    theme: String
  },
  watch: {
    "$store.getters.theme": function() {
      let theme = this[this.theme];
      this.baisicConfig["字体样式"].value[0] = theme.color;
      this.initStyle(true);
    }
  },
  methods: {
    initStyle(bool) {
      let theme = this[this.theme];
      this.text = this.baisicConfig["开文本"].value;
      theme.color = this.baisicConfig["字体样式"].value[0];
      let font = this.baisicConfig["文本样式"].value;
      let fontAlign = this.baisicConfig["字体样式"].value;
      this.styles = {
        fontSize: font[0],
        fontFamily: font[1],
        lineHeight: font[2],
        alignItems: font[4],
        color: fontAlign[0],
        fontWeight: fontAlign[1],
        fontStyle: fontAlign[2],
        textDecoration: fontAlign[3]
      };
      this.textStyle = {
        justifyContent: font[3]
      };
      if (!bool) {
        this.$parent.initStyle(
          this.baisicConfig["尺寸"].value,
          this.baisicConfig["位置"].value,
          this.baisicConfig["旋转角度"].value
        );
      }
    },
    btnCut() {
      this.$nextTick(() => {
        if (this.isOn) {
          this.text = this.baisicConfig["开文本"].value;
          this.switchsStyle = {
            flexDirection: "row"
          };
        } else {
          this.text = this.baisicConfig["关文本"].value;
          this.switchsStyle = {
            flexDirection: "row-reverse"
          };
        }
        this.isOn = !this.isOn;
      });
    }
  },
  data() {
    return {
      text: "",
      styles: {},
      circleStyle: {},
      switchsStyle: {},
      textStyle: {},
      isOn: true,
      white: {
        color: ""
      },
      black: {
        color: "white"
      },
      highConfig: {
        添加响应: {
          type: "explain"
        },
        可见: {
          type: "eventVisible",
          value: {
            pointId: [],
            rule: ""
          }
        },
        添加事件: {
          type: "explain"
        },
        事件: {
          type: "event",
          remind: false,
          value: [
            {
              order: ""
            }
          ]
        }
      },
      baisicConfig: {
        尺寸: {
          type: "widthHeight",
          label: ["宽度", "高度"],
          value: [0, 0]
        },
        位置: {
          type: "widthHeight",
          label: ["横轴", "纵轴"],
          value: [0, 0]
        },
        线条1: {
          type: "line"
        },
        文本样式: {
          type: "font-align",
          value: ["12px", "", "", "center", "center"]
        },
        字体样式: {
          type: "font",
          value: ["#FFFFFF", "normal", "", ""]
        },
        开文本: {
          type: "textarea",
          value: "ON"
        },
        线条2: {
          type: "line"
        },
        关文本: {
          type: "textarea",
          value: "OFF"
        },
        线条3: {
          type: "line"
        },
        旋转角度: {
          type: "slider",
          status: 1,
          range: [0, 360],
          value: 0
        }
      }
    };
  }
};
</script>
<style lang="less" scoped>
.symbolComp {
  width: calc(100%);
  height: calc(100%);

  box-sizing: border-box;
  white-space: pre;
  padding: 6px;
  overflow: hidden;
  .switchs {
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #000;
    border-radius: 200px;
    box-sizing: border-box;
    white-space: pre;
    padding: 6px;
    .circle {
      width: 35.97%;
      border-radius: 50%;
      background-color: #0064ff;
      height: 100%;
    }
    .text {
      flex: 1;
      display: flex;
      padding: 0 4px;
    }
  }
}
</style>
