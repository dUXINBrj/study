<template>
  <div class="symbolComp" :style="styles">
    <div ref="chart" style="width:100%;height:100%"></div>
  </div>
</template>
<script>
import echarts from "echarts";
export default {
  props: {
    theme: String
  },
  watch: {
    "$store.getters.theme": function() {
      let theme = this[this.theme];
      console.log(theme);
      this.initStyle(true);
    }
  },
  methods: {
    initStyle(bool) {
      this.styles = {
        opacity: this.baisicConfig["显示度"].value / 100,
        background: this.baisicConfig["背景颜色"].value
      };
      this.drawPie();

      if (!bool) {
        this.$parent.initStyle(
          this.baisicConfig["尺寸"].value,
          this.baisicConfig["位置"].value,
          this.baisicConfig["旋转角度"].value
        );
      }
    },

    drawPie() {
      if (!this.charts) {
        this.charts = echarts.init(this.$refs.chart);
      }
      let positionArr = this.baisicConfig["标题位置"].value.split("_");
      let LegPositionArr = this.baisicConfig["说明文字"].value.split("_");
      let font = this.baisicConfig["图表标题字体"].value;
      let font2 = this.baisicConfig["图表内容字体"].value;
      this.charts.setOption({
        title: {
          text: this.baisicConfig["名称"].value,
          left: positionArr[0],
          top: positionArr[1],
          textStyle: {
            fontSize: font[0].substring(0, font[0].length - 2),
            fontFamily: font[1],
            fontWeight: font[2],
            color: font[3]
          }
        },
        legend: {
          orient: "vertical",
          left: LegPositionArr[0],
          top: LegPositionArr[1],
          data: ["默认名称0"],
          textStyle: {
            fontSize: font2[0].substring(0, font[0].length - 2),
            fontFamily: font2[1],
            fontWeight: font2[2],
            color: font2[3]
          }
        },
        tooltip: {
          trigger: "item",
          formatter: "{a}<br/>{b}:{c} ({d}%)"
        },
        series: [
          {
            name: this.baisicConfig["名称"].value,
            type: "pie",
            data: this.highConfig["数据添加"].value,
            radius: ["50%", "70%"],
            avoidLabelOverlap: false,
            label: {
              show: false,
              position: "center"
            },
            emphasis: {
              label: {
                show: true,
                fontSize: "14",
                fontWeight: "bold"
              }
            },
            labelLine: {
              show: false
            }
          }
        ]
      });
    }
  },
  data() {
    return {
      charts: "",
      styles: {},
      white: {
        color: ""
      },
      baisicConfig: {
        尺寸: {
          type: "widthHeight",
          label: ["宽度", "高度"],
          value: [0, 0]
        },
        位置: {
          type: "widthHeight",
          label: ["横轴", "纵轴"],
          value: [0, 0]
        },
        线条1: {
          type: "line"
        },
        名称: {
          type: "input",
          value: "环图"
        },
        标题位置: {
          type: "select",
          label: [
            {
              label: "上",
              value: "center_top"
            },
            {
              label: "下",
              value: "center_bottom"
            },
            {
              label: "左",
              value: "left_middle"
            },
            {
              label: "右",
              value: "right_middle"
            },
            {
              label: "左上",
              value: "left_top"
            },
            {
              label: "右上",
              value: "right_top"
            },
            {
              label: "左下",
              value: "left_bottom"
            },
            {
              label: "右下",
              value: "right_bottom"
            }
          ],
          value: "left_top"
        },
        说明文字: {
          type: "select",
          label: [
            {
              label: "上",
              value: "center_top"
            },
            {
              label: "下",
              value: "center_bottom"
            },
            {
              label: "左",
              value: "left_middle"
            },
            {
              label: "右",
              value: "right_middle"
            },
            {
              label: "左上",
              value: "left_top"
            },
            {
              label: "右上",
              value: "right_top"
            },
            {
              label: "左下",
              value: "left_bottom"
            },
            {
              label: "右下",
              value: "right_bottom"
            }
          ],
          value: "center_bottom"
        },
        线条2: {
          type: "line"
        },
        图表标题字体: {
          type: "fontStyle",
          value: ["14px", "", "normal", "#333"]
        },
        图表内容字体: {
          type: "fontStyle",
          value: ["14px", "", "normal", "#B2DDFF"]
        },
        背景颜色: {
          type: "color-select",
          value: ""
        },
        显示度: {
          type: "slider",
          status: 1,
          range: [0, 100],
          value: 100
        },
        样式还原: {
          type: "resetStyle"
        },
        线条3: {
          type: "line"
        },
        旋转角度: {
          type: "slider",
          status: 1,
          range: [0, 160],
          value: 0
        },
        线条4: {
          type: "line"
        },
        默认时间选择: {
          type: "select",
          label: [
            {
              label: "实时",
              value: "center_top"
            },
            {
              label: "当日",
              value: "center_bottom"
            }
          ],
          value: "center_top"
        }
      },
      highConfig: {
        添加响应: {
          type: "explain"
        },
        数据添加: {
          type: "seriesData",
          chartType: "pie",
          value: [
            {
              name: "默认名称0",
              value: 100,
              pointId: [],
              rule: "",
              itemStyle: {
                color: ""
              }
            }
          ]
        }
      },
      opinion: ["直接访问", "邮件营销", "联盟广告", "视频广告", "搜索引擎"],
      opinionData: [
        { value: 335, name: "直接访问" },
        { value: 310, name: "邮件营销" },
        { value: 234, name: "联盟广告" },
        { value: 135, name: "视频广告" },
        { value: 1548, name: "搜索引擎" }
      ]
    };
  }
};
</script>

<style lang="less" scoped>
.symbolComp {
  padding: 0 10px;
  width: calc(100%);
  height: calc(100%);
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-sizing: border-box;
  white-space: pre;
  overflow: hidden;
}
</style>
