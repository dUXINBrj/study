export function initStyle(bool, that) {
  let theme = that[that.theme];
  let colorConfig = that.baisicConfig["字体样式"];
  if (colorConfig) {
    theme.color = colorConfig.value[0];
  }

  let borderColorConfig = that.baisicConfig["边框颜色"];
  if (borderColorConfig) {
    theme.borderColor = borderColorConfig.value;
  }

  let textConfig = that.baisicConfig["文本内容"];
  if (textConfig) {
    that.text = textConfig.value;
  }
  let fontConfig = that.baisicConfig["文本样式"];
  let styles = (that.styles = that.styles || {});
  if (fontConfig) {
    let font = fontConfig.value;
    styles.fontSize = font[0];
    styles.fontFamily = font[1];
    styles.lineHeight = font[2];
    styles.justifyContent = font[3];
    styles.alignItems = font[4];
    // if (fontAlignConfig) {
    //     let fontAlign = fontAlignConfig.value;
    //     let background
    //     that.styles = {
    //         fontSize: font[0],
    //         fontFamily: font[1],
    //         lineHeight: font[2],
    //         justifyContent: font[3],
    //         alignItems: font[4],
    //         color: fontAlign[0],
    //         fontWeight: fontAlign[1],
    //         fontStyle: fontAlign[2],
    //         textDecoration: fontAlign[3],
    //         background: that.baisicConfig["背景颜色"].value,
    //         border: `${that.baisicConfig["边框粗细"].value}px solid ${that.baisicConfig["边框颜色"].value}`,
    //         opacity: that.baisicConfig["显示度"].value / 100
    //     };
    // }
  }

  let fontAlignConfig = that.baisicConfig["字体样式"];
  if (fontAlignConfig) {
    let fontAlign = fontAlignConfig.value;
    styles.color = fontAlign[0];
    styles.fontWeight = fontAlign[1];
    styles.fontStyle = fontAlign[2];
    styles.textDecoration = fontAlign[3];
  }
  let backgroundConfig = that.baisicConfig["背景颜色"];
  if (backgroundConfig) {
    let background = backgroundConfig.value;
    styles.background = background;
  }
  let borderWidthConfig = that.baisicConfig["边框粗细"];
  if (borderWidthConfig && borderColorConfig) {
    let _borderWidth = borderWidthConfig.value;
    let _borderColor = borderColorConfig.value;
    styles.border = `${_borderWidth}px solid ${_borderColor}`;
  }

  let opacityConfig = that.baisicConfig["显示度"];
  if (opacityConfig) {
    let opacity = opacityConfig.value;
    styles.opacity = opacity / 100;
  }

  let monitorConfig = that.baisicConfig["地址"];
  if (monitorConfig) {
    let monitorSrc = monitorConfig.value;
    that.videoSrc = monitorSrc;
  }
  // let font = that.baisicConfig["文本样式"].value;
  // let fontAlign = that.baisicConfig["字体样式"].value;

  if (!bool) {
    that.$parent.initStyle(
      that.baisicConfig["尺寸"].value,
      that.baisicConfig["位置"].value,
      that.baisicConfig["旋转角度"].value
    );
  }
}
