# ztcsc

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

### description
组件 NavMenu
```
以index.vue中的el-menu为父容器，循环子组件menuItem
在menuItem中以vue原生dom结构进行书写会导致最外层多包一层div
导致菜单向左收起后无法隐藏有二级菜单的菜单名
因此使用jsx进行编码
在jsx中使用递归调用menuItem组件本身时，需注意组件名称首字母大写，jsx会将此当作一个类
小写则不能进行递归调用
