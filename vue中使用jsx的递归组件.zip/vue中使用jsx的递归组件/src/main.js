/** ========= 插件库和JS文件 start ========= **/
import Vue from 'vue'
import App from './App.vue'
import router from './router/index'
import store from './store/index'
import request from './request/http'
import urlConfig from './request/api/index'
import ElementUI from 'element-ui'
import regExp from './utils/regExp'
import tip from './utils/tip'
/** ========= 插件库和JS文件 end ========= **/

/** ========= 样式文件 start ========= **/
import 'element-ui/lib/theme-chalk/index.css' // elementUI的样式
import '@/assets/font/iconfont.css' // 字体文件
/** ========= 样式文件 end ========= **/

/** ========= VUE全局变量 start ========= **/
Vue.prototype.$api = request
Vue.prototype.$urlConfig = urlConfig
Vue.prototype.$regExp = regExp
Vue.prototype.$tip = tip
Vue.prototype.$store = store
/** ========= VUE全局变量 start ========= **/

Vue.use(ElementUI)

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
