const MAINPAGE = () => import(/* webpackChunkName: "about" */ '../views/mainPage/index')

export default [
  {
    path: '/index',
    name: 'mainPage',
    component: MAINPAGE,
    meta: {
      requireAuth: false
    }
  }
]
