/*
 * @module: 工具类 - 提示语
 * @fileName: tip.js
 * @Description: 用于存放项目中所有的提示语
 * @Author: LiSuwan
 * @Date: 2019-04-01 10:57:42
 */

export default {
  /* ================= 登录注册模块 start ============= */
  userNameDefault: '英文和字母均可，20个字符以内',
  userNameTip: '请输入正确的用户名格式',
  emailDefault: '请输入正确的邮箱地址',
  emailTip: '请输入正确的邮箱地址',
  passwordDefault: '请设置登录密码，10个字符以内',
  passwordTip: '请输入正确的密码格式',
  confirmPasswordDefault: '请确认登录密码',
  confirmPasswordTip: '密码输入不相同',
  codeDefault: '请输入发送到邮箱里的验证码',
  codeTip: '验证码错误'
  /* ================= 登录注册模块 end ============= */
}
