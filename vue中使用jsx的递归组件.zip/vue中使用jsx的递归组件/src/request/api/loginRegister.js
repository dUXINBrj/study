/*
 * @module: api接口 - 用户登录注册模块
 * @fileName:loginRegister.js
 * @Description:用户登录注册接口
 * @Author: LiSuwan
 * @Date: 2019-04-02 14:29:58
 */

let loginRegister = {
  'emailRepeat': 'users/tenants/email/', // 邮箱重复校验
  'sendEmail': 'users/tenants/send/', // 发送验证码到邮箱
  'nameRepeat': 'users/tenants/name/', // 用户名重复校验
  'tenants': '/users/tenants', // 租户注册
  // ================= 登录模块 WJN start =============
  'login': 'users/login', // 登陆
  'loginCode': 'users/verification/code/' // 获取登陆验证码
  // ================= 登录模块 WJN end =============
}

export default loginRegister
