// 用户管理模块的接口列表
let user = {
  'userInfo': '/users/user' // 获取登陆用户的信息
}
export default user
