/**
 * api接口的统一出口
 */
// 用户管理
import user from './user'
import loginRegister from './loginRegister'

let urlConfig = Object.assign( // 合并对象
  user,
  loginRegister
)

export default urlConfig
