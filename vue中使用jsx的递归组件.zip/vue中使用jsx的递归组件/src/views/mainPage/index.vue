<!--
 * @module: 平台首页
 * @fileName: index.vue
 * @Description: 平台首页
 * @Author: DuXin
 * @Date: 2019-04-09 14:18:53
 -->
<template>
 <div id="mainPage">
  <el-container>
    <el-aside width='17.448%'>
      <div class="logo-container"></div>
      <div class="aside-container">
        <nav-menu :navData='navData'></nav-menu>
      </div>
    </el-aside>
    <el-container>
      <el-header height='5.208vw'>
        <i class="iconfont iconyonghumingtubiao"></i>
        <div class="header-right">
          <i @click="fullScreen">全屏</i>
        </div>
      </el-header>
      <el-main>
        <router-view/>
      </el-main>
    </el-container>
  </el-container>
 </div>
</template>

<script>
import NavMenu from '@/components/NavMenu'
export default {
  data () {
    return {
      navData: [
        {
          name: '首页',
          path: '/home',
          src: 'iconyonghumingtubiao',
          children: []
        },
        {
          name: '实时监控',
          path: '/control',
          src: 'iconmimaxianshiyanjingtubiao',
          children: []
        },
        {
          name: '隐患管理',
          path: '',
          src: 'iconyanzhengmatubiao',
          children: [
            {
              name: '隐患查询',
              path: '',
              children: [
                { path: '/mainPage/test2', name: 'tets2', children: [] },
                { path: '/mainPage', name: '隐患处理2', children: [] },
                { path: '/mainPage', name: '隐患记录2', children: [] }
              ]
            },
            {
              path: '/mainPage',
              name: '隐患处理',
              children: [
                {
                  name: '能效管理',
                  path: '/energy',
                  src: 'iconyouxiangtubiao',
                  children: [ { path: '/mainPage/test1', name: 'test1', children: [] } ]
                }
              ]
            },
            { path: '/mainPage', name: '隐患记录', children: [] }
          ]
        },
        {
          name: '能效管理',
          path: '/energy',
          src: 'iconyouxiangtubiao',
          children: []
        }
      ]
    }
  },

  components: {
    'nav-menu': NavMenu
  },

  computed: {},

  mounted () {},

  methods: {
    /**
     * @Description: 全屏方法
     * @Author: DuXin
     * @Date: 2019-04-09 18:07:44
     */
    fullScreen () {}
  }
}

</script>
<style lang='stylus' scoped>
back-color = rgba(0,91,172,1)
#mainPage
  position absolute
  left 0
  right 0
  top 0
  bottom 0
  margin auto
#mainPage > .el-container
  width 100%
  height 100%
.el-aside
  height 100%
  background back-color
  box-shadow:0px 0px 15px 1px rgba(0,39,74,1)
  z-index 99
.logo-container
  width 100%
  height 100px
  display flex
  background #00284D
.el-header
  background back-color
  line-height 5.208vw
  padding-left 40px
  padding-right 50px
  color #fff
.iconfont
  color #fff
  font-size 22px
.header-right
  float right
  height 100%
.aside-container
  width 100%
  height calc(100% - 168px)
</style>
