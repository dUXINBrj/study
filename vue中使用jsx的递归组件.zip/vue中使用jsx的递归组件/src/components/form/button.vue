
<template>
  <div class="button">
    <el-button :disabled='isDisabled' :class="[btnStyleObj.size,btnStyleObj.disabled]" class="buttonBorder" @click="setEvent">{{btnName}}</el-button>
  </div>
</template>

<script>
export default {
  data () {
    return {
      btnStyleObj: {// button的样式
        size: '',
        disabled: ''
      },
      isDisabled: true // 按钮默认禁用
    }
  },
  props: ['btnName', 'btnStyle'],
  components: {},
  created () {
    this.btnStyleObj.size = (this.btnStyle && this.btnStyle.size) || 'buttonCodeSize'
    this.btnStyleObj.disabled = (this.btnStyle && this.btnStyle.disabled) || 'buttonDisabled'
  },
  computed: {},
  watch: {
    'btnStyle': {
      handler: function (val) { // 特别注意，不能用箭头函数，箭头函数，this指向全局
        this.btnStyleObj.disabled = (this.btnStyle && this.btnStyle.disabled) || 'buttonDisabled'

        if (this.btnStyle.disabled === 'buttonDisabled') {
          this.isDisabled = true
        } else {
          this.isDisabled = false
        }
      },
      deep: true
    }
  },
  mounted () {},
  methods: {
    /**
     * @Description:button按钮事件
     * @Author: LiSuwan
     * @Date: 2019-04-01 17:02:10
     */
    setEvent () {
      this.$emit('btnClick')
    }
  }
}

</script>
<style lang='stylus' scoped>
$colorDefault = #B9B9B9
$colorTip = #E60012
$colorIOTBlue = #005BAC
$colorDisabled = #ddd
$fontColorDisabled = #fff

.button
  >>> .el-button.is-disabled:hover
    border-color $colorDisabled
    background $colorDisabled
    color $fontColorDisabled

  >>> .el-button
    font-size 16px
    letter-spacing 1px
  >>> .codtButton:hover
      border-color #e3e3e3
      color #999
      background #f8f8f8

.buttonCodeSize
  border-radius 3px
  width 100%;
  max-width 192px;
  height 68px
.buttonRegisterSize
  border-radius 3px
  width 452px
  height 68px
.buttonBorder
  border-width 1.5px
  border-style solid
.buttonDisabled
  border-color $colorDisabled
  color $fontColorDisabled
  background $colorDisabled
.codtButton
  border-color #e3e3e3
  color #999
  background #f8f8f8
.registerBtn
  border-color $colorIOTBlue
  color $fontColorDisabled
  background $colorIOTBlue
</style>
