<!--
 * @module: 表单 - input表单
 * @fileName: input.vue
 * @Description: input 表单
 * @Author: LiSuwan
 * @Date: 2019-03-28 15:11:03
 -->

<template>
  <div class="input">
    <label :class="[labelStyle.line,labelStyle.width]">
      <span class="icon" :class="[{iconfont:iconName},iconName]" :style="{'font-size':iconStyleObj.fontSize+'px',color:iconStyleObj.color}"></span>
      <el-input
        :placeholder="placeholder"
        v-bind="$attrs"
        v-model.trim="content"
        v-on:focus="interaction"
        @blur="blurInput"
        :type="type"
      >
        <i slot="suffix" class="iconfont iconmimaxianshiyanjingtubiao"  @click.stop.prevent='showPassword' v-if="type"></i>
      </el-input>
    </label>
    <p class="input_tip" v-if="tip.isShow" :class="[tip.color]">{{tipName}}</p>
  </div>
</template>

<script>
export default {
  data () {
    return {
      content: '', // input框的内容
      labelStyle: {// label边框线的颜色
        line: 'borderColorDefault',
        width: 'labelWidth'
      },
      tip: {
        isShow: false, // 控制是否显示提示语颜色
        color: 'input_tipColorDefault' // 提示语颜色
      },
      iconStyleObj: {// icon的样式配置
        fontSize: '18', // icon的字体尺寸
        color: '#b2b2b2' // icon的字体颜色
      }
    }
  },
  inheritAttrs: false,
  props: ['iconName', 'placeholder', 'tipName', 'iconStyle', 'type', 'labelwidth'],
  components: {},

  created () {
    if (this.labelwidth) this.labelStyle.width = this.labelwidth
  },
  watch: {

  },
  mounted () {
    if (this.iconStyle) { // 设置组件的样式
      Object.assign(this.iconStyleObj, this.iconStyle)
    }
  },

  methods: {
    /**
     * @Description:设置input的交互
     * @Author: LiSuwan
     * @Date: 2019-03-28 18:48:35
     */
    interaction () {
      this.labelStyle.line = 'borderColorIOTBlue'
      this.tip.isShow = true
    },
    /**
     * @Description:设置input失去焦点的交互
     * @Author: LiSuwan
     * @Date: 2019-03-28 18:54:34
     */
    blurInput () {
      // this.tip.isShow = false

      this.$emit('getContent', this.content)
    },
    /**
     * @Description: 控制密码显示与隐藏
     * @Author: LiSuwan
     * @Date: 2019-03-29 13:35:29
     */
    showPassword () {
      this.type = this.type === 'password' ? 'text' : 'password'
    },
    /**
     * @Description:根据状态修改提示语颜色及显示隐藏、根据不同状态修改表单的颜色
     * @Author: LiSuwan
     * @param {number} 1：提示语、边框线的颜色改成红色 2：边框线改成默认 提示语改成默认的并隐藏
     * @Date: 2019-04-01 10:38:37
     */
    modifyTipStyle (type) {
      if (type === 1) {
        this.$set(this.tip, 'isShow', true)
        this.$set(this.tip, 'color', 'input_tipColorTip')
        this.$set(this.iconStyleObj, 'color', '#005BAC')
        this.$set(this.labelStyle, 'line', 'borderColorTip')
      } else if (type === 2) {
        this.$set(this.labelStyle, 'line', 'borderColorDefault')
        this.$set(this.tip, 'isShow', false)
        this.$set(this.iconStyleObj, 'color', '#005BAC')
        this.$set(this.tip, 'color', 'input_tipColorDefault')
      }
    }

  }
}

</script>
<style lang='stylus' scoped>
$colorDefault = #B9B9B9
$colorTip = #E60012
$colorIOTBlue = #005BAC

.input
  position relative
  label
    border-width: 1.5px;
    border-style: solid;
    border-radius: 3px;
    height 68px;
    display: flex;
    display: -webkit-flex; /* Safari */
    justify-content: flex-start;
    align-items:center;
    box-sizing border-box;
  >>> .el-input__inner
    border:none
    font-size 16px
    width 95%;
    padding:0 0 0 10px;
    color:#767676;
    font-size 18px;
    height 40px;
    line-height 40px;
    &::placeholder
      color:#b9b9b9;
  >>> .el-input--suffix
    line-height 40px
  >>> .el-input__suffix
    cursor pointer
    right 20px;
  .icon
    margin-left 20px
  .input_tip
    font-size: 16px;
    text-align left
    position absolute
    left 0px
    top:75px;
  .input_tipColorDefault
    color $colorDefault
  .input_tipColorTip
    color $colorTip
.borderColorDefault
  border-color $colorDefault
.borderColorTip
  border-color $colorTip
.borderColorIOTBlue
  border-color $colorIOTBlue
.labelWidth
  width 100%;
  box-sizing border-box;
.codeLabelWidth
  width 100%;
  max-width 247px;
</style>
