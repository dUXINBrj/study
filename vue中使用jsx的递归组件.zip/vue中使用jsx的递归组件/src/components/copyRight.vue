<!--
 * @module: copyRight
 * @fileName: copyRight.vue
 * @Description: 底部copyRight组件
 * @Author: WangJiaNan
 * @Date: 2019-04-03 13:23:47
 -->
<!--  -->
<template>
  <div class="copy_box">
    <p>COPYRIGHT © 2019 浙江正泰电器股份有限公司 </p>
    <p>浙ICP备11016013号</p>
  </div>
</template>

<script>
export default {
  data () {
    return {
    }
  },

  components: {},

  computed: {},

  mounted () {},

  methods: {}
}
</script>
<style lang='stylus' scoped>
  .copy_box
    >p
      font-family PingFangSC-Regular
      font-size 16px
      color #666666
      letter-spacing 0
      line-height 25px
      margin 5px 0
      padding-bottom 15px;
</style>
