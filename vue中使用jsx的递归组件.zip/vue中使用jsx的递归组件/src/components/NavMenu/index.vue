<!--
 * @module: mainPage
 * @fileName: aside.vue
 * @Description: 导航栏组件
 * @Author: DuXin
 * @Date: 2019-04-09 16:52:28
 -->
<template>
 <div>
   <el-menu
      :background-color="backgroundColor"
      :text-color="textColor"
      :active-text-color="activeTextColor"
      :collapse="true"
      >
      <template  v-for="(item , index ) in navData" >
        <menuItem :key='index' :item='item' :textColor='textColor'></menuItem>
      </template>
    </el-menu>
 </div>
</template>

<script>
import menuItem from './menuItem'
export default {
  props: {
    navData: {
      type: Array,
      required: true
    },
    backgroundColor: {
      type: String,
      default: '#005BAC'
    },
    textColor: {
      type: String,
      default: '#FFF'
    },
    activeTextColor: {
      type: String,
      default: '#FFF'
    }
  },
  data () {
    return {
    }
  },

  components: {
    menuItem
  },

  computed: {},

  mounted () {},

  methods: {}
}

</script>
<style lang='stylus' scoped>
a
  text-decoration none
.el-menu
  border-right none
</style>
