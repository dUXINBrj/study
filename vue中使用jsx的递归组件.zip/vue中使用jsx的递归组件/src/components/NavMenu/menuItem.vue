<!-- <div>
  <router-link :to="item.path" v-if='!item.children.length'>
    <el-menu-item :index="item.path">
      <i class="iconfont" v-if='item.src' :class="item.src" :style="{color: textColor}"></i>
      <span slot="title">{{item.name}}</span>
    </el-menu-item>
  </router-link>
  <el-submenu :index='Math.floor(Math.random () * 100000).toString()' v-if="item.children.length">
    <template slot="title">
      <i class="iconfont" v-if='item.src' :class="item.src" :style="{color: textColor}"></i>
      <span>{{item.name}}</span>
    </template>
    <menuItem v-for="(_item , index ) in item.children" :key="index" :item='_item' :textColor='textColor'></menuItem>
  </el-submenu>
</div> -->
<script>
export default {
  name: 'MenuItem',
  props: [ 'item', 'textColor' ],
  data () {
    return {
    }
  },
  render (h) {
    let menuItem
    let iconClass = this.item.src
    let icon = this.item.src ? <i class={['iconfont', iconClass]} style={{ color: this.textColor }}></i> : ''
    if (!this.item.children.length) {
      menuItem = <router-link to={this.item.path}>
        <el-menu-item index={this.item.path}>
          {icon}
          <span slot="title">{this.item.name}</span>
        </el-menu-item>
      </router-link>
    } else {
      menuItem = <el-submenu
        index={Math.floor(Math.random() * 100000).toString()}>
        <template slot="title">
          {icon}
          <span>{this.item.name}</span>
        </template>
        {
          this.item.children.map((_item, index) => {
            console.log(_item)
            return (
              <MenuItem
                key={index}
                item={_item}
                textColor={this.textColor}
              >
              </MenuItem>
            )
          })
        }
      </el-submenu>
    }
    return menuItem
  }
}

</script>
<style lang='stylus' scoped>
.iconfont
  margin-right 5px
  width 30px
  display inline-block
.el-menu-item.is-active
   background-color #1890FF !important
a
  text-decoration none
</style>
