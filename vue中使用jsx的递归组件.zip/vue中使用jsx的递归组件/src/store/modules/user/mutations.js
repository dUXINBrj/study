import { SET_TOKEN } from './mutation-type'
const mutation = {
  [SET_TOKEN] (state, token) {
    state.token = token
  }
}
export default mutation
