import Vue from 'vue'
import Vuex from 'vuex'
import getters from './getters'
import mutation from './mutations'
Vue.use(Vuex)

const state = {
  token: ''
}
// window.sessionStorage.getItem('logintoken') ? window.sessionStorage.getItem('logintoken') : ''
export default {
  namespaced: true,
  state,
  getters,
  mutation: mutation
}
