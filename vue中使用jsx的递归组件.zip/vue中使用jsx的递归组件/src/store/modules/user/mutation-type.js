export const SET_TOKEN = 'TOKEN'
