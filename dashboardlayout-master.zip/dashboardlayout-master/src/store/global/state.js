import {
    store
} from 'utils/';


export default {
    ajax_loading: false
};