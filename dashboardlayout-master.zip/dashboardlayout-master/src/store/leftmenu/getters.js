export default {
    // getCartList(state) {
    //     return state.cartList;
    // }
};