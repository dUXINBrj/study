/**
 * @desc 使用常量代替事假类型
 */
export default {
   SETA_COMPONENT_STATUS : SET_COMPONENT_STATUS


}
