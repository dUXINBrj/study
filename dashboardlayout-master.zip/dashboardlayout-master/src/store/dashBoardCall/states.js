/**
 * @author 
 * @desc 配置dash组件状态
 */
export default {
    dashcomponentstatus:{
     config : "edit",
    
    }

};