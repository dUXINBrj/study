/**
 * Created by sailengsi on 2017/5/10.
 */

//更新用户信息
export const UPDATE_USERINFO = 'UPDATE_USERINFO';

// 将要切换的机构ID
export const UPDATE_WILLSWITCHUNITID = 'UPDATE_WILLSWITCHUNITID';

//清空用户信息
export const REMOVE_USERINFO = 'REMOVE_USERINFO';

