import List from './List.vue';
export default List;