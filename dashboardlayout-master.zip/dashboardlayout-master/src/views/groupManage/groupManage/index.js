import List from './list/';

export default {
    List
};