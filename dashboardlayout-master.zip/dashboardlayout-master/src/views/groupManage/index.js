import groupManage from './groupManage/'

export default {
    groupManage
};