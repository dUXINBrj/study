
import SwitchUnit from './SwitchUnit.vue';

export default SwitchUnit;