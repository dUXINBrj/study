import userGroup from './userGroup/'
import userList from './userList/'
import userRole from './userRole/'
export default {
    userGroup,
    userList,
    userRole
    
};