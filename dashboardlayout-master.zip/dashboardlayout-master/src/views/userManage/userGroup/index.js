import list from './list.vue';

export default {
    list
};