/**
 * Created by sailengsi on 2017/5/10.
 */

import Login from './login/';
import LoginONlocale from './LoginONlocale/';
import SwitchUnit from './SwitchUnit';


import UnitManage from './unitManage/';
import UserManage from './userManage/';
import ContrlData from './contrlData/';
import UserInfo from './UserInfo/';
import UnitInfo from './OneUnitManage/';
import manageBoard from './manageBoard/';
import groupManage from './groupManage'
import dash from './dash/';
export {
	Login,
	LoginONlocale,
	SwitchUnit,
	UnitManage,
	UserManage,
	ContrlData,
	UserInfo,
	UnitInfo,
	manageBoard,
	groupManage,
	dash
};