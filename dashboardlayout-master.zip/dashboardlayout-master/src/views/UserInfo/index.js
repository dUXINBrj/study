import UserInfo from './UserInfo.vue';
export default UserInfo;