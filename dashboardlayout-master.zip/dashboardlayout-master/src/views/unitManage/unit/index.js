import List from './list/';
import Edit from './edit/';
import Type from './type/';

export default {
    List,
    Edit,
    Type
};