import Type from './Type.vue';
export default Type;