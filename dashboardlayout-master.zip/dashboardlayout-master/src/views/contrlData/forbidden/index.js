import ForbiddenPeople from './forbiddenPeople/'

export default {
    ForbiddenPeople
};