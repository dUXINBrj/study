import People from './People.vue';
export default People;