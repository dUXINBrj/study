import Forbidden from './forbidden/'
import Score from './score/'
export default {
    Forbidden,
    Score
};