import OneUnitHome from './OneUnitHome.vue';

export default OneUnitHome;