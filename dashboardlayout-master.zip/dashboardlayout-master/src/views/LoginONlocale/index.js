/**
 * Created by sailengsi on 2017/5/10.
 */

import LoginONlocale from './LoginONlocale.vue';

export default LoginONlocale; 