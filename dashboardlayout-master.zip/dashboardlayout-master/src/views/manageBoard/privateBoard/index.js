import privateManage from "./private.vue"
export default {
	privateManage
}
