import collect from "./collect.vue"
export default {
	collect
}