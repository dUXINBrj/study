import dashBoard from  "./dashBoard/"
import collectBoard from  "./collectBoard/"
import privateBoard from  "./privateBoard/"

export default {
	dashBoard,
	collectBoard,
	privateBoard
}