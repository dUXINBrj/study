export default {
	data(){
		return {
			imgarray:[{id:1,src:require("../../../assets/A12.png"),laytype:"A"},
			           {id:2,src:require("../../../assets/AA12.png"),laytype:"AA"},
			           {id:3,src:require("../../../assets/AAA2.png"),laytype:"AAA"},
			           {id:4,src:require("../../../assets/AB112.png"),laytype:"AB"}
			           ],
			carIndex:"2"         
		}
		
	}
	
}
