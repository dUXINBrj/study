<template>
	
  </el-table>
</template>

<script>
	import systemNoticeJs from "./systemNotice.js";
	export default systemNoticeJs
</script>

<style>
</style>