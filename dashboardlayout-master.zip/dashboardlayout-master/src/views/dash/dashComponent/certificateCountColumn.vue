<template>
	  <section class="chart">
                <div class="chartColumn" style=" width:90%;margin:auto;height:300px;"></div>
    </section>
</template>

<script>
	import certificateCountColumnJs from './certificateCountColumn.js';
    export default certificateCountColumnJs;
</script>

<style>
</style>