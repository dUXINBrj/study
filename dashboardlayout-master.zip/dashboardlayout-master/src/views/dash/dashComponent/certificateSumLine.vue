<template>
    <section class="chart">
                <div class="certificateSum" style=" width:90%;margin:auto;height:300px;"></div>
    </section>
</template>
<script>
    import certificateSumLineJs from './certificateSumLine.js';
    export default certificateSumLineJs;
</script>
<style scoped>
    
</style>
