import dashBoard from "./dashBoard/"
import dashComponent from "./dashComponent/"
export default {
	dashBoard,
	dashComponent
} 
