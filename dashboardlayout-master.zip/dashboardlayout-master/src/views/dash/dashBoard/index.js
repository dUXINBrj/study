import dashView from './dashView.vue';
export default dashView;