/**
 * Created by sailengsi on 2017/5/11.
 */
import Content from './Content.vue';
import Home from './Home.vue';

export {
	Home, Content
};