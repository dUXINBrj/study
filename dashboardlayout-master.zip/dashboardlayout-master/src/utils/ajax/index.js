import ajax from './ajax.js';
export default ajax;