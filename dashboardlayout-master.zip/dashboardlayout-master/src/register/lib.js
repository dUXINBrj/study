import lib_$ from 'jquery';
import lib__ from 'underscore';

// console.log(lib__);

export default {
	lib_$,
	lib__
};