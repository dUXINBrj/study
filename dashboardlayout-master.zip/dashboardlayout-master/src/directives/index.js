/**
 * Created by sailengsi on 2017/6/20.
 */

import wangeditorContent from './wangeditor';

export {
	wangeditorContent
};