/**
 * @author
 * @desc dashBoard API
 * 
 */
export default [
              {
	            name  : '获取小工具列表',
	            method: 'getGadgetList',
	            path  : 'dashboard/gadgets/page',
	            type  : 'post',
                }
]
	

