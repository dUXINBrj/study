export default function (test) {
	console.log('mixin test');
}