import Test from './Test.js';

export default {
	Test
};
