//导入自定义的全局混合
import methods from './methods/';
export {
	methods
};